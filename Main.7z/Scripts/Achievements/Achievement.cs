using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Settings;
using UnityEngine.SceneManagement;

public abstract class Achievement : MonoBehaviour
{
    public LocalizedString AchievementName;
    public AchievementData Data;

    protected AchievementsController _achievementsController;

    private void Start()
    {
        _achievementsController = AchievementsController.Instance;
        Data = _achievementsController.GetAchievementSaveData(Data.AchievementSaveKey);
        Data.AchievementName = AchievementName;
    }

    protected void OnEnable()
    {
                SceneManager.sceneLoaded += OnSceneLoaded;
    }

    protected void OnDisable()
    {
                SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        StartCoroutine(OnSceneLoadedHandler(scene, mode));
    }
    protected abstract IEnumerator OnSceneLoadedHandler(Scene scene, LoadSceneMode mode);


}
[System.Serializable]
public class AchievementData
{
    [HideInInspector]
    public LocalizedString AchievementName;

    public string AchievementSaveKey;
    public bool IsUnlocked;
    public int CurrentProgress;
    public int RequiredProgress;
}