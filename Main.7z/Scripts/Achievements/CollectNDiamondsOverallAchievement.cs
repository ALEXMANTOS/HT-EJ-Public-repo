using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CollectNDiamondsOverallAchievement : Achievement
{
    private int _previousDiamondCount = 0;
    private bool _subscribed;

    protected override IEnumerator OnSceneLoadedHandler(Scene scene, LoadSceneMode mode)
    {
        if (!Data.IsUnlocked)
        {
            Scene currentScene = scene;

            yield return new WaitUntil(() => CurrencyController.Instance != null || SceneManager.GetActiveScene() != currentScene);

            if (SceneManager.GetActiveScene() != currentScene)
            {
                yield break;
            }

            if (_subscribed) yield break;

            _previousDiamondCount = CurrencyController.Instance.GetDiamonds();
            CurrencyController.Instance.OnDiamondsUpdated += OnDiamondsUpdate;

            _subscribed = true;
        }
    }

    private void OnDiamondsUpdate(int currentCount)
    {
        if (currentCount > _previousDiamondCount)
        {
            int diamondsAdded = currentCount - _previousDiamondCount;

            _achievementsController.UpdateAchievementProgress(Data.AchievementSaveKey, diamondsAdded);
        }

        _previousDiamondCount = currentCount;
    }
}