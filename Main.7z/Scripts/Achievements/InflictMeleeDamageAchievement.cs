using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class InflictMeleeDamageAchievement : Achievement
{
    protected override IEnumerator OnSceneLoadedHandler(Scene scene, LoadSceneMode mode)
    {
        Scene currentScene = scene;

        yield return new WaitUntil(() => PlayerManager.Instance != null || SceneManager.GetActiveScene() != currentScene);

        if (SceneManager.GetActiveScene() != currentScene)
        {
            yield break;
        }

        if (!Data.IsUnlocked)
        {
            if(PlayerManager.Instance.TryGetComponent(out IPlayerMeleeAttack attack))
            {
                attack.OnDamageApplied += OnDamageApplied;
            }
        }
    }

    private void OnDamageApplied(float damage)
    {
        _achievementsController.UpdateAchievementProgress(Data.AchievementSaveKey, Mathf.CeilToInt(damage));
    }
}
