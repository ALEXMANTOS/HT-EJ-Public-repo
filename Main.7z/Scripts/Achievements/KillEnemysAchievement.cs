using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class KillEnemysAchievement : Achievement
{
    protected override IEnumerator OnSceneLoadedHandler(Scene scene, LoadSceneMode mode)
    {
        Scene currentScene = scene;

        yield return new WaitUntil(() => GameManager.Instance != null || SceneManager.GetActiveScene() != currentScene);

        if (SceneManager.GetActiveScene() != currentScene)
        {
            yield break;
        }

        if (!Data.IsUnlocked)
        {
            GameManager.Instance.GetComponent<EntitiesSpawnController>().OnEnemyKilled += (string name) => { _achievementsController.UpdateAchievementProgress(Data.AchievementSaveKey, 1); };
        }
    }
}