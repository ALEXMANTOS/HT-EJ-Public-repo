using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class KillTargetEnemyAchievement : Achievement
{
    [SerializeField] private string _TargetEnemyName;

    protected override IEnumerator OnSceneLoadedHandler(Scene scene, LoadSceneMode mode)
    {
        Scene currentScene = scene;

        yield return new WaitUntil(() => GameManager.Instance != null || SceneManager.GetActiveScene() != currentScene);

        if (SceneManager.GetActiveScene() != currentScene)
        {
            yield break; 
        }

        if (!Data.IsUnlocked)
        {
            GameManager.Instance.GetComponent<EntitiesSpawnController>().OnEnemyKilled += CheckEnemy;
        }
    }

    private void CheckEnemy(string name)
    {
        if(name == _TargetEnemyName)
        {
            _achievementsController.UpdateAchievementProgress(Data.AchievementSaveKey, 1);
        }
    }
}
