using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.SceneManagement;

public class ReachTurnByCharacterAchievement : Achievement
{
    [Space]
    [SerializeField] private string _LevelKey;
    [SerializeField] private string _CharacterName;

    private TurnController _turnController;

    protected override IEnumerator OnSceneLoadedHandler(Scene scene, LoadSceneMode mode)
    {
        if (!Data.IsUnlocked)
        {
            Scene currentScene = scene;

            yield return new WaitUntil(() => GameManager.Instance != null || SceneManager.GetActiveScene() != currentScene);

            if (SceneManager.GetActiveScene() != currentScene)
            {
                yield break;
            }

            if (_LevelKey != string.Empty && currentScene.name != _LevelKey) yield break;
            if (PlayerManager.Instance.name.Replace("(Clone)", "") != _CharacterName) yield break;

            _turnController = GameManager.Instance.GetComponent<TurnController>();
            _turnController.OnNewGameTurnStarted += CheckProgress;
        }
    }

    private void CheckProgress()
    {
        int bestTurnScore = Data.CurrentProgress;
        int currentTurn = _turnController.CurrentTurn;

        if (currentTurn > bestTurnScore)
        {
            int progressToAdd = currentTurn - bestTurnScore;
            _achievementsController.UpdateAchievementProgress(Data.AchievementSaveKey, progressToAdd);
        }
    }
}