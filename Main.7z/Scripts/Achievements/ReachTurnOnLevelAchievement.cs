using BayatGames.SaveGameFree;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ReachTurnOnLevelAchievement : Achievement
{
    [Space]
    [SerializeField] private string _LevelKey;

    protected override IEnumerator OnSceneLoadedHandler(Scene scene, LoadSceneMode mode)
    {
        if (!Data.IsUnlocked)
        {
            yield return new WaitUntil(() => _achievementsController != null);

            int bestTurnScore = LevelsManager.Instance.GetBestScore(_LevelKey);
            int progressToAdd = bestTurnScore - Data.CurrentProgress;
            _achievementsController.UpdateAchievementProgress(Data.AchievementSaveKey, progressToAdd);
        }
    }
}
