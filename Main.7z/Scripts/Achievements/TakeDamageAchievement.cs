using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TakeDamageAchievement : Achievement
{
    protected override IEnumerator OnSceneLoadedHandler(Scene scene, LoadSceneMode mode)
    {
        Scene currentScene = scene;

        yield return new WaitUntil(() => PlayerManager.Instance != null || SceneManager.GetActiveScene() != currentScene);

        if (SceneManager.GetActiveScene() != currentScene)
        {
            yield break;
        }

        if (!Data.IsUnlocked)
        {
            if (PlayerManager.Instance.TryGetComponent(out EntityHealth health))
            {
                health.OnDamaged += OnDamaged;
            }
        }
    }

    private void OnDamaged(float damage)
    {
        _achievementsController.UpdateAchievementProgress(Data.AchievementSaveKey, Mathf.CeilToInt(damage));
    }
}
