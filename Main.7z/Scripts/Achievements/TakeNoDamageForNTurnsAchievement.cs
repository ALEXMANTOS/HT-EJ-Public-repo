using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TakeNoDamageForNTurnsAchievement : Achievement
{
    [Space]
    [SerializeField] private int _NumberOfTurns;

    private TurnController _turnController;
    private int _lastTurnNoDamage = 0;

    protected override IEnumerator OnSceneLoadedHandler(Scene scene, LoadSceneMode mode)
    {
        if (!Data.IsUnlocked)
        {
            Scene currentScene = scene;

            yield return new WaitUntil(() => PlayerManager.Instance != null || SceneManager.GetActiveScene() != currentScene);

            if (SceneManager.GetActiveScene() != currentScene)
            {
                yield break;
            }

            _turnController = GameManager.Instance.GetComponent<TurnController>();
            PlayerManager.Instance.GetComponent<EntityHealth>().OnDamaged += OnDamaged;
        }
    }

    private void OnDamaged(float damage)
    {
        if (_turnController.CurrentTurn - _lastTurnNoDamage >= _NumberOfTurns)
        {
            _achievementsController.UpdateAchievementProgress(Data.AchievementSaveKey, 1);
        }
        else
        {
            _lastTurnNoDamage = _turnController.CurrentTurn;
        }
    }
}