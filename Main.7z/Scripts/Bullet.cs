using Lean.Pool;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    private BulletProperties _properties;
    private GameObject _shooter;


    private void FixedUpdate()
    {
        transform.position += transform.right * _properties.Speed * Time.fixedDeltaTime;;
    }

    public void InitBullet(float damage, BulletProperties properties,GameObject shooter)
    {
        _properties = properties;
        _properties.Damage = damage;

        _shooter = shooter;

        LeanPool.Despawn(gameObject, _properties.Lifetime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject == _shooter) return;

        if (collision.TryGetComponent(out EntityHealth hp))
        {
            if(hp is PlayerHealth)
            {
                hp.ApplyDamage(_properties.Damage);
            }
            else if (_properties.DamageAll)
            {
                hp.ApplyDamage(_properties.Damage);
            }
            else
            {
                return;
            }
        }

        LeanPool.Despawn(gameObject);
    }
}


[Serializable]
public struct BulletProperties
{
    [HideInInspector] public float Damage;
    public float Speed;
    public float Lifetime;
    public bool DamageAll;

    public BulletProperties( float speed, float damage, float lifetime, bool damageEnemies)
    {
        Speed = speed;
        Damage = damage;
        Lifetime = lifetime;
        DamageAll = damageEnemies;
    }
}