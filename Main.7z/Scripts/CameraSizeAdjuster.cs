using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Camera))]
public class CameraSizeAdjuster : MonoBehaviour
{
    private Camera _camera;

    private MapController _mapController;

    void Start()
    {
        _camera = GetComponent<Camera>();
        _mapController = GameManager.Instance.GetComponent<MapController>();

        SetCameraSize();
    }

    void SetCameraSize()
    {
        float aspectRatio = (float)Screen.width / Screen.height;
        float sizeMultiplier = 0.5f;
        Vector2 mapSize = _mapController.GetMapSize();
        if (mapSize.x / mapSize.y > aspectRatio)
        {
            _camera.orthographicSize = (mapSize.x / 2f / aspectRatio) + sizeMultiplier;
        }
        else
        {
            _camera.orthographicSize = (mapSize.y / 2f) + sizeMultiplier;
        }
    }
}
