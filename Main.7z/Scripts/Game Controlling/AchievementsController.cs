using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using BayatGames.SaveGameFree;

public class AchievementsController : MonoBehaviour
{
    public static AchievementsController Instance {  get; private set; }

    private Dictionary<string, AchievementData> _achievements = new Dictionary<string, AchievementData>();
    private const string SAVE_KEY = "achievements";

    private void Awake()
    {
        if(Instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
        }

        if (SaveGame.Exists(SAVE_KEY))
        {
            _achievements = SaveGame.Load(SAVE_KEY, new Dictionary<string, AchievementData>());
        }

        foreach (Transform achievementTransform in transform)
        {
            Achievement achievement = achievementTransform.GetComponent<Achievement>();
            AddAchievementIfNotExists(achievement.Data);
        }

        RemoveNonExistingAchievements();
    }

    private void AddAchievementIfNotExists(AchievementData achievement)
    {
        if (!_achievements.ContainsKey(achievement.AchievementSaveKey))
        {
            _achievements.Add(achievement.AchievementSaveKey, achievement);
            SaveProgress();
        }
    }
    private void RemoveNonExistingAchievements()
    {
        List<string> keysToRemove = new List<string>();
        foreach (var achievementKey in _achievements.Keys)
        {
            bool existsInChildren = false;

            foreach (Transform achievementTransform in transform)
            {
                Achievement achievement = achievementTransform.GetComponent<Achievement>();
                if (achievement.Data.AchievementSaveKey == achievementKey)
                {
                    existsInChildren = true;
                    break;
                }
            }
            if (!existsInChildren)
            {
                keysToRemove.Add(achievementKey);
            }
        }
        foreach (string key in keysToRemove)
        {
            _achievements.Remove(key);
        }

        if (keysToRemove.Count > 0)
        {
            SaveProgress();
        }
    }

    public AchievementData GetAchievementSaveData(string saveKey)
    {
        return _achievements[saveKey];
    }
    public bool IsAchievementUnlocked(string achievementSaveKey)
    {
        return _achievements.ContainsKey(achievementSaveKey) && _achievements[achievementSaveKey].IsUnlocked;
    }
    public bool IsAchievementExist(string achievementSaveKey)
    {
        return _achievements.ContainsKey(achievementSaveKey);
    }
    public void UnlockAchievement(string achievementSaveKey)
    {
        if (_achievements.ContainsKey(achievementSaveKey) && !_achievements[achievementSaveKey].IsUnlocked)
        {
            _achievements[achievementSaveKey].IsUnlocked = true;
            SaveProgress();
        }
    }
    public void UpdateAchievementProgress(string achievementSaveKey, int progressToAdd)
    {
        if (_achievements.ContainsKey(achievementSaveKey))
        {
            AchievementData achievement = _achievements[achievementSaveKey];
            if (!achievement.IsUnlocked)
            {
                achievement.CurrentProgress += progressToAdd;

                if (achievement.CurrentProgress >= achievement.RequiredProgress)
                {
                    UnlockAchievement(achievementSaveKey);
                }
                SaveProgress();
            }
        }
    }

    [ContextMenu("Reset Achievements")]
    public void ResesAchievements()
    {
        _achievements = new Dictionary<string, AchievementData>();
        SaveProgress();
    }
    private void SaveProgress()
    {
        SaveGame.Save(SAVE_KEY, _achievements);
    }
}