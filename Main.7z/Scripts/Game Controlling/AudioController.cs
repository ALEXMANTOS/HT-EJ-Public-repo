using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioController : MonoBehaviour
{
    public static AudioController Instance { get; private set; }

    [SerializeField] private List<AudioClip> _Music;
    [SerializeField] private AudioSource _BGSource;
    [SerializeField] private AudioSource _SFXSource;
    [SerializeField] private float _PauseBetweenTracks = 2f;

    private int _currentTrackIndex = 0;

    private void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        if (_Music.Count > 0)
        {
            ShuffleTracks();
            StartCoroutine(PlayMusic());
        }
    }

    private void ShuffleTracks()
    {
        for (int i = 0; i < _Music.Count; i++)
        {
            AudioClip temp = _Music[i];
            int randomIndex = Random.Range(i, _Music.Count);
            _Music[i] = _Music[randomIndex];
            _Music[randomIndex] = temp;
        }
    }

    private IEnumerator PlayMusic()
    {
        while (true)
        {
            if (!_BGSource.isPlaying)
            {
                _BGSource.clip = _Music[_currentTrackIndex];
                _BGSource.Play();
                yield return new WaitForSeconds(_BGSource.clip.length);
                yield return new WaitForSeconds(_PauseBetweenTracks);
                _currentTrackIndex = (_currentTrackIndex + 1) % _Music.Count;
            }

            yield return null;
        }
    }


    public void PlaySound(AudioClip clip, float volume = 1)
    {
        _SFXSource.PlayOneShot(clip,volume);
    }
}