using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(TurnController))]
[RequireComponent(typeof(EntitiesSpawnController))]
[RequireComponent(typeof(MapController))]
public class BossSpawner : MonoBehaviour
{
    [SerializeField] private List<BossSpawnInfo> _spawnInfos;

    private TurnController _turnController;
    private EntitiesSpawnController _entitiesSpawnController;
    private MapController _mapController;

    private void Start()
    {
        _turnController = GetComponent<TurnController>();
        _entitiesSpawnController = GetComponent<EntitiesSpawnController>();
        _mapController = GetComponent<MapController>();

        _turnController.OnNewGameTurnStarted += OnNewGameTurnStarted;
    }

    private void OnNewGameTurnStarted()
    {
        int currentTurn = _turnController.CurrentTurn;
        for (int i = _spawnInfos.Count - 1; i >= 0; i--)
        {
            var spawnInfo = _spawnInfos[i];
            if (spawnInfo.SpawnAtTurn <= currentTurn)
            {
                bool spawned = SpawnBoss(spawnInfo);
                if (spawned)
                {
                    _spawnInfos.RemoveAt(i);
                }
            }
        }
    }

    private bool SpawnBoss(BossSpawnInfo spawnInfo)
    {
        if (spawnInfo.BossPrefab == null)
        {
            Debug.LogWarning("BossPrefab �� ����� ��� ������ �� ��������� � ������ SpawnInfos!");
            return false;
        }

        bool spawnSuccessful = _mapController.TryToSpawnEntityOnRandomFreeCell(spawnInfo.BossPrefab, out GameObject bossGO);
        if (spawnSuccessful)
        {
            _entitiesSpawnController.AddEntityToSpawned(bossGO.GetComponent<MapEntityTurnController>());
        }

        return spawnSuccessful;
    }

    [Serializable]
    public struct BossSpawnInfo
    {
        public GameObject BossPrefab;
        public int SpawnAtTurn;
    }
}