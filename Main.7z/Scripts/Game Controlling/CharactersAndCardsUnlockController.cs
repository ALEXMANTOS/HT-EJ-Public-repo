using BayatGames.SaveGameFree;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Localization.Tables;

public class CharactersAndCardsUnlockController : MonoBehaviour
{
    public static CharactersAndCardsUnlockController Instance { get; private set; }

    [SerializeField] private List<CharacterSelectiveInfoData> _CharactersDatas;
    [SerializeField] private List<CardSelectiveInfoData> _CardsDatas;

    private const string CHARACTERSSAVE_KEY = "characters";
    private Dictionary<string, bool> _unlockedCharacters = new Dictionary<string, bool>();

    private const string CARDSSAVE_KEY = "cards";
    private Dictionary<string, bool> _unlockedCards = new Dictionary<string, bool>();

    private void Awake()
    {
        Instance = this;

        HandleUnlocks(CHARACTERSSAVE_KEY, _unlockedCharacters,
                      _CharactersDatas.Select(c => new KeyValuePair<string, bool>(
                          c.CharacterName.TableEntryReference.KeyId.ToString(), c.InitiallyUnlocked)).ToList(),
                      SaveCharacters);

        HandleUnlocks(CARDSSAVE_KEY, _unlockedCards,
                      _CardsDatas.Select(c => new KeyValuePair<string, bool>(
                          c.CardData.CardName.TableEntryReference.KeyId.ToString(), c.InitiallyUnlocked)).ToList(),
                      SaveCards);
    }

    private void HandleUnlocks(string saveKey, Dictionary<string, bool> unlockedItems, List<KeyValuePair<string, bool>> itemKeyIdsWithStatus, Action saveMethod)
    {
        LoadUnlocks(saveKey, unlockedItems);
        CheckForNewItems(unlockedItems, itemKeyIdsWithStatus);
        RemoveOldItems(unlockedItems, itemKeyIdsWithStatus.Select(item => item.Key).ToList());

        saveMethod.Invoke();
    }
    private void LoadUnlocks(string saveKey, Dictionary<string, bool> unlockedItems)
    {
        if (SaveGame.Exists(saveKey))
        {
            unlockedItems.Clear();
            var loadedItems = SaveGame.Load(saveKey, new Dictionary<string, bool>());

            foreach (var item in loadedItems)
            {
                unlockedItems[item.Key] = item.Value;
            }
        }
        else
        {
            unlockedItems.Clear();
        }
    }
    private void CheckForNewItems(Dictionary<string, bool> unlockedItems, List<KeyValuePair<string, bool>> itemKeyIdsWithStatus)
    {
        foreach (var item in itemKeyIdsWithStatus)
        {
            if (!unlockedItems.ContainsKey(item.Key))
            {
                unlockedItems.Add(item.Key, item.Value);
            }
        }
    }
    private void RemoveOldItems(Dictionary<string, bool> unlockedItems, List<string> itemKeyIds)
    {
        List<string> itemsToRemove = unlockedItems.Keys.Where(itemName => !itemKeyIds.Contains(itemName)).ToList();

        foreach (string itemName in itemsToRemove)
        {
            unlockedItems.Remove(itemName);
        }
    }

    public bool IsCharacterUnlocked(string characterNameKeyId)
    {
        return _unlockedCharacters.ContainsKey(characterNameKeyId) && _unlockedCharacters[characterNameKeyId];
    }

    public void UnlockCharacter(string characterNameKeyId)
    {
        if (_unlockedCharacters.ContainsKey(characterNameKeyId) && !_unlockedCharacters[characterNameKeyId])
        {
            _unlockedCharacters[characterNameKeyId] = true;
            SaveCharacters();
        }
    }
    public void UnlockAllCharacters()
    {
        foreach (var character in _CharactersDatas)
        {
            string keyId = character.CharacterName.TableEntryReference.KeyId.ToString();
            if (_unlockedCharacters.ContainsKey(keyId) && !_unlockedCharacters[keyId])
            {
                _unlockedCharacters[keyId] = true;
            }
            else if (!_unlockedCharacters.ContainsKey(keyId))
            {
                _unlockedCharacters.Add(keyId, true);
            }
        }

        SaveCharacters();
    }


    public GameObject GetCharacter(string characterNameKeyId)
    {
        return _CharactersDatas.Find(data => data.CharacterName.TableEntryReference.KeyId.ToString() == characterNameKeyId)?.CharacterPrefab;
    }
    public GameObject GetFirstCharacter()
    {
        return _CharactersDatas[0].CharacterPrefab;
    }

    public bool IsCardUnlocked(string cardNameKeyId)
    {
        return _unlockedCards.ContainsKey(cardNameKeyId) && _unlockedCards[cardNameKeyId];
    }

    public void UnlockCard(string cardNameKeyId)
    {
        if (_unlockedCards.ContainsKey(cardNameKeyId) && !_unlockedCards[cardNameKeyId])
        {
            _unlockedCards[cardNameKeyId] = true;
            SaveCards();
        }
    }
    public void UnlockAllCards()
    {
        foreach (var card in _CardsDatas)
        {
            string keyId = card.CardData.CardName.TableEntryReference.KeyId.ToString();
            if (_unlockedCards.ContainsKey(keyId) && !_unlockedCards[keyId])
            {
                _unlockedCards[keyId] = true;
            }
            else if (!_unlockedCards.ContainsKey(keyId))
            {
                _unlockedCards.Add(keyId, true);
            }
        }

        SaveCards();
    }

    public CardData GetCard(string cardNameKeyId)
    {
        return _CardsDatas.Find(data => data.CardData.CardName.TableEntryReference.KeyId.ToString() == cardNameKeyId).CardData;
    }

    private void SaveCharacters()
    {
        SaveGame.Save(CHARACTERSSAVE_KEY, _unlockedCharacters);
    }

    private void SaveCards()
    {
        SaveGame.Save(CARDSSAVE_KEY, _unlockedCards);
    }

    [ContextMenu("Reset Characters Saves")]
    public void ResetCharactersSaves()
    {
        SaveGame.Delete(MainMenuController.SELECTED_CHARACTER_SAVE_KEY);
        _unlockedCharacters = new Dictionary<string, bool>();
        SaveCharacters();
    }

    [ContextMenu("Reset Cards Saves")]
    public void ResetCardsSaves()
    {
        _unlockedCards = new Dictionary<string, bool>();
        SaveCards();
    }
}
