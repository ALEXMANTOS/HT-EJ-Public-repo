using BayatGames.SaveGameFree;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CurrencyController : MonoBehaviour
{
    public static CurrencyController Instance { get; private set; }

    public event System.Action<int> OnDiamondsUpdated;
    public event System.Action<int> OnRubiesUpdated;

    private const string DIAMONDS_SAVE_KEY = "diamonds";
    private int _diamonds;

    private const string RUBIES_SAVE_KEY = "rubies";
    private int _rubies;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

        LoadDiamonds();
        LoadRubies();
    }

    #region Diamonds
    public int GetDiamonds()
    {
        return _diamonds;
    }
    public void AddDiamonds(int amount)
    {
        _diamonds += amount;
        SaveDiamonds();
        OnDiamondsUpdated?.Invoke(_diamonds);
    }
    public bool TrySpendDiamonds(int amount)
    {
        if (_diamonds >= amount)
        {
            _diamonds -= amount;
            SaveDiamonds();
            OnDiamondsUpdated?.Invoke(_diamonds);
            return true;
        }
        else
        {
            Debug.LogWarning("������������ �������!");
            return false;
        }
    }
    private void SaveDiamonds()
    {
        SaveGame.Save(DIAMONDS_SAVE_KEY, _diamonds);
    }
    private void LoadDiamonds()
    {
        if (SaveGame.Exists(DIAMONDS_SAVE_KEY))
        {
            _diamonds = SaveGame.Load<int>(DIAMONDS_SAVE_KEY);
        }
        else
        {
            _diamonds = 0;
        }

        OnDiamondsUpdated?.Invoke(_diamonds);
    }

    [ContextMenu("Reset Diamonds")]
    public void ResetDiamonds()
    {
        _diamonds = 0;
        SaveDiamonds();
        OnDiamondsUpdated?.Invoke(_diamonds);
    }
    #endregion

    #region Rubies
    public int GetRubies()
    {
        return _rubies;
    }
    public void AddRubies(int amount)
    {
        _rubies += amount;
        SaveRubies();
        OnRubiesUpdated?.Invoke(_rubies);
    }
    public bool TrySpendRubies(int amount)
    {
        if (_rubies >= amount)
        {
            _rubies -= amount;
            SaveRubies();
            OnRubiesUpdated?.Invoke(_rubies);
            return true;
        }
        else
        {
            Debug.LogWarning("������������ �������!");
            return false;
        }
    }
    private void SaveRubies()
    {
        SaveGame.Save(RUBIES_SAVE_KEY, _rubies);
    }
    private void LoadRubies()
    {
        if (SaveGame.Exists(RUBIES_SAVE_KEY))
        {
            _rubies = SaveGame.Load<int>(RUBIES_SAVE_KEY);
        }
        else
        {
            _rubies = 0;
        }

        OnRubiesUpdated?.Invoke(_rubies);
    }

    [ContextMenu("Reset Rubies")]
    public void ResetRubies()
    {
        _rubies = 0;
        SaveRubies();
        OnRubiesUpdated?.Invoke(_rubies);
    }
    #endregion
}
