using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class DeckController : MonoBehaviour
{
    [SerializeField] private GameObject _CardHolderPrefab;
    [SerializeField] private int _MaxCardsCount;

    [Header("Refs")]
    [SerializeField] private RectTransform _Deck;
    [SerializeField] private RectTransform _HoldingCardHolderRef;
    [SerializeField] private OpenedCardUI _OpenedCard;

    private RectTransform _holdingCardHolder;

    private void Start()
    {
        GetComponent<TurnController>().OnNewTurnStarted += SetDeckInteractable;
    }

    private void SetDeckInteractable(string teamName)
    {
        if(teamName != "Player" && _Deck.GetComponent<CanvasGroup>().blocksRaycasts == true)
        {
            _Deck.GetComponent<CanvasGroup>().blocksRaycasts = false;

            if(_OpenedCard.gameObject.activeSelf == true)
            {
                CloseCard();
            }
            else if (_holdingCardHolder != null)
            {
                _holdingCardHolder.GetComponentInChildren<IEndDragHandler>().OnEndDrag(null);

               
            }
        }
        else if(teamName == "Player")
        {
            _Deck.GetComponent<CanvasGroup>().blocksRaycasts = true;
        }
    }


    public RectTransform SetHoldingCard(RectTransform cardHolder)
    {
        cardHolder.transform.SetParent(_HoldingCardHolderRef);
        _holdingCardHolder = cardHolder;

        return _HoldingCardHolderRef;
    }
    public RectTransform PutCardInDeck(RectTransform cardHolder)
    {
        cardHolder.transform.SetParent(_Deck);
        _holdingCardHolder = null;

        return _Deck;
    }
    public void OpenCard(CardUI card,RectTransform holder)
    {

        _OpenedCard.SetCardData(card._CardData,card.GetComponent<Image>().sprite);
        _OpenedCard.SetCardActive(true);

        _holdingCardHolder.gameObject.SetActive(false);
    }
    public void CloseCard()
    {
        _OpenedCard.SetCardActive(false);
        _holdingCardHolder.gameObject.SetActive(true);

    }
    public void ActivateCard()
    {
        _OpenedCard.UseCard();
        _OpenedCard.SetCardActive(false);
        Destroy(_holdingCardHolder.gameObject);

    }

    public bool TryAddCardToDeck(CardData newCard)
    {
        if (DeckIsFull())
            return false;

        GameObject newCardUIObj = Instantiate(_CardHolderPrefab, _Deck);
        CardUI cardUI = newCardUIObj.GetComponentInChildren<CardUI>();

        cardUI.SetCardData(newCard);

        return true;
    }
    public bool DeckIsFull()
    {
        if (_Deck.childCount >= _MaxCardsCount)
            return true;
        else
            return false;
    }
    public void RemoveCards(CardData cardData, int quantityToRemove)
    {
        int removedCount = 0;

        for (int i = _Deck.childCount - 1; i >= 0 && removedCount < quantityToRemove; i--)
        {
            RectTransform cardHolder = _Deck.GetChild(i) as RectTransform;
            CardUI cardUI = cardHolder.GetComponentInChildren<CardUI>();
            if (cardUI != null && cardUI._CardData == cardData)
            {
                Destroy(cardHolder.gameObject);
                removedCount++;
            }
        }
    }
    public void RemoveAllCards(params CardData[] cardDataArray)
    {
        for (int i = _Deck.childCount - 1; i >= 0; i--)
        {
            RectTransform cardHolder = _Deck.GetChild(i) as RectTransform;
            CardUI cardUI = cardHolder.GetComponentInChildren<CardUI>();
            if (cardUI != null && cardDataArray.Contains(cardUI._CardData))
            {
                Destroy(cardHolder.gameObject);
            }
        }
    }
}