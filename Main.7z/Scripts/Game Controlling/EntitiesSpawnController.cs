using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class EntitiesSpawnController : MonoBehaviour
{
    public System.Action<string> OnEnemyKilled;

    [SerializeField] private List<GameObject> _ChestsPrefabs;
    [SerializeField] private int _SpawnChestEveryNTurn = 7;

    [Space]
    [SerializeField] private GameObject _DiamondCollectivePrefab;
    [SerializeField] private int _MaxDiamondsOnMap = 3;

    [Space]
    [SerializeField] private List<SpawnData> _EntitiesToSpawn;
    [SerializeField] private List<TeamSpawnLimit> _teamSpawnLimits = new List<TeamSpawnLimit>();

    private int _lastChestSpawnTurn;

    private Dictionary<string, List<GameObject>> _spawnedEntities = new Dictionary<string, List<GameObject>>();
    private Dictionary<string, int> _maxEntitiesPerTeam = new Dictionary<string, int>();
    private List<GameObject> _spawnedDiamonds = new List<GameObject>();

    private TurnController _turnController;
    private MapController _mapController;

    private void Start()
    {
        _turnController = GameManager.Instance.GetComponent<TurnController>();
        _mapController = GameManager.Instance.GetComponent<MapController>();

        foreach (var teamLimit in _teamSpawnLimits)
        {
            _maxEntitiesPerTeam.Add(teamLimit.TeamName, teamLimit.MaxEntities);
        }

        GameObject playerPrefab = CharactersAndCardsUnlockController.Instance.GetCharacter(MainMenuController.Instance.GetSelectedCharacterNameKeyId());
        if(playerPrefab == null)
        {
            playerPrefab = CharactersAndCardsUnlockController.Instance.GetFirstCharacter();
        }

        _mapController.TryToSpawnEntityOnRandomFreeCell(playerPrefab, out GameObject player);
        _spawnedEntities["Player"] = new List<GameObject>
            {
                player
            };

        StartCoroutine(StartSpawning());
        _turnController.SubscribeToTeamTurnStartEvent("Spawn", StartSpawning);
    }

    private IEnumerator StartSpawning()
    {
        RemoveNullEntriesFromSpawnedEntities();

        List<SpawnData> spawnableEntities = _EntitiesToSpawn.FindAll(data =>
        {
            string teamName = data.EntityPrefab.GetComponent<MapEntityTurnController>().TurnTeamName;
            return !_spawnedEntities.ContainsKey(teamName) ||
                   _spawnedEntities[teamName].Count < _maxEntitiesPerTeam[teamName];
        });

        if (spawnableEntities.Count == 0)
        {
            Debug.LogWarning("��� ������� �������� ������ ������.");
            yield break;
        }

        SpawnData randomSpawnData = spawnableEntities[Random.Range(0, spawnableEntities.Count)];
        int spawnCount = Random.Range(randomSpawnData.MinSpawnCount, randomSpawnData.MaxSpawnCount + 1);

        string teamName = randomSpawnData.EntityPrefab.GetComponent<MapEntityTurnController>().TurnTeamName;

        for (int i = 0; i < spawnCount; i++)
        {
            if (_mapController.TryToSpawnEntityOnRandomFreeCell(randomSpawnData.EntityPrefab, out GameObject spawnedEntity))
            {
                if (!_spawnedEntities.ContainsKey(teamName))
                {
                    _spawnedEntities[teamName] = new List<GameObject>();
                }
                _spawnedEntities[teamName].Add(spawnedEntity);
            }

            yield return null;
        }

        if (_turnController.CurrentTurn > _lastChestSpawnTurn + _SpawnChestEveryNTurn)
        {
            _lastChestSpawnTurn = _turnController.CurrentTurn;

            _mapController.TryToSpawnEntityOnRandomFreeCell(_ChestsPrefabs[Random.Range(0,_ChestsPrefabs.Count)]);
        }

        SpawnDiamondCollective();
    }

    public void AddEntityToSpawned(MapEntityTurnController entityTurnController)
    {
        string teamName = entityTurnController.TurnTeamName;

        if (!_spawnedEntities.ContainsKey(teamName))
        {
            _spawnedEntities[teamName] = new List<GameObject>();
        }
        _spawnedEntities[teamName].Add(entityTurnController.gameObject);
    }
    #region GetEntity
    public GameObject GetRandomEntity(params string[] teamNames)
    {
        List<GameObject> potentialEntities = new List<GameObject>();

        if (teamNames == null || teamNames.Length == 0)
        {
            foreach (var entityList in _spawnedEntities.Values)
            {
                potentialEntities.AddRange(entityList);
            }
        }
        else
        {
            foreach (string teamName in teamNames)
            {
                if (_spawnedEntities.ContainsKey(teamName))
                {
                    potentialEntities.AddRange(_spawnedEntities[teamName]);
                }
                else
                {
                    Debug.LogWarning($"������� '{teamName}' �� �������.");
                }
            }
        }
        potentialEntities.RemoveAll(entity => entity == null);

        if (potentialEntities.Count == 0)
        {
            Debug.LogWarning("��� ��������� ��������� ��� ������.");
            return null;
        }
        return potentialEntities[Random.Range(0, potentialEntities.Count)];
    }
    public GameObject GetRandomEntityExclude(params string[] teamNames)
    {
        List<GameObject> potentialEntities = new List<GameObject>();

        if (teamNames == null || teamNames.Length == 0)
        {
            foreach (var entityList in _spawnedEntities.Values)
            {
                potentialEntities.AddRange(entityList);
            }
        }
        else
        {
            foreach (var kvp in _spawnedEntities)
            {
                if (!teamNames.Contains(kvp.Key))
                {
                    potentialEntities.AddRange(kvp.Value);
                }
            }
        }
        potentialEntities.RemoveAll(entity => entity == null);

        if (potentialEntities.Count == 0)
        {
            Debug.LogWarning("��� ��������� ��������� ��� ������.");
            return null;
        }
        return potentialEntities[Random.Range(0, potentialEntities.Count)];
    }
    public GameObject GetRandomEntityExclude(params GameObject[] excludedObjects)
    {
        List<GameObject> potentialEntities = new List<GameObject>();
        foreach (var entityList in _spawnedEntities.Values)
        {
            potentialEntities.AddRange(entityList);
        }
        potentialEntities.RemoveAll(entity => entity == null || excludedObjects.Contains(entity));

        if (potentialEntities.Count == 0)
        {
            Debug.LogWarning("��� ��������� ��������� ��� ������.");
            return null;
        }
        return potentialEntities[Random.Range(0, potentialEntities.Count)];
    }
    public GameObject GetRandomEntityExclude(string[] teamNames = null, GameObject[] excludedObjects = null)
    {
        List<GameObject> potentialEntities = new List<GameObject>();
        foreach (var kvp in _spawnedEntities)
        {
            if (teamNames == null || !teamNames.Contains(kvp.Key))
            {
                potentialEntities.AddRange(kvp.Value);
            }
        }
        potentialEntities.RemoveAll(entity => entity == null || (excludedObjects != null && excludedObjects.Contains(entity)));

        if (potentialEntities.Count == 0)
        {
            Debug.Log("��� ��������� ��������� ��� ������.");
            return null;
        }
        return potentialEntities[Random.Range(0, potentialEntities.Count)];
    }

    public List<GameObject> GetEntitiesByTeam(string teamName)
    {
        if (_spawnedEntities.TryGetValue(teamName, out List<GameObject> entities))
        {
            entities.RemoveAll(entity => entity == null);
            return entities;
        }
        else
        {
            Debug.LogWarning($"������� '{teamName}' �� �������.");
            return new List<GameObject>();
        }
    }
    public List<GameObject> GetEntitiesByTeam(params string[] teamsNames)
    {
        List<GameObject> potentialEntities = new List<GameObject>();

        if (teamsNames == null || teamsNames.Length == 0)
        {
            foreach (var entityList in _spawnedEntities.Values)
            {
                potentialEntities.AddRange(entityList);
            }
        }
        else
        {
            foreach (string teamName in teamsNames)
            {
                if (_spawnedEntities.ContainsKey(teamName))
                {
                    potentialEntities.AddRange(_spawnedEntities[teamName]);
                }
                else
                {
                    Debug.LogWarning($"������� '{teamName}' �� �������.");
                }
            }
        }
        potentialEntities.RemoveAll(entity => entity == null);

        if (potentialEntities.Count == 0)
        {
            Debug.LogWarning("��� ��������� ��������� ��� ������.");
            return null;
        }
        return potentialEntities;
    }

    public List<GameObject> GetEntitiesExcludingTeams(params string[] excludedTeamNames)
    {
        List<GameObject> entities = new List<GameObject>();
        foreach (var kvp in _spawnedEntities)
        {
            if (!excludedTeamNames.Contains(kvp.Key))
            {
                entities.AddRange(kvp.Value);
            }
        }
        entities.RemoveAll(entity => entity == null);

        return entities;
    }
    #endregion

    [ContextMenu("Spawn Last Entity In List")]
    private void SpawnLastEntity()
    {
        SpawnData spawnData = _EntitiesToSpawn[_EntitiesToSpawn.Count - 1];
        int spawnCount = Random.Range(spawnData.MinSpawnCount, spawnData.MaxSpawnCount + 1);

        for (int i = 0; i < spawnCount; i++)
        {
            if (_mapController.TryToSpawnEntityOnRandomFreeCell(spawnData.EntityPrefab, out GameObject spawnedEntity))
            {
                var entityTurnController = spawnedEntity.GetComponent<MapEntityTurnController>();
                string teamName = entityTurnController.TurnTeamName;
                if (!_spawnedEntities.ContainsKey(teamName))
                {
                    _spawnedEntities[teamName] = new List<GameObject>();
                }
                _spawnedEntities[teamName].Add(spawnedEntity);
            }
        }
    }


    private void SpawnDiamondCollective()
    {
        _spawnedDiamonds.RemoveAll(diamond => diamond == null);
        if (_spawnedDiamonds.Count >= _MaxDiamondsOnMap)
        {
            return;
        }
        if (_mapController.TryToSpawnEntityOnRandomFreeCell(_DiamondCollectivePrefab, out GameObject spawnedDiamond))
        {
            _spawnedDiamonds.Add(spawnedDiamond);
        }
    }

    private void RemoveNullEntriesFromSpawnedEntities()
    {
        List<string> keysToRemove = new List<string>();

        foreach (var kvp in _spawnedEntities)
        {
            kvp.Value.RemoveAll(entity => entity == null);
            if (kvp.Value.Count == 0)
            {
                keysToRemove.Add(kvp.Key);
            }
        }
        foreach (var key in keysToRemove)
        {
            _spawnedEntities.Remove(key);
        }
    }


    [System.Serializable]
    public struct TeamSpawnLimit
    {
        public string TeamName;
        public int MaxEntities;
    }
    [System.Serializable]
    public struct SpawnData
    {
        public GameObject EntityPrefab;
        public int MinSpawnCount;
        public int MaxSpawnCount;
    }
}