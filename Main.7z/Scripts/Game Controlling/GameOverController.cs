using BayatGames.SaveGameFree;
using DG.Tweening;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverController : MonoBehaviour
{
    public event Action OnGameOver;

    [Header("Game Over UI")]
    [SerializeField] private RectTransform _gameOverScreen;
    [SerializeField] private RectTransform _giveUpPanel;

    public bool GameIsOver { get; private set; }

    private TurnController _turnController;

    private float lastAdTime = 0;

    private void Start()
    {
        _turnController = GameManager.Instance.GetComponent<TurnController>();
        _giveUpPanel.anchoredPosition = new Vector2(_giveUpPanel.anchoredPosition.x, 200f);
        _giveUpPanel.gameObject.SetActive(false);
    }

    private void OnApplicationQuit()
    {
        SaveScore();
    }

    public void OpenGiveUpPanel()
    {
        if (_giveUpPanel.gameObject.activeSelf == true) return;

        _giveUpPanel.gameObject.SetActive(true);
        _giveUpPanel.DOAnchorPosY(-120f, 1).SetEase(Ease.OutQuad);
    }

    public void CloseGiveUpPanel()
    {
        if (_giveUpPanel.gameObject.activeSelf == false) return;

        _giveUpPanel.DOAnchorPosY(200f, 1).SetEase(Ease.InQuad)
            .OnComplete(() => _giveUpPanel.gameObject.SetActive(false));
    }

    public void GiveUp()
    {
        CloseGiveUpPanel();
        GameOver();
    }

    public void GameOver()
    {
        GameIsOver = true;

        _turnController.CancelTurnsCycle();

        SaveScore();
        OpenGameOverScreen();
        if (Time.time - lastAdTime >= 120f && ShopController.Instance.GetProductPurchaseStatus("removeads") == false)
        {
            AdMobManager.Instance.ShowInterstitialAd();
            lastAdTime = Time.time;
        }

        OnGameOver?.Invoke();
    }

    public void SaveScore()
    {
        LevelsManager.Instance.TrySetBestScore(SceneManager.GetActiveScene().name, _turnController.CurrentTurn);
    }

    private void OpenGameOverScreen()
    {
        _gameOverScreen.localScale = Vector3.zero;
        _gameOverScreen.gameObject.SetActive(true);

        _gameOverScreen.DOScale(Vector3.one, 0.7f).SetEase(Ease.OutBack);
    }
}