using BayatGames.SaveGameFree;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelsManager : MonoBehaviour
{
    public static LevelsManager Instance { get; private set; }

    [SerializeField] private List<LevelSelectiveInfoData> _Levels;

    private const string LEVELSSAVE_KEY = "levelsdatas";

    private List<LevelSaveData> _levelsDatas = new List<LevelSaveData>();

    private void Awake()
    {
        Instance = this;

        LoadLevelsData();
        foreach (var level in _Levels)
        {
            if (!_levelsDatas.Exists(data => data.LevelKey == level.LevelKey))
            {
                _levelsDatas.Add(new LevelSaveData(level.LevelKey, level.InitiallyUnlocked, 0));
            }
        }
        _levelsDatas.RemoveAll(data => !_Levels.Exists(level => level.LevelKey == data.LevelKey));

        SaveLevelsData();
    }

    private void LoadLevelsData()
    {
        if (SaveGame.Exists(LEVELSSAVE_KEY))
        {
            _levelsDatas = SaveGame.Load(LEVELSSAVE_KEY, new List<LevelSaveData>());
        }
        else
        {
            _levelsDatas = new List<LevelSaveData>();
        }
    }

    private void SaveLevelsData()
    {
        SaveGame.Save(LEVELSSAVE_KEY, _levelsDatas);
    }

    public bool IsLevelUnlocked(string levelKey)
    {
        var levelData = _levelsDatas.Find(data => data.LevelKey == levelKey);
        return levelData.IsUnlocked;
    }

    public void UnlockLevel(string levelKey)
    {
        int index = _levelsDatas.FindIndex(data => data.LevelKey == levelKey);
        if (index != -1 && !_levelsDatas[index].IsUnlocked)
        {
            LevelSaveData updatedData = _levelsDatas[index];
            updatedData.IsUnlocked = true;
            _levelsDatas[index] = updatedData;

            SaveLevelsData();
        }
    }
    public void UnlockAllLevels()
    {
        for (int i = 0; i < _levelsDatas.Count; i++)
        {
            if (!_levelsDatas[i].IsUnlocked)
            {
                _levelsDatas[i] = new LevelSaveData(_levelsDatas[i].LevelKey, true, _levelsDatas[i].BestScore);
            }
        }

        SaveLevelsData();
    }

    public int GetBestScore(string levelKey)
    {
        var levelData = _levelsDatas.Find(data => data.LevelKey == levelKey);
        return levelData.BestScore;
    }

    public bool TrySetBestScore(string levelKey, int score)
    {
        int index = _levelsDatas.FindIndex(data => data.LevelKey == levelKey);
        if (index != -1 && score > _levelsDatas[index].BestScore)
        {
            LevelSaveData updatedData = _levelsDatas[index];
            updatedData.BestScore = score;
            _levelsDatas[index] = updatedData;

            SaveLevelsData();

            return true;
        }

        return false;
    }

    [ContextMenu("Reset Levels Saves")]
    public void ResetLevelsSaves()
    {
        for (int i = 0; i < _levelsDatas.Count; i++)
        {
            var levelInfo = _Levels.Find(level => level.LevelKey == _levelsDatas[i].LevelKey);
            bool initiallyUnlocked = levelInfo != null && levelInfo.InitiallyUnlocked;
            _levelsDatas[i] = new LevelSaveData(_levelsDatas[i].LevelKey, initiallyUnlocked, 0);
        }
        SaveLevelsData();
    }
}

[System.Serializable]
public struct LevelSaveData
{
    public string LevelKey;
    public bool IsUnlocked;
    public int BestScore;

    public LevelSaveData(string levelKey, bool isUnlocked, int bestScore)
    {
        LevelKey = levelKey;
        IsUnlocked = isUnlocked;
        BestScore = bestScore;
    }
}