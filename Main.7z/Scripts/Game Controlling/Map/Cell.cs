using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cell : MonoBehaviour
{
    [field:SerializeField] public GameObject Occupant {  get; private set; }

    public bool TryToChangeOccupant(GameObject newOccupant)
    {
        if (Occupant != null && newOccupant != null)
        {
            return false;
        }

        Occupant = newOccupant;
        return true;
    }
}