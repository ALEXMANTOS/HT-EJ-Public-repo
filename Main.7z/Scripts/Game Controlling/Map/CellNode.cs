using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CellNode
{
    public Cell cell;
    public CellNode Parent;
    public float gCost;
    public float hCost;
    public float FCost => gCost + hCost;

    public CellNode(Cell cell, CellNode parent, float gCost, float hCost)
    {
        this.cell = cell;
        Parent = parent;
        this.gCost = gCost;
        this.hCost = hCost;
    }

}