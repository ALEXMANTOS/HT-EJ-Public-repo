using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class MapController : MonoBehaviour
{
    [SerializeField] private Transform _MapParent;
    [SerializeField] private List<GameObject> _CellPrefabs;

    [Space]
    [SerializeField] private bool _CustomMap;
    [SerializeField] private int _GridWidth;
    [SerializeField] private int _GridHeight;

    private List<Cell> _map = new List<Cell>();

    private void Awake()
    {
        if (_CustomMap)
        {
            for (int i = 0; i < _MapParent.transform.childCount; i++)
            {
                _map.Add(_MapParent.transform.GetChild(i).GetComponent<Cell>());
            }
        }
        else
        {
            CreateMap();
        }
    }

    private void CreateMap()
    {
        float startX = -(_GridWidth - 1) / 2f;
        float startY = -(_GridHeight - 1) / 2f;

        for (int x = 0; x < _GridWidth; x++)
        {
            for (int y = 0; y < _GridHeight; y++)
            {
                GameObject cellGO = Instantiate(_CellPrefabs[Random.Range(0,_CellPrefabs.Count)], _MapParent);

                cellGO.transform.position = new Vector2(startX + x, startY + y);
                _map.Add(cellGO.GetComponent<Cell>());
            }
        }
    }
    [ContextMenu("Create Cells")]
    private void CreateCells()
    {
        float startX = -(_GridWidth - 1) / 2f;
        float startY = -(_GridHeight - 1) / 2f;

        for (int x = 0; x < _GridWidth; x++)
        {
            for (int y = 0; y < _GridHeight; y++)
            {
                GameObject cellGO = Instantiate(_CellPrefabs[Random.Range(0, _CellPrefabs.Count)], _MapParent);

                cellGO.transform.position = new Vector2(startX + x, startY + y);
            }
        }
    }

    public bool TryToChangeEntityCell(GameObject entity,Cell fromCell, Cell toCell)
    {
        if (toCell != null && toCell.TryToChangeOccupant(entity))
        {
            fromCell?.TryToChangeOccupant(null);
            return true;
        }
        else
        {
            return false;
        }
    }
    public void ClearCellOccupant(Cell cell)
    {
        cell.TryToChangeOccupant(null);
    }

    #region GetCells
    public List<Cell> GetMap()
    {
        return _map;
    }
    public List<Cell> GetRandomCells(int numberOfCells)
    {
        if (_map.Count == 0) return null;

        List<Cell> mapCopy = new List<Cell>(_map);
        List<Cell> selectedCells = new List<Cell>();
        for (int i = 0; i < numberOfCells; i++)
        {
            int randomIndex = Random.Range(0, mapCopy.Count);
            selectedCells.Add(mapCopy[randomIndex]);
            mapCopy.RemoveAt(randomIndex);
        }

        return selectedCells;
    }

    public List<Cell> GetRandomFreeCells(int numberOfCells)
    {
        List<Cell> freeCells = _map.Where(cell => cell.Occupant == null).ToList();
        if (freeCells.Count <= numberOfCells)
            return freeCells;

        List<Cell> selectedCells = new List<Cell>();
        for (int i = 0; i < numberOfCells; i++)
        {
            int randomIndex = Random.Range(0, freeCells.Count);
            selectedCells.Add(freeCells[randomIndex]);
            freeCells.RemoveAt(randomIndex);
        }

        return selectedCells;
    }
    public Cell GetCellAtPosition(Vector2 position)
    {
        Cell cell = _map.Find(c => (Vector2)c.transform.position == position);
        return cell;
    }
    public List<Cell> GetCellsOnSameLineX(Cell playerCell)
    {
        List<Cell> cellsOnLineX = new List<Cell>();
        foreach (Cell cell in _map)
        {
            if (cell.transform.position.x == playerCell.transform.position.x)
            {
                cellsOnLineX.Add(cell);
            }
        }

        return cellsOnLineX;
    }

    public List<Cell> GetCellsOnSameLineY(Cell playerCell)
    {
        List<Cell> cellsOnLineY = new List<Cell>();
        foreach (Cell cell in _map)
        {
            if (cell.transform.position.y == playerCell.transform.position.y)
            {
                cellsOnLineY.Add(cell);
            }
        }

        return cellsOnLineY;
    }

    public List<Cell> GetNeighborCells(Cell cell)
    {
        List<Cell> neighbors = new List<Cell>();

        if (cell == null) return neighbors;
        Vector2 currentPosition = (Vector2)cell.transform.position;
        Vector2[] directions = {
        new Vector2(0, 1),
        new Vector2(0, -1),
        new Vector2(-1, 0),
        new Vector2(1, 0)
    };

        foreach (Vector2 direction in directions)
        {
            Vector2 neighborPosition = currentPosition + direction;
            Cell neighborCell = GetCellAtPosition(neighborPosition);
            if (neighborCell != null)
            {
                neighbors.Add(neighborCell);
            }
        }

        return neighbors;
    }

    #endregion

    #region Spawning
    public bool TryToSpawnEntity(GameObject entityPrefab, Cell cell)
    {
        if (cell.Occupant != null)
            return false;

        GameObject entity = Instantiate(entityPrefab);
        entity.transform.position = cell.transform.position;

        return TryToChangeEntityCell(entity,null,cell);
    }
    public bool TryToSpawnEntity(GameObject entityPrefab, Cell cell,out GameObject spawnedGO)
    {
        if (cell.Occupant != null)
        {
            spawnedGO = null;
            return false;
        }

        GameObject entity = Instantiate(entityPrefab);
        entity.transform.position = cell.transform.position;

        spawnedGO = entity;
        return TryToChangeEntityCell(entity, null, cell);
    }

    public bool TryToSpawnEntity(GameObject entityPrefab, Vector2 cellPosition)
    {
        Cell cell = GetCellAtPosition(cellPosition);

        if (cell.Occupant != null)
            return false;

        GameObject entity = Instantiate(entityPrefab);
        entity.transform.position = cell.transform.position;

        return TryToChangeEntityCell(entity, null, cell);
    }
    public bool TryToSpawnEntity(GameObject entityPrefab, Vector2 cellPosition, out GameObject spawnedGO)
    {
        Cell cell = GetCellAtPosition(cellPosition);

        if (cell.Occupant != null)
        {
            spawnedGO = null;
            return false;
        }

        GameObject entity = Instantiate(entityPrefab);
        entity.transform.position = cell.transform.position;

        spawnedGO = entity;
        return TryToChangeEntityCell(entity, null, cell);
    }

    public bool TryToSpawnEntityOnRandomFreeCell(GameObject entityPrefab)
    {
        List<Cell> freeCells = _map.FindAll(c => c.Occupant == null);

        if (freeCells.Count == 0)
            return false;

        Cell randomCell = freeCells[Random.Range(0, freeCells.Count)];

        if (randomCell == null)
            return false;

        GameObject entity = Instantiate(entityPrefab);
        entity.transform.position = randomCell.transform.position;

        return TryToChangeEntityCell(entity, null, randomCell);
    }
    public bool TryToSpawnEntityOnRandomFreeCell(GameObject entityPrefab, out GameObject spawnedGO)
    {
        List<Cell> freeCells = _map.FindAll(c => c.Occupant == null);

        Cell randomCell = null;
        if (freeCells.Count > 0)
        {
            randomCell = freeCells[Random.Range(0, freeCells.Count)];
        }

        if (randomCell == null)
        {
            spawnedGO = null;
            return false;
        }

        GameObject entity = Instantiate(entityPrefab);
        entity.transform.position = randomCell.transform.position;

        spawnedGO = entity;
        return TryToChangeEntityCell(entity, null, randomCell);
    }

    #endregion

    #region PathFinding
    public List<Cell> FindPath(Cell startCell, Cell targetCell)
    {
        List<CellNode> openSet = new List<CellNode>();
        HashSet<CellNode> closedSet = new HashSet<CellNode>();
        Dictionary<Cell, CellNode> allNodes = new Dictionary<Cell, CellNode>();

        CellNode startNode = new CellNode(startCell, null, 0, GetDistance(startCell, targetCell));
        openSet.Add(startNode);
        allNodes[startCell] = startNode;

        while (openSet.Count > 0)
        {
            CellNode currentNode = openSet[0];
            for (int i = 1; i < openSet.Count; i++)
            {
                if (openSet[i].FCost < currentNode.FCost ||
                    (openSet[i].FCost == currentNode.FCost && openSet[i].hCost < currentNode.hCost))
                {
                    currentNode = openSet[i];
                }
            }

            openSet.Remove(currentNode);
            closedSet.Add(currentNode);
            if (currentNode.cell == targetCell)
            {
                return RetracePath(startNode, currentNode);
            }
            foreach (Cell neighborCell in GetNeighborCells(currentNode.cell))
            {
                if (closedSet.Contains(allNodes.ContainsKey(neighborCell) ? allNodes[neighborCell] : null))
                    continue;
                if (IsObstacle(neighborCell) && neighborCell != targetCell)
                    continue;

                float newCostToNeighbor = currentNode.gCost + GetDistance(currentNode.cell, neighborCell);
                if (!allNodes.ContainsKey(neighborCell))
                {
                    CellNode neighborNode = new CellNode(neighborCell, currentNode, newCostToNeighbor, GetDistance(neighborCell, targetCell));
                    allNodes[neighborCell] = neighborNode;
                }

                CellNode neighbor = allNodes[neighborCell];
                if (newCostToNeighbor < neighbor.gCost || !openSet.Contains(neighbor))
                {
                    neighbor.gCost = newCostToNeighbor;
                    neighbor.hCost = GetDistance(neighbor.cell, targetCell);
                    neighbor.Parent = currentNode;
                    if (!openSet.Contains(neighbor))
                    {
                        openSet.Add(neighbor);
                    }
                }
            }
        }
        return null;
    }

    private List<Cell> RetracePath(CellNode startNode, CellNode endNode)
    {
        List<Cell> path = new List<Cell>();
        CellNode currentNode = endNode;

        while (currentNode != startNode)
        {
            path.Add(currentNode.cell);
            currentNode = currentNode.Parent;
        }

        path.Reverse();
        return path;
    }

    private bool IsObstacle(Cell cell)
    {
        return cell.Occupant != null;
    }

    private float GetDistance(Cell a, Cell b)
    {
        return Vector2.Distance(a.transform.position, b.transform.position);
    }
    #endregion

    public Vector2 GetMapSize()
    {
        return new Vector2(_GridWidth,_GridHeight);
    }
}