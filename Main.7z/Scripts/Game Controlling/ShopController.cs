using BayatGames.SaveGameFree;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Purchasing;
using UnityEngine.UI;

public class ShopController : MonoBehaviour
{
    public static ShopController Instance { get; private set; }

    [SerializeField] private CodelessIAPButton _RemoveAdsIAPButton;
    [SerializeField] private CodelessIAPButton _UnlockAllContentIAPButton;

    private Dictionary<string, bool> _productsPurchaseStatuses = new Dictionary<string, bool>();
    private const string NC_PRODUCTS_SAVE_KEY = "ncproducts";

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

        LoadProductPurchaseStatus();
        SetNonConsumableButtonStatus(_RemoveAdsIAPButton);
        SetNonConsumableButtonStatus(_UnlockAllContentIAPButton);
    }


    public bool GetProductPurchaseStatus(string productID)
    {
        _productsPurchaseStatuses.TryGetValue(productID, out bool isPurchased);
        return isPurchased;
    }

    public void UnlockAllContent(Product product)
    {
        Debug.Log("All content unlocked!");

        UnlockAllController.Instance.UnlockAll();

        SaveProductPurchaseStatus(product.definition.id, true);
        SetNonConsumableButtonStatus(_UnlockAllContentIAPButton);
    }
    public void RemoveAds(Product product)
    {
        Debug.Log("Ads removed!");

        SaveProductPurchaseStatus(product.definition.id, true);
        SetNonConsumableButtonStatus(_RemoveAdsIAPButton);
    }
    public void BuyRubies(Product product)
    {
        int rubiesToAdd = (int)product.definition.payout.quantity;
        CurrencyController.Instance.AddRubies(rubiesToAdd);
    }

    public void ShowRewardedAd()
    {
        AdMobManager.Instance.ShowRewardedAd();
    }


    private void SetNonConsumableButtonStatus(CodelessIAPButton iapButton)
    {
        if (_productsPurchaseStatuses.TryGetValue(iapButton.productId, out bool isPurchased) && isPurchased)
        {
            iapButton.button.interactable = false;
        }
        else
        {
            Product product = GetProductById(iapButton.productId);
            if (product != null && product.hasReceipt)
            {
                iapButton.button.interactable = false;
                SaveProductPurchaseStatus(iapButton.productId, true);
            }
        }
    }
    private Product GetProductById(string productId)
    {
        IStoreController storeController = CodelessIAPStoreListener.Instance.StoreController;
        if (storeController != null)
        {
            return storeController.products.WithID(productId);
        }

        return null;
    }


    private void SaveProductPurchaseStatus(string productId, bool isPurchased)
    {
        _productsPurchaseStatuses[productId] = isPurchased;

        SaveGame.Save(NC_PRODUCTS_SAVE_KEY, _productsPurchaseStatuses);
    }
    private void LoadProductPurchaseStatus()
    {
        if (SaveGame.Exists(NC_PRODUCTS_SAVE_KEY))
        {
            _productsPurchaseStatuses = SaveGame.Load(NC_PRODUCTS_SAVE_KEY, new Dictionary<string, bool>());
        }
        else
        {
            CheckPurchasedNonConsumableItems();
        }
    }

    private void CheckPurchasedNonConsumableItems()
    {
        IStoreController storeController = CodelessIAPStoreListener.Instance.StoreController;
        if (storeController != null)
        {
            foreach (var product in storeController.products.all)
            {
                if (product.definition.type == ProductType.NonConsumable && product.hasReceipt)
                {
                    SaveProductPurchaseStatus(product.definition.id, true);
                }
                else
                {
                    SaveProductPurchaseStatus(product.definition.id, false);
                }
            }
        }
    }

    [ContextMenu("Reset Products Saves")]
    public void ResetProductsSaves()
    {
        _productsPurchaseStatuses = new Dictionary<string, bool>();
        SaveGame.Save(NC_PRODUCTS_SAVE_KEY, _productsPurchaseStatuses);
    }
}