using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UIElements;

public class TurnController : MonoBehaviour
{
    public event Action<string> OnNewTurnStarted;
    public event Action OnNewGameTurnStarted;

    [SerializeField] private List<string> _TeamsNames;
    [SerializeField] private float _TimeBetweenTurns;

    private Dictionary<string, List<Func<IEnumerator>>> _turnsStartEvents = new Dictionary<string, List<Func<IEnumerator>>>();
    private Queue<string> _teamTurnQueue = new Queue<string>();

    public int CurrentTurn { get; private set; } = 0;

    private bool _turnsCyclePaused;

    private void Awake()
    {
        foreach(var teamName in _TeamsNames)
        {
            _turnsStartEvents.Add(teamName,new List<Func<IEnumerator>>());
            _teamTurnQueue.Enqueue(teamName);
        }

        StartCoroutine(TurnsHandler());
    }

    public void CancelTurnsCycle()
    {
        StopAllCoroutines();
    }
    public void StopTurnsCycle()
    {
        _turnsCyclePaused = true;
    }
    public void ResumeTurnsCycle()
    {
        _turnsCyclePaused = false;
    }

    public void SubscribeToTeamTurnStartEvent(string teamName, Func<IEnumerator> coroutineFactory)
    {
        if (!_turnsStartEvents.ContainsKey(teamName))
        {
            Debug.LogError("��� �������� �� �����, ���� ������� ������������ ��� �������(��� ��� �� �������� � TurnController)");
            return;
        }
        _turnsStartEvents[teamName].Add(coroutineFactory);
    }
    public void UnsubscribeFromTeamTurnStartEvent(string teamName, Func<IEnumerator> coroutineFactory)
    {
        if (!_turnsStartEvents.ContainsKey(teamName))
        {
            Debug.LogError("��� ������� �� ������, ���� ������� ������������ ��� ������� (��� ��� �� �������� � TurnController)");
            return;
        }

        if (_turnsStartEvents[teamName].Contains(coroutineFactory))
        {
            _turnsStartEvents[teamName].Remove(coroutineFactory);
        }
        else
        {
            Debug.LogWarning("�������� �� ����� � ������ ��� ��������.");
        }
    }

    private IEnumerator TriggerTurnEvent(string teamName)
    {
        if (_turnsStartEvents.ContainsKey(teamName))
        {
            List<Coroutine> activeCoroutines = new List<Coroutine>();
            List<Func<IEnumerator>> toRemove = new List<Func<IEnumerator>>();
            List<Func<IEnumerator>> coroutineFuncs = new List<Func<IEnumerator>>(_turnsStartEvents[teamName]);

            foreach (var coroutineFunc in coroutineFuncs)
            {
                if (coroutineFunc != null)
                {
                    Coroutine coroutine = StartCoroutine(coroutineFunc());
                    activeCoroutines.Add(coroutine);
                }
                else
                {
                    toRemove.Add(coroutineFunc);
                }
            }
            foreach (var func in toRemove)
            {
                _turnsStartEvents[teamName].Remove(func);
            }
            foreach (var activeCoroutine in activeCoroutines)
            {
                yield return activeCoroutine;
            }
        }
    }
    
    private IEnumerator TurnsHandler()
    {
        while (true)
        {
            if (_turnsCyclePaused)
            {
                yield return new WaitUntil(() => _turnsCyclePaused == false);
            }

            if(_teamTurnQueue.Peek() == _TeamsNames[0])
            {
                CurrentTurn++;
                OnNewGameTurnStarted?.Invoke();
            }

            float timeToNextTurn = _TimeBetweenTurns;

            if (_teamTurnQueue.Count > 0)
            {
                string currentTeam = _teamTurnQueue.Dequeue();

                var events = StartCoroutine(TriggerTurnEvent(currentTeam));
                OnNewTurnStarted?.Invoke(currentTeam);

                if(events == null)
                {
                    timeToNextTurn = 0.1f;
                }

                yield return events;

                _teamTurnQueue.Enqueue(currentTeam);
            }

            yield return new WaitForSeconds(timeToNextTurn);
        }
    }
}