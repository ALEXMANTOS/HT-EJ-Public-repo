using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

[RequireComponent(typeof(TurnController), typeof(MapController))]
public class ArrowsLevelController : MonoBehaviour
{
    [SerializeField] private Bullet _ArrowPrefab;
    [SerializeField] private float _ArrowDamage;
    [SerializeField] private BulletProperties _ArrowProperties;
    [SerializeField] private int _SpawnDistance;
    [SerializeField] private int _TargetsCount;

    [Space]
    [SerializeField] private GameObject _WarningSignPrefab;

    private TurnController _turnController;
    private MapController _mapController;

    private List<ArrowLine> _arrowLines = new();
    private List<GameObject> _activeWarningSigns = new();

    private void Start()
    {
        _turnController = GetComponent<TurnController>();
        _mapController = GetComponent<MapController>();

        _turnController.OnNewGameTurnStarted += OnNewTurnStarted;
    }

    private void OnNewTurnStarted()
    {
        if (_arrowLines.Count > 0)
        {
            Shoot();
        }

        FindNewShootLines();
    }

    private void Shoot()
    {
        foreach (var targetLine in _arrowLines)
        {
            Vector2 spawnPosition = -targetLine.Direction * _SpawnDistance;
            spawnPosition += targetLine.TargetPosition;

            CreateArrow(spawnPosition, targetLine.Direction);
        }
        foreach (var sign in _activeWarningSigns)
        {
            FadeOutWarningSign(sign);
        }
        _activeWarningSigns.Clear();
    }

    private void CreateArrow(Vector2 spawnPosition, Vector2 direction)
    {
        Bullet arrow = LeanPool.Spawn(_ArrowPrefab, spawnPosition, Quaternion.identity);

        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        arrow.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));

        arrow.InitBullet(_ArrowDamage, _ArrowProperties, gameObject);
    }

    private Vector2 GetShootDirection()
    {
        int directionIndex = Random.Range(0, 3);

        switch (directionIndex)
        {
            case 0: return Vector2.up;
            case 1: return Vector2.left;
            case 2: return Vector2.right;
            default: return Vector2.zero;
        }
    }

    private void FindNewShootLines()
    {
        var map = _mapController.GetMap();

        _arrowLines.Clear();
        HashSet<Vector2> usedPositions = new();

        foreach (var target in map)
        {
            Vector2 direction = GetShootDirection();
            Vector2 currentPosition = target.transform.position;
            Vector2 targetPosition = FindFurthestCellInDirection(currentPosition, direction);
            if (usedPositions.Contains(targetPosition))
            {
                continue;
            }

            usedPositions.Add(targetPosition);
            ArrowLine targetLine = new ArrowLine
            {
                TargetPosition = targetPosition,
                Direction = -direction
            };
            DOVirtual.DelayedCall(0.2f, () => CreateWarningSign(targetPosition));

            _arrowLines.Add(targetLine);
            if (_arrowLines.Count >= _TargetsCount)
            {
                break;
            }
        }
    }

    private Vector2 FindFurthestCellInDirection(Vector2 startPosition, Vector2 direction)
    {
        Vector2 currentPosition = startPosition;
        while (_mapController.GetCellAtPosition(currentPosition + direction) != null)
        {
            currentPosition += direction;
        }
        currentPosition += direction;

        return currentPosition;
    }

    private void CreateWarningSign(Vector2 position)
    {
        GameObject warningSign = LeanPool.Spawn(_WarningSignPrefab, position, Quaternion.identity);

        _activeWarningSigns.Add(warningSign);
        SpriteRenderer spriteRenderer = warningSign.GetComponent<SpriteRenderer>();
        spriteRenderer.DOFade(1, 0);
        spriteRenderer.DOFade(0.2f, 1f).SetLoops(-1, LoopType.Yoyo).SetEase(Ease.InOutSine);
    }

    private void FadeOutWarningSign(GameObject warningSign)
    {
        SpriteRenderer spriteRenderer = warningSign.GetComponent<SpriteRenderer>();
        spriteRenderer.DOFade(0f, 0.5f).OnComplete(() =>
        {
            LeanPool.Despawn(warningSign);
        });
    }

    private struct ArrowLine
    {
        public Vector2 TargetPosition;
        public Vector2 Direction;
    }
}