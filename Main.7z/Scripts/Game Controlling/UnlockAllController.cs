using UnityEngine;

public class UnlockAllController : MonoBehaviour
{
    public static UnlockAllController Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        if (ShopController.Instance.GetProductPurchaseStatus("unlockallcontent"))
        {
            UnlockAll();
        }
    }

    public void UnlockAll()
    {
        CharactersAndCardsUnlockController.Instance.UnlockAllCards();
        CharactersAndCardsUnlockController.Instance.UnlockAllCharacters();
        LevelsManager.Instance.UnlockAllLevels();

        var characterAndCardSelectiveUIs = FindObjectsByType<CharacterAndCardSelectiveUI>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (var ui in characterAndCardSelectiveUIs)
        {
            ui.UnlockSelectiveUI();
        }

        var levelSelectButtons = FindObjectsByType<LevelSelectButton>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        foreach (var button in levelSelectButtons)
        {
            button.UnlockButton();
        }
    }
}