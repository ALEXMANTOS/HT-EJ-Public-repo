using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class AllyTurret : MonoBehaviour, IMapEntityTurnMover, IMapEntityInteractable, IMapEntityAttack
{
    [field: SerializeField] public int MovePriority { get; private set; }
    [field: SerializeField] public float TimeToNextMove { get; private set; }

    [Space]
    [SerializeField] private GameObject _ProjectilePrefab;
    [SerializeField] private GameObject _ReticlePrefab;
    [SerializeField] private TMP_Text _TurnsText;

    [field: Space]
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }
    [SerializeField] private Transform _SpawnPosition;
    [SerializeField] private int _ShootsCount;
    [SerializeField] private float _ShootDelay;
    [SerializeField] private float _ProjectileDuration = 1f;
    [SerializeField] private int _LiveTimeTurns = 5;

    [Space]
    [SerializeField] private Transform _TurretTop;
    [SerializeField] private float _RecoilDistance = 0.2f;
    [SerializeField] private float _RecoilDuration = 0.1f;

    private Vector3 _turretTopInitialPosition;

    private EntityHealth _target;
    private int _currentTurns;
    private GameObject _reticleInstance;
    private bool _isDestroying;
    private bool _reticleInAnimation;

    private EntitiesSpawnController _entitiesSpawnController;

    private void Start()
    {
        _turretTopInitialPosition = _TurretTop.localPosition;
        _entitiesSpawnController = GameManager.Instance.GetComponent<EntitiesSpawnController>();

        _reticleInstance = Instantiate(_ReticlePrefab, transform.position, Quaternion.identity);
        UpdateTurnsText();
    }
    private void Update()
    {
        if (_isDestroying) return;

        if (_target == null)
        {
            FindRandomTarget();
        }

        UpdateReticlePosition();
        UpdateTurretRotation();
    }

    public bool TryDoMove()
    {
        _currentTurns++;
        UpdateTurnsText();
        
        if (_target != null)
        {
            int completedShots = 0;

            for (int i = 0; i < _ShootsCount; i++)
            {
                DOVirtual.DelayedCall(_ShootDelay * i, () =>
                {
                    ShootAtTarget(() =>
                    {
                        completedShots++;
                        if (completedShots == _ShootsCount)
                        {
                            if (_currentTurns >= _LiveTimeTurns)
                            {
                                DestroyTower();
                            }
                        }
                    });
                });
            }
        }
        else if(_currentTurns >= _LiveTimeTurns)
        {
            DestroyTower();
        }

        return true;
    }
    public bool TryInteract()
    {
        if (_isDestroying) return false;

        string[] excludeTeams = { "Obstacle","Player","Ally"};
        List<GameObject> excludeGOs = new List<GameObject>();
        if (_target != null)
        {
            excludeGOs.Add(_target.gameObject);
            var newTarget = _entitiesSpawnController.GetRandomEntityExclude(excludeTeams, excludeGOs.ToArray())?.GetComponent<EntityHealth>();

            if (newTarget != null)
            {
                _target = newTarget;
            }
        }

        if (_target == null)
        {
            return false;
        }

        return true;
    }


    private void FindRandomTarget()
    {
        _target = _entitiesSpawnController.GetRandomEntityExclude("Obstacle", "Player", "Ally")?.GetComponent<EntityHealth>();

        if(_target == null && _reticleInstance.activeSelf == true && _reticleInAnimation == false)
        {
            _reticleInAnimation = true;
            _reticleInstance.transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() => { _reticleInstance.SetActive(false); _reticleInAnimation = false; });
        }
        else if(_target != null && _reticleInstance.activeSelf == false && _reticleInAnimation == false)
        {
            _reticleInAnimation = true;
            _reticleInstance.SetActive(true);
            _reticleInstance.transform.DOScale(1, 0.5f).SetEase(Ease.InBack).OnComplete(() => { _reticleInAnimation = false; });
        }
    }

    private void UpdateReticlePosition()
    {
        if (_target != null && _reticleInstance != null)
        {
            _reticleInstance.transform
                .DOMove(_target.transform.position, 0.1f)
                .SetEase(Ease.Linear);
        }
    }

    private void UpdateTurnsText()
    {
        if (_TurnsText != null)
        {
            _TurnsText.text = $"{_LiveTimeTurns - _currentTurns}";
        }
    }

    private void UpdateTurretRotation()
    {
        if (_target != null && _TurretTop != null)
        {
            Vector3 direction = (_target.transform.position - _TurretTop.position).normalized;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            if (_target.transform.position.x < _TurretTop.position.x)
            {
                _TurretTop.localScale = new Vector3(_TurretTop.localScale.x, Mathf.Abs(_TurretTop.localScale.y), _TurretTop.localScale.z);
            }
            else
            {
                _TurretTop.localScale = new Vector3(_TurretTop.localScale.x, -Mathf.Abs(_TurretTop.localScale.y), _TurretTop.localScale.z);
            }
            _TurretTop.rotation = Quaternion.Euler(0, 0, angle + 180);
        }
    }

    private void ShootAtTarget(System.Action onComplete = null)
    {
        if (_target != null)
        {
            Vector3 spawnPosition = _SpawnPosition.position;
            GameObject projectileInstance = LeanPool.Spawn(_ProjectilePrefab, spawnPosition, Quaternion.identity);
            AnimateRecoil();

            projectileInstance.transform
                .DOMove(_target.transform.position, _ProjectileDuration)
                .SetEase(Ease.Linear)
                .OnComplete(() =>
                {
                    _target?.ApplyDamage(Damage);
                    LeanPool.Despawn(projectileInstance);

                    onComplete?.Invoke();
                });
        }
    }

    private void AnimateRecoil()
    {
        if (_TurretTop != null)
        {
            _TurretTop.DOLocalMove(_turretTopInitialPosition - _TurretTop.up * _RecoilDistance, _RecoilDuration / 2)
                .SetEase(Ease.OutQuad)
                .OnComplete(() =>
                {
                    _TurretTop.DOLocalMove(_turretTopInitialPosition, _RecoilDuration / 2)
                        .SetEase(Ease.InQuad);
                });
        }
    }

    private void DestroyTower()
    {
        _isDestroying = true;

        _reticleInstance.transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() => Destroy(_reticleInstance));
        transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() => Destroy(gameObject));
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(_SpawnPosition.position, 0.1f);
    }
}