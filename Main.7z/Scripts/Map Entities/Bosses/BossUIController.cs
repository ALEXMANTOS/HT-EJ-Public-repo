using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(EntityHealth))]
public class BossUIController : MonoBehaviour
{
    [SerializeField] private Slider _HPSlider;
    [SerializeField] private TMP_Text _HPText;

    [Space]
    [SerializeField] private Canvas _BossCanvas;

    private EntityHealth _hp;

    private void Awake()
    {
        _hp = GetComponent<EntityHealth>();
        _hp.OnHPChanged += UpdateHP;
    }

    private void Start()
    {
        _HPSlider.maxValue = _hp._MaxHealth;

        _BossCanvas.transform.SetParent(null);

        UpdateHP(_hp._CurrentHealth);
    }

    private void OnDisable()
    {
        if(_BossCanvas != null)
        {
            Destroy(_BossCanvas.gameObject);
        }
    }

    private void UpdateHP(float hp)
    {
        _HPSlider.value = hp;
        _HPText.text = hp % 1 == 0
        ? $"{(int)hp}/{_hp._MaxHealth}" : $"{hp:F1}/{_hp._MaxHealth}";
    }
}