using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class CellMovingEntity : MonoBehaviour
{
    [SerializeField] private float _MoveDuration = 0.5f;
    [SerializeField] private Ease _MoveEaseType = Ease.OutCubic;
    [SerializeField] private float _FlipDuration = 0.15f;
    [SerializeField] private float _RotationAngle = 8f;
    public float MoveDuration
    {
        get => _MoveDuration;
        protected set => _MoveDuration = value;
    }

    public Ease MoveEaseType
    {
        get => _MoveEaseType;
        protected set => _MoveEaseType = value;
    }

    public float FlipDuration
    {
        get => _FlipDuration;
        protected set => _FlipDuration = value;
    }

    public float RotationAngle
    {
        get => _RotationAngle;
        protected set => _RotationAngle = value;
    }


    protected bool _animateMovement = true;
    protected bool _canMove = true;

    protected Cell _currentCell;

    protected MapController _mapController;

    protected void Start()
    {
        _mapController = GameManager.Instance.GetComponent<MapController>();
        SetCurrentCell(_mapController.GetCellAtPosition(transform.position));
    }

    public virtual bool TryMoveToCell(Cell targetCell)
    {
        if (_canMove == false) return false;

        if (_mapController.TryToChangeEntityCell(gameObject, _currentCell, targetCell))
        {
            _currentCell = targetCell;

            if (_animateMovement)
            {
                Vector3 direction = targetCell.transform.position - transform.position;
                if (direction.x > 0)
                {
                    transform.DOScaleX(Mathf.Abs(transform.localScale.x), FlipDuration).SetEase(Ease.InOutSine);
                }
                else if (direction.x < 0)
                {
                    transform.DOScaleX(-Mathf.Abs(transform.localScale.x), FlipDuration).SetEase(Ease.InOutSine);
                }
                float targetRotationZ = direction.x != 0
                    ? RotationAngle * Mathf.Sign(direction.x)
                    : RotationAngle * Mathf.Sign(direction.y);
                transform.DORotate(new Vector3(0f, 0f, targetRotationZ), MoveDuration / 2)
                    .SetEase(Ease.InOutSine).OnComplete(() =>
                    {
                        transform.DORotate(Vector3.zero, MoveDuration / 2)
                            .SetEase(Ease.InOutSine);
                    });
            }
            transform.DOMove(targetCell.transform.position, MoveDuration)
                .SetEase(MoveEaseType)
                .OnComplete(() =>
                {
                    OnMoveComplete(targetCell);
                });

            return true;
        }
        else
        {
            return false;
        }
    }
    public virtual bool TeleportToCell(Cell targetCell)
    {
        if (_canMove == false) return false;

        if (_mapController.TryToChangeEntityCell(gameObject, _currentCell, targetCell))
        {
            _canMove = false;
            _currentCell = targetCell;

            transform.DOScale(0, 0.2f).OnComplete(() => { transform.DOMove(targetCell.transform.position, 0); transform.DOScale(1, 0.2f).OnComplete(() =>
            {
                OnMoveComplete(targetCell);
                _canMove = true;
            });
            } );

            return true;
        }
        else
        {
            return false;
        }
    }

    protected virtual void SetCurrentCell(Cell cell)
    {
        _currentCell = cell;
    }
    protected virtual void OnMoveComplete(Cell targetCell)
    {
    }
}