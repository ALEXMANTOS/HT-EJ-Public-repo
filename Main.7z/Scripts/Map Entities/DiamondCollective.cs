using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiamondCollective : MapEntity�ollective
{
    [SerializeField] private int _MinDropCount;
    [SerializeField] private int _MaxDropCount;

    private new void Start()
    {
        base.Start();

        transform.position = new Vector3 (transform.position.x, transform.position.y, 1);
    }

    protected override void OnCollect()
    {
        int diamondsCount = Random.Range(_MinDropCount,_MaxDropCount + 1);
        CurrencyController.Instance.AddDiamonds(diamondsCount);
    }
}