using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(CellMovingEntity), true)]
public class CellMovingEntityEditor : Editor
{
    SerializedProperty moveDurationProp;
    SerializedProperty moveEaseTypeProp;
    SerializedProperty flipDuration;
    SerializedProperty rotationAngle;

    private void OnEnable()
    {
        moveDurationProp = serializedObject.FindProperty("_MoveDuration");
        moveEaseTypeProp = serializedObject.FindProperty("_MoveEaseType");
        flipDuration = serializedObject.FindProperty("_FlipDuration");
        rotationAngle = serializedObject.FindProperty("_RotationAngle");
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();
        DrawPropertiesExcluding(serializedObject, "_MoveDuration", "_MoveEaseType", "_RotationAngle", "_FlipDuration");
        EditorGUILayout.Space();
        EditorGUILayout.LabelField("Cell moving settings", EditorStyles.boldLabel);
        EditorGUILayout.PropertyField(moveDurationProp);
        EditorGUILayout.PropertyField(moveEaseTypeProp);
        EditorGUILayout.PropertyField(flipDuration);
        EditorGUILayout.PropertyField(rotationAngle);
        serializedObject.ApplyModifiedProperties();
    }
}