using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyLaunchAttack : EnemyAttack
{
    [SerializeField] private GameObject _ProjectilePrefab;
    [SerializeField] private float _ProjectileDuration = 1f;
    [SerializeField] private float _ProjectileArcHeight = 2f;

    [Space]
    [SerializeField] private int _ShootEveryNTurn;
    [SerializeField] private int _ShootCount;
    [SerializeField] private float _ShootDelay;

    private int _nextTurnMove;

    private Transform _player;

    private MapController _mapController;
    private TurnController _turnController;

    private void Start()
    {
        _player = PlayerManager.Instance.transform;

        _mapController = GameManager.Instance.GetComponent<MapController>();
        _turnController = GameManager.Instance.GetComponent<TurnController>();

        _nextTurnMove = _turnController.CurrentTurn + _ShootEveryNTurn;
    }

    public override bool TryDoMove()
    {
        if (_turnController.CurrentTurn >= _nextTurnMove)
        {
            FireAtSelectedCells();
            _nextTurnMove = _turnController.CurrentTurn + _ShootEveryNTurn;

            return true;
        }

        return false;
    }

    private void FireAtSelectedCells()
    {
        Cell targetCell = _mapController.GetCellAtPosition(_player.position);

        for (int i = 0; i < _ShootCount; i++)
        {
            float delay = i * _ShootDelay;
            StartCoroutine(FireProjectileWithDelay(targetCell, delay));
        }
    }

    private IEnumerator FireProjectileWithDelay(Cell targetCell, float delay)
    {
        yield return new WaitForSeconds(delay);
        FireProjectile(targetCell);
    }

    private void FireProjectile(Cell targetCell)
    {
        Vector2 startPosition = transform.position;
        Vector2 targetPosition = targetCell.transform.position;

        GameObject projectile = LeanPool.Spawn(_ProjectilePrefab, startPosition, Quaternion.identity);
        Sequence projectileSequence = DOTween.Sequence();
        float midPointY = Mathf.Max(startPosition.y, targetPosition.y) + _ProjectileArcHeight;
        Vector2 midPoint = new Vector2((startPosition.x + targetPosition.x) / 2, midPointY);

        AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];
        AudioController.Instance.PlaySound(clip, 0.6f);
        projectileSequence.Append(projectile.transform.DOMove(midPoint, _ProjectileDuration / 2).SetEase(Ease.OutQuad));
        projectileSequence.Append(projectile.transform.DOMove(targetPosition, _ProjectileDuration / 2).SetEase(Ease.InCubic))
            .OnComplete(() => OnProjectileLanded(projectile, targetCell));
    }

    private void OnProjectileLanded(GameObject projectile, Cell targetCell)
    {
        LeanPool.Despawn(projectile);
        var occupant = targetCell.Occupant;
        if (occupant != null)
        {
            var damageable = occupant.GetComponent<EntityHealth>();
            if (damageable != null)
            {
                damageable.ApplyDamage(Damage);
            }
        }
    }
}
