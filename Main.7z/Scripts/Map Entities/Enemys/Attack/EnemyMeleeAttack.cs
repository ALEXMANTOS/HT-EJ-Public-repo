using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMeleeAttack : EnemyAttack
{
    [SerializeField] private int _AttackDistance = 1;
    [SerializeField] private LayerMask _ObstacleLayer;

    public override bool TryDoMove()
    {
        int enemyLayer = gameObject.layer;

        gameObject.layer = LayerMask.NameToLayer("Ignore Raycast");

        Vector2 directionToPlayer = (_playerManager.transform.position - transform.position).normalized;

        if (Vector2.Distance(transform.position, _playerManager.transform.position) <= _AttackDistance)
        {
            RaycastHit2D hit = Physics2D.Raycast(transform.position, directionToPlayer, _AttackDistance, _ObstacleLayer);

            if (hit.collider == null)
            {
                _playerManager.GetComponent<EntityHealth>().ApplyDamage(Damage);
                gameObject.layer = enemyLayer;

                if(_Sounds.Count > 0) 
                {
                    AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];
                    AudioController.Instance.PlaySound(clip, 0.6f);
                }

                return true;
            }
        }

        gameObject.layer = enemyLayer;

        return false;
    }
}