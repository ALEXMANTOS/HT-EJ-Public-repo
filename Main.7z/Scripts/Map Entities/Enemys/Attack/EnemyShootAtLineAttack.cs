using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Lean.Pool;

public class EnemyShootAtLineAttack : EnemyAttack
{
    [SerializeField] private GameObject _ProjectilePrefab;

    [Space]
    [SerializeField] private float _AttackDistance;
    [SerializeField] private LayerMask _ObstacleLayerMask;
    [SerializeField] private BulletProperties _Properties;

    public override bool TryDoMove()
    {
        Vector2 enemyPosition = transform.position;
        Vector2 playerPosition = _playerManager.transform.position;
        if ((Mathf.Approximately(enemyPosition.x, playerPosition.x) || Mathf.Approximately(enemyPosition.y, playerPosition.y)) &&
            Vector2.Distance(enemyPosition, playerPosition) <= _AttackDistance)
        {
            if (!IsObstacleBetween(enemyPosition, playerPosition))
            {
                ShootProjectile(playerPosition);
                return true;
            }
        }

        return false;
    }

    private void ShootProjectile(Vector2 targetPosition)
    {
        GameObject projectile = LeanPool.Spawn(_ProjectilePrefab, transform.position, Quaternion.identity);
        Vector2 direction = (targetPosition - (Vector2)transform.position).normalized;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        projectile.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));

        if (_Sounds.Count > 0)
        {
            AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];
            AudioController.Instance.PlaySound(clip, 0.6f);
        }

        Bullet bullet = projectile.GetComponent<Bullet>();
        bullet.InitBullet(Damage, _Properties,gameObject);
    }
    private bool IsObstacleBetween(Vector2 enemyPosition, Vector2 playerPosition)
    {
        RaycastHit2D hit = Physics2D.Linecast(enemyPosition, playerPosition, _ObstacleLayerMask);
        if (hit.collider != null)
        {
            return true;
        }

        return false;
    }
}