using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class EnemyAttack : MonoBehaviour, IMapEntityTurnMover, IMapEntityAttack
{
    [field:SerializeField] public int MovePriority { get; private set; }

    [field: SerializeField] public float TimeToNextMove { get; private set; }

    [field: Space]
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }

    [Space]
    [Space]
    [SerializeField] protected List<AudioClip> _Sounds;

    protected PlayerManager _playerManager;

    public abstract bool TryDoMove();

    private void Start()
    {
        _playerManager = PlayerManager.Instance;
    }
}
