using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : EntityHealth
{
    public event Action OnDeath;

    protected override void Death()
    {
        OnDeath?.Invoke();

        base.Death();
    }
}
