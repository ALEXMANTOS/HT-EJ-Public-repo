using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(EnemyHealth))]
public class EnemyInvokeOnEnemyKilledEvent : MonoBehaviour
{
    private void Start()
    {
        GetComponent<EnemyHealth>().OnDeath += () => GameManager.Instance.GetComponent<EntitiesSpawnController>().OnEnemyKilled?.Invoke(gameObject.name.Replace("(Clone)",""));
    }
}
