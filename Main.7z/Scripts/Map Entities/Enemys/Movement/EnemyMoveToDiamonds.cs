using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMoveToDiamonds : EnemyMovementWithCollect
{
    public override bool TryDoMove()
    {
        Cell nearestDiamond = FindNearestDiamond();
        if (nearestDiamond != null)
        {
            List<Cell> path = _mapController.FindPath(_currentCell, nearestDiamond);
            if (path != null && path.Count > 0)
            {
                TryMoveToCell(path[0]);
                return true;
            }
        }
        return false;
    }
    private Cell FindNearestDiamond()
    {
        DiamondCollective[] diamonds = FindObjectsByType<DiamondCollective>(FindObjectsSortMode.None);
        Cell nearestDiamond = null;
        float shortestDistance = float.MaxValue;
        foreach (DiamondCollective diamond in diamonds)
        {
            Cell diamondCell = _mapController.GetCellAtPosition(diamond.transform.position);
            if(diamondCell.Occupant != null)
            {
                continue;
            }

            float distance = GetDistance(_currentCell, diamondCell);
            if (distance < shortestDistance)
            {
                shortestDistance = distance;
                nearestDiamond = diamondCell;
            }
        }

        return nearestDiamond;
    }

    private float GetDistance(Cell fromCell, Cell toCell)
    {
        float dx = Mathf.Abs(fromCell.transform.position.x - toCell.transform.position.x);
        float dy = Mathf.Abs(fromCell.transform.position.y - toCell.transform.position.y);
        return dx + dy;
    }
}