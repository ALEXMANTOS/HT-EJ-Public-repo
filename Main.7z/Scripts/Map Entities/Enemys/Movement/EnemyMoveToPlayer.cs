using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class EnemyMoveToPlayer : MapEntityMovement
{
    private Transform _playerTransform;

    private new void Start()
    {
        base.Start();

        _playerTransform = PlayerManager.Instance.transform;
    }

    public override bool TryDoMove()
    {
        var path = _mapController.FindPath(_currentCell, _mapController.GetCellAtPosition(_playerTransform.position));
        Cell targetCell = path?[0];

        return TryMoveToCell(targetCell);
    }
}