using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMoveToPlayerLine : MapEntityMovement
{
    private PlayerManager _playerManager;

    private new void Start()
    {
        base.Start();

        _playerManager = PlayerManager.Instance;
    }

    public override bool TryDoMove()
    {
        Cell bestTargetCell = FindBestTargetLineCell();

        if (bestTargetCell != null)
        {
            List<Cell> path = _mapController.FindPath(_currentCell, bestTargetCell);
            TryMoveToCell(path?[0]);

            return true;
        }
        else
        {
            List<Cell> path = _mapController.FindPath(_currentCell, _mapController.GetCellAtPosition(_playerManager.transform.position));
            if (path?.Count > 0 && TryMoveToCell(path[0]))
            {
                return true;
            }

            return false;
        }
    }

    private Cell FindBestTargetLineCell()
    {
        Cell playerCell = _mapController.GetCellAtPosition(_playerManager.transform.position);
        Cell currentCell = _currentCell;

        List<Cell> potentialCells = new List<Cell>();
        if (CanMoveToSameLineX(currentCell, playerCell))
        {
            potentialCells.AddRange(_mapController.GetCellsOnSameLineX(playerCell));
        }
        if (CanMoveToSameLineY(currentCell, playerCell))
        {
            potentialCells.AddRange(_mapController.GetCellsOnSameLineY(playerCell));
        }
        return FindClosestCell(potentialCells, currentCell);
    }

    private bool CanMoveToSameLineX(Cell currentCell, Cell playerCell)
    {
        if (currentCell.transform.position.x != playerCell.transform.position.x)
        {
            List<Cell> cellsOnLineX = _mapController.GetCellsOnSameLineX(playerCell);

            foreach (Cell cell in cellsOnLineX)
            {
                if (cell.Occupant != null && cell != playerCell)
                {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    private bool CanMoveToSameLineY(Cell currentCell, Cell playerCell)
    {
        if (currentCell.transform.position.y != playerCell.transform.position.y)
        {
            List<Cell> cellsOnSameLineY = _mapController.GetCellsOnSameLineY(playerCell);

            foreach (Cell cell in cellsOnSameLineY)
            {
                if (cell.Occupant != null && cell != playerCell)
                {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    private Cell FindClosestCell(List<Cell> cells, Cell currentCell)
    {
        Cell closestCell = null;
        float closestDistance = float.MaxValue;

        foreach (Cell cell in cells)
        {
            float distance = GetDistance(currentCell, cell);
            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestCell = cell;
            }
        }

        return closestCell;
    }

    private float GetDistance(Cell a, Cell b)
    {
        return Vector2.Distance(a.transform.position, b.transform.position);
    }
}