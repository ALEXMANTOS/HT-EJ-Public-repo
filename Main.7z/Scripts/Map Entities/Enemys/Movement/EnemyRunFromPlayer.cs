using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class EnemyRunFromPlayer : MapEntityMovement
{
    private PlayerManager _player;

    private new void Start()
    {
        base.Start();

        _player = PlayerManager.Instance;
    }

    public override bool TryDoMove()
    {
        Cell playerCell = _mapController.GetCellAtPosition(_player.transform.position);
        Cell enemyCell = _mapController.GetCellAtPosition(transform.position);

        Vector2 directionFromPlayer = (Vector2)(enemyCell.transform.position - playerCell.transform.position);
        Vector2 normalizedDirection = directionFromPlayer.normalized;
        Vector2 targetPosition = (Vector2)enemyCell.transform.position + normalizedDirection;

        Cell targetCell = _mapController.GetCellAtPosition(targetPosition);
        if (targetCell != null && targetCell.Occupant == null)
        {
            TryMoveToCell(targetCell);
            return true;
        }
        else
        {
            List<Cell> escapePath = FindEscapePath(enemyCell, playerCell);

            if (escapePath != null && escapePath.Count > 0)
            {
                Cell nextCell = escapePath[0];
                TryMoveToCell(nextCell);
                return true;
            }
        }

        return false;
    }
    private List<Cell> FindEscapePath(Cell enemyCell, Cell playerCell)
    {
        List<Cell> neighborCells = _mapController.GetNeighborCells(enemyCell);
        neighborCells = neighborCells
            .Where(cell => cell.Occupant == null)
            .OrderByDescending(cell => GetDistance(cell, playerCell))
            .ToList();
        if (neighborCells.Count > 0)
        {
            return _mapController.FindPath(enemyCell, neighborCells[0]);
        }

        return null;
    }

    private float GetDistance(Cell a, Cell b)
    {
        return Vector2.Distance((Vector2)a.transform.position, (Vector2)b.transform.position);
    }
}