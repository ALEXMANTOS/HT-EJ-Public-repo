using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class EnemySpawnSubEnemys : MonoBehaviour, IMapEntityTurnMover
{
    [field: SerializeField] public int MovePriority { get; private set; }
    [field: SerializeField] public float TimeToNextMove { get; private set; }

    [Space]
    [SerializeField] private List<GameObject> _SubEnemys;
    [SerializeField] private int _TurnsToNextSpawn;
    [SerializeField] [Range(1,4)] private int _SpawnCount;

    private int _turnsSinceLastSpawn = 0; 

    private MapController _mapController;
    private EntitiesSpawnController _entitiesSpawnController;
    private TurnController _turnController;

    private bool _turned;

    private void Awake()
    {
        _mapController = GameManager.Instance.GetComponent<MapController>();
        _entitiesSpawnController = GameManager.Instance.GetComponent<EntitiesSpawnController>();
        _turnController = GameManager.Instance.GetComponent<TurnController>();
    }

    private void OnEnable()
    {
        _turnController.OnNewGameTurnStarted += ResetTurned;
    }
    private void OnDisable()
    {
        _turnController.OnNewGameTurnStarted -= ResetTurned;
    }

    public bool TryDoMove()
    {
        if (_turned) return false;

        List<Cell> neighborCells = _mapController.GetNeighborCells(_mapController.GetCellAtPosition(transform.position));
        List<Cell> freeCells = neighborCells.Where(cell => cell.Occupant == null).ToList();

        if (_turnsSinceLastSpawn >= _TurnsToNextSpawn && freeCells.Count > 0)
        {
            _turnsSinceLastSpawn = 0;

            int spawnLimit = Mathf.Min(_SpawnCount, freeCells.Count);

            List<Cell> cellsToSpawnIn = freeCells.OrderBy(cell => Random.value).Take(spawnLimit).ToList();

            foreach (var cell in cellsToSpawnIn)
            {
                GameObject enemyToSpawn = _SubEnemys[Random.Range(0, _SubEnemys.Count)];
                _mapController.TryToSpawnEntity(enemyToSpawn, cell,out GameObject enemy);
                _entitiesSpawnController.AddEntityToSpawned(enemy.GetComponent<MapEntityTurnController>());
            }

            _turned = true;
            return true;
        }

        _turned = true;
        _turnsSinceLastSpawn++;
        return false;
    }

    private void ResetTurned()
    {
        _turned = false;
    }
}