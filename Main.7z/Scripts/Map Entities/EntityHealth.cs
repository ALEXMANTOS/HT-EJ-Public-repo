using DG.Tweening;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EntityHealth : MonoBehaviour
{
    public event Action<float> OnHPChanged;
    public event Action<float> OnDamaged;
    public event Action<float> OnHeal;

    [Header("Health")]
    [SerializeField] private float maxHealth;
    [SerializeField] private float currentHealth;
    public float _MaxHealth { get { return maxHealth; } protected set { maxHealth = value; } }
    public float _CurrentHealth { get { return currentHealth; } protected set { currentHealth = value; } }

    protected bool _Immortal = false;

    public virtual void ApplyDamage(float damage)
    {
        if (_Immortal == true)
        {
            return;
        }

        if (damage < 0)
        {
            Debug.LogError("��������� ���� ������ � �����");
            return;
        }

        _CurrentHealth -= damage;
        if (_CurrentHealth <= 0.001f)
        {
            _CurrentHealth = 0;
            OnDamaged?.Invoke(damage);
            OnHPChanged?.Invoke(_CurrentHealth);

            Death();
            return;
        }

        OnDamaged?.Invoke(damage);
        OnHPChanged?.Invoke(_CurrentHealth);
    }
    public virtual void ApplyDamage(float damage,ref float appliedDamage)
    {
        appliedDamage = 0;

        if (_Immortal == true)
        {
            return;
        }

        if (damage < 0)
        {
            Debug.LogError("��������� ���� ������ � �����");
            return;
        }

        float oldHealth = _CurrentHealth;
        _CurrentHealth -= damage;

        if (_CurrentHealth <= 0.001f)
        {
            _CurrentHealth = 0;
            appliedDamage = oldHealth;

            OnDamaged?.Invoke(damage);
            OnHPChanged?.Invoke(_CurrentHealth);

            Death();
            return;
        }

        appliedDamage = damage;
        OnDamaged?.Invoke(damage);
        OnHPChanged?.Invoke(_CurrentHealth);
    }
    public virtual void Heal(float heal)
    {
        if (heal < 0)
        {
            Debug.LogError("������� ������ � �����");
            return;
        }

        _CurrentHealth += heal;
        if (_CurrentHealth > _MaxHealth)
        {
            _CurrentHealth = _MaxHealth;
        }


        OnHPChanged?.Invoke(_CurrentHealth);
        OnHeal?.Invoke(heal);
    }

    protected virtual void Death()
    {
        GetComponent<MapEntityTurnController>().UnsubscribeFromTurnEvent();

        transform.DOScale(Vector3.zero, 0.25f)
            .SetEase(Ease.InBack)
            .OnComplete(() =>
            {
                Destroy(gameObject);
            });
    }
}