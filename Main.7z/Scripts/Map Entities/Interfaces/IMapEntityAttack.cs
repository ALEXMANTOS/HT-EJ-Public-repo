using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IMapEntityAttack
{
    float Damage { get; }
    AttackType AttackType { get; }

}

public enum AttackType
{
    Melee,
    Shoot,
    Launch,
    Ray
}