using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IMapEntityTurnMover 
{
    int MovePriority {  get; }
    float TimeToNextMove {  get; }

    bool TryDoMove();
}