using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IPlayerTurnMover
{
    int MovePriority { get; }
    float TimeToNextMove { get; }

    bool TryDoMove(Vector2 targetMovePosition);
}
