using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(EntityHealth))]
public class MapEntityDamageEffects : MonoBehaviour
{
    private void Start()
    {
        GetComponent<EntityHealth>().OnDamaged += OnDamaged;
    }

    private void OnDamaged(float damage)
    {
        Camera.main.GetComponent<CameraShake>().Shake(damage);
        SliceEffect.Instance.ShowSliceEffect(transform.position);
    }
}
