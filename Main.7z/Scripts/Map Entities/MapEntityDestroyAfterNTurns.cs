using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapEntityDestroyAfterNTurns : MonoBehaviour
{
    [SerializeField] private Vector2Int _TurnsLifeSpawnRange;

    private int _destroyOnTurn;

    private TurnController _turnController;
    private MapEntityTurnController _mapEntityTurnController;

    private void Start()
    {
        _turnController = GameManager.Instance.GetComponent<TurnController>();
        _mapEntityTurnController = GetComponent<MapEntityTurnController>();

        _destroyOnTurn = _turnController.CurrentTurn + Random.Range(_TurnsLifeSpawnRange.x, _TurnsLifeSpawnRange.y + 1);

        _mapEntityTurnController.OnMoved += CheckTurn;
    }

    private void CheckTurn()
    {
        if (_turnController.CurrentTurn >= _destroyOnTurn && _mapEntityTurnController.CurrentMovesCount == 1)
        {
            transform.DOScale(0, 0.5f).SetEase(Ease.InBack).SetDelay(_mapEntityTurnController.TimeBetweenMoves).OnComplete(() => Destroy(gameObject));
        }
    }
}