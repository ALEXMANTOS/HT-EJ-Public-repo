using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapEntityGiveEPToPlayerOnDestroy : MonoBehaviour
{
    [SerializeField] private float _ChanceToDrop;
    [SerializeField] private float _MinDropCount;
    [SerializeField] private float _MaxDropCount;

    private void OnDestroy()
    {
        if (PlayerManager.Instance == null) return;

        float[] _probalitys = { _ChanceToDrop, 100 - _ChanceToDrop};
        int? randomIndex = ProbalityRandom.RandomRange(_probalitys);
        
        if(randomIndex == 0)
        {
            float dropCount = Mathf.Round(Random.Range(_MinDropCount, _MaxDropCount) * 10f) / 10f;
            PlayerManager.Instance.GetComponent<PlayerEnergy>().AddEnergy(dropCount);
        }
    }
}
