using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class MapEntityHealOtherEntities : MonoBehaviour, IMapEntityTurnMover
{
    [field: SerializeField] public int MovePriority { get; private set; }
    [field: SerializeField] public float TimeToNextMove { get; private set; }

    [Space]
    [SerializeField] private List<string> _HealTeams;

    [Space]
    [SerializeField] private float _HealAmount = 0.1f;
    [SerializeField] private int _MaxTargets = 3;

    [Space]
    [SerializeField] private GameObject _BeamPrefab;
    [SerializeField] private Vector2 _BeamArcRange = new Vector2(-3f, 3f); 

    private List<EntityHealth> _currentTargets = new List<EntityHealth>();
    private List<LineRenderer> _lines = new List<LineRenderer>(); 
    private List<Vector3> _controlPoints = new List<Vector3>();

    private Dictionary<EntityHealth, System.Action<float>> _handlers = new();

    private EntitiesSpawnController _entitySpawnController;

    private void Start()
    {
        _entitySpawnController = GameManager.Instance.GetComponent<EntitiesSpawnController>();
    }

    private void Update()
    {
        UpdateLines();
    }

    private void OnDisable()
    {
        if (!gameObject.scene.isLoaded) return;

        foreach(var enemy in _currentTargets)
        {
            UnsubscribeFromTargetEvents(enemy);
        }
    }

    public bool TryDoMove()
    {
        for (int i = _currentTargets.Count - 1; i >= 0; i--)
        {
            if (_currentTargets[i] == null)
            {
                RemoveLine(i);
            }
        }

        HealTargets();

        int neededTargets = _MaxTargets - _currentTargets.Count;
        if (neededTargets > 0)
        {
            FindNewTargets(neededTargets);
        }

        UpdateLines();
        return false;
    }

    private void FindNewTargets(int neededTargets)
    {
        List<EntityHealth> allEntities = _entitySpawnController.GetEntitiesByTeam(_HealTeams.ToArray())
            .Where(GO => GO.GetComponent<EntityHealth>()).Select(GO => GO.GetComponent<EntityHealth>()).ToList();
        allEntities.Remove(GetComponent<EntityHealth>());

        foreach (var entity in allEntities)
        {
            if (_currentTargets.Contains(entity))
                continue;

            _currentTargets.Add(entity);
            SubscribeToTargetEvents(entity);
            CreateLine(entity);

            neededTargets--;

            if (neededTargets <= 0)
                break;
        }
    }

    private void HealTargets()
    {
        foreach (var entity in _currentTargets)
        {
            entity.Heal(_HealAmount);
        }
    }

    private void CreateLine(EntityHealth entity)
    {
        var line = Instantiate(_BeamPrefab, transform).GetComponent<LineRenderer>();
        _lines.Add(line);

        Vector3 startPosition = transform.position;
        Vector3 endPosition = entity.transform.position;
        Vector3 controlPoint = (startPosition + endPosition) / 2;

        controlPoint += new Vector3(
            Random.Range(-_BeamArcRange.x, _BeamArcRange.x),
            Random.Range(_BeamArcRange.y * 0.5f, _BeamArcRange.y),
            Random.Range(-_BeamArcRange.x, _BeamArcRange.x)
        );

        _controlPoints.Add(controlPoint);
    }

    private void UpdateLines()
    {
        for (int i = 0; i < _currentTargets.Count; i++)
        {
            if (i >= _lines.Count || _currentTargets[i] == null)
                continue;

            var line = _lines[i];
            var targetPosition = _currentTargets[i].transform.position;

            Vector3 startPosition = transform.position;
            Vector3 midPoint = (startPosition + targetPosition) / 2;

            Vector3 floatingOffset = new Vector3(
            Mathf.Sin(Time.time * 1f + i) * 0.5f,
            Mathf.Cos(Time.time * 0.5f + i) * 0.5f, 
            Mathf.Sin(Time.time * 0.8f + i) * 0.5f 
            );

            Vector3 controlPoint = midPoint + floatingOffset;

            int resolution = 5; 
            Vector3[] positions = new Vector3[resolution];
            for (int j = 0; j < resolution; j++)
            {
                float t = j / (float)(resolution - 1);
                positions[j] = CalculateQuadraticBezierPoint(t, startPosition, controlPoint, targetPosition);
            }

            line.positionCount = positions.Length;
            line.SetPositions(positions);
        }
    }

    private Vector3 CalculateQuadraticBezierPoint(float t, Vector3 start, Vector3 control, Vector3 end)
    {
        float oneMinusT = 1f - t;
        return oneMinusT * oneMinusT * start +
               2f * oneMinusT * t * control +
               t * t * end;
    }

    private void SubscribeToTargetEvents(EntityHealth target)
    {
        if (target != null && !_handlers.ContainsKey(target))
        {
            System.Action<float> handler = damage => HandleTargetDamaged(target);
            _handlers[target] = handler;

            target.OnDamaged += handler;
        }
    }

    private void UnsubscribeFromTargetEvents(EntityHealth target)
    {
        if (target != null && _handlers.TryGetValue(target, out var handler))
        {
            target.OnDamaged -= handler;
            _handlers.Remove(target);
        }
    }

    private void HandleTargetDamaged(EntityHealth health)
    {
        if (health._CurrentHealth <= 0)
        {
            int index = _currentTargets.IndexOf(health);
            RemoveLine(index);
        }
    }

    private void RemoveLine(int index)
    {
        if (index < 0 || index >= _lines.Count)
            return;

        Destroy(_lines[index].gameObject);
        _lines.RemoveAt(index);

        _controlPoints.RemoveAt(index);

        UnsubscribeFromTargetEvents(_currentTargets[index]);

        _currentTargets.RemoveAt(index);
    }
}