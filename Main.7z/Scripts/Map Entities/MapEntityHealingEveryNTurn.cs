using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(EntityHealth))]
public class MapEntityHealingEveryNTurn : MonoBehaviour
{
    [SerializeField] private float _HealAmount;
    [SerializeField] private int _EveryNTurn;

    [Space]
    [SerializeField] private Sprite _PlayerEffectIcon;
    private const string EFFECT_NAME = "Self Healing";

    private int _currentTurn;

    private EntityHealth _health;
    private PlayerEffectsUIController _playerEffectsUIController;

    private void Start()
    {
        _health = GetComponent<EntityHealth>();
        _playerEffectsUIController = PlayerEffectsUIController.Instance;

        if (_health is PlayerHealth)
        {
            _playerEffectsUIController.AddUIEffect(EFFECT_NAME,_PlayerEffectIcon,_EveryNTurn);
        }

        _currentTurn = _EveryNTurn;
        GameManager.Instance.GetComponent<TurnController>().OnNewGameTurnStarted += OnTurnStart;
    }

    private void OnDisable()
    {
        if (!gameObject.scene.isLoaded) return;

        GameManager.Instance.GetComponent<TurnController>().OnNewGameTurnStarted -= OnTurnStart;
    }
    private void OnTurnStart()
    {
        _currentTurn--;

        if (_currentTurn == 0)
        {
            Heal();
            _currentTurn = _EveryNTurn;
        }

        if (_health is PlayerHealth)
        {
            _playerEffectsUIController.UpdateUIEffectStatus(EFFECT_NAME,_currentTurn);
        }
    }

    private void Heal()
    {
        if (_health != null)
        {
            _health.Heal(_HealAmount);
        }
    }
}