using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapEntityIdleAnimation : MonoBehaviour
{
    [SerializeField] private float _ScaleAmount = 0.95f;
    [SerializeField] private float _IdleDuration = 1f;

    private Tween _idleTween;

    private void Start()
    {
        if(TryGetComponent(out MapEntitySpawnAnimation spawnAnim))
        {
            Invoke("StartIdleAnimation",spawnAnim._AnimationDuration);
        }
        else
        {
            StartIdleAnimation();
        }
    }

    private void StartIdleAnimation()
    {
        _idleTween = transform.DOScaleY(_ScaleAmount, _IdleDuration)
            .SetEase(Ease.InOutSine)
            .SetLoops(-1, LoopType.Yoyo);
    }

    private void OnDisable()
    {
        if (_idleTween != null)
        {
            _idleTween.Kill();
        }
    }
}