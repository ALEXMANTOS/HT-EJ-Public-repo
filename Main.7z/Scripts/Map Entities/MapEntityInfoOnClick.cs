using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization;

public class MapEntityInfoOnClick : MapEntityInfoOnClickBase
{
    [SerializeField] private LocalizedString _Name;
    public override string EntityName => _Name.GetLocalizedString();

    [SerializeField] private SpriteRenderer _EntitySR;
    public override Sprite EntityIcon => _EntitySR.sprite;

    [SerializeField] private LocalizedString _Description;
    public override string EntityDescription => _Description.GetLocalizedString();
}
