using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public abstract class MapEntityInfoOnClickBase : MonoBehaviour, IPointerClickHandler
{
    public virtual string EntityName { get; protected set; }
    public virtual Sprite EntityIcon { get; protected set; }
    public virtual string EntityDescription { get; protected set; }

    public void OnPointerClick(PointerEventData eventData)
    {
        OnClicked();
    }

    protected virtual void OnClicked()
    {
        EntityInfoBoxUI.Instance.ShowInfo(this);
    }
}