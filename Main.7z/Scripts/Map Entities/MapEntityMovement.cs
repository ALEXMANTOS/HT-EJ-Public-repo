using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public abstract class MapEntityMovement : CellMovingEntity,IMapEntityTurnMover
{
    [field: SerializeField] public int MovePriority { get; private set; }
    public float TimeToNextMove { get; private set; }

    private void Awake()
    {
        TimeToNextMove = MoveDuration;
    }

    public abstract bool TryDoMove();
}
