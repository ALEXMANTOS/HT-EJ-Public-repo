using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class MapEntityRandomMoveAfterAll : MonoBehaviour, IMapEntityTurnMover
{
    [field: SerializeField] public int MovePriority { get; private set; }
    public float TimeToNextMove { get; private set; }

    private MapEntityMovement _movement;
    private MapController _mapController;

    private void Awake()
    {
        _movement = GetComponent<MapEntityMovement>();
        _mapController = GameManager.Instance.GetComponent<MapController>();

        if (_movement == null)
        {
            Debug.LogError("MapEntityMovement is null blyat");
        }
    }

    private void Start()
    {
        TimeToNextMove = _movement.MoveDuration;
    }

    public bool TryDoMove()
    {
        Cell[] neighborsCells = _mapController.GetNeighborCells(_mapController.GetCellAtPosition(transform.position)).ToArray();
        neighborsCells = neighborsCells.Where(cell => cell.Occupant == null).ToArray();

        if (neighborsCells.Length == 0) return false;

        Cell randomCell = neighborsCells[Random.Range(0,neighborsCells.Length)];
        return _movement.TryMoveToCell(randomCell);
    }
}