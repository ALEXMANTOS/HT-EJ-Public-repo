using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(EntityHealth))]
public class MapEntitySFXWhenDamaged : MonoBehaviour
{
    [SerializeField] private List<AudioClip> _Sounds;

    private void Start()
    {
        GetComponent<EntityHealth>().OnDamaged += PlaySound;
    }

    private void PlaySound(float damage)
    {
        AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];

        AudioController.Instance.PlaySound(clip,0.6f);
    }
}
