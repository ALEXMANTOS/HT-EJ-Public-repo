using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapEntitySpawnAnimation : MonoBehaviour
{
    [field: SerializeField] public float _AnimationDuration { get; private set; } = 0.3f;

    private void OnEnable()
    {
        transform.localScale = Vector2.zero;

        transform.DOScale(Vector2.one, _AnimationDuration).SetEase(Ease.OutBack);
    }
}
