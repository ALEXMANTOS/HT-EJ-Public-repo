using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class MapEntitySpawnEntityOnDeath : MonoBehaviour
{
    [SerializeField] private GameObject _SpawnPrefab;
    [SerializeField] private SpawnType _spawnType = SpawnType.Single;
    [SerializeField] private int _entitiesToSpawn = 1;

    private MapController _mapController;
    private EntitiesSpawnController _entitiesSpawnController;

    private void Start()
    {
        _mapController = GameManager.Instance.GetComponent<MapController>();
        _entitiesSpawnController = GameManager.Instance.GetComponent<EntitiesSpawnController>();
    }

    private void OnDisable()
    {
        if (!gameObject.scene.isLoaded) return;

        _mapController.ClearCellOccupant(_mapController.GetCellAtPosition(transform.position));

        if (_spawnType == SpawnType.Single)
        {
            SpawnSingleEntity();
        }
        else if (_spawnType == SpawnType.Multiple)
        {
            SpawnMultipleEntities();
        }
    }

    private void SpawnSingleEntity()
    {
        if (_mapController.TryToSpawnEntity(_SpawnPrefab, transform.position, out GameObject spawnedInstance))
        {
            _entitiesSpawnController.AddEntityToSpawned(spawnedInstance.GetComponent<MapEntityTurnController>());
        }
    }

    private void SpawnMultipleEntities()
    {
        List<Vector3> neighborPositions = _mapController.GetNeighborCells(_mapController.GetCellAtPosition(transform.position))
            .Select(cell => cell.transform.position).ToList();

        int spawnedCount = 0;
        foreach (Vector3 position in neighborPositions)
        {
            if (spawnedCount >= _entitiesToSpawn) break;

            if (_mapController.TryToSpawnEntity(_SpawnPrefab, position, out GameObject spawnedInstance))
            {
                _entitiesSpawnController.AddEntityToSpawned(spawnedInstance.GetComponent<MapEntityTurnController>());
                spawnedCount++;
            }
        }
    }

    private enum SpawnType
    {
        Single,
        Multiple
    }
}