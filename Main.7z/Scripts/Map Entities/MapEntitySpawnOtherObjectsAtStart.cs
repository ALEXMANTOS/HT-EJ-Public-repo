using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MapEntityTurnController))]
public class MapEntitySpawnOtherObjectsAtStart : MonoBehaviour
{
    public event Action<List<GameObject>> OnGOsSpawned;

    [SerializeField] protected List<GameObject> _GObjectsToSpawn;
    protected List<GameObject> _spawnedGObjects = new List<GameObject>();

    protected TurnController _turnController;

    protected Func<IEnumerator> _coroutine;

    protected void Start()
    {
        _turnController = GameManager.Instance.GetComponent<TurnController>();

        _coroutine = TrySpawn;
        StartCoroutine(TrySpawn());
        _turnController.SubscribeToTeamTurnStartEvent(GetComponent<MapEntityTurnController>().TurnTeamName, _coroutine);
    }

    protected virtual IEnumerator TrySpawn()
    {
        for (int i = _GObjectsToSpawn.Count - 1; i >= 0; i--)
        {
            var goPref = _GObjectsToSpawn[i];

            if (GameManager.Instance.GetComponent<MapController>().TryToSpawnEntityOnRandomFreeCell(goPref,out GameObject go))
            {
                _spawnedGObjects.Add(go);
                _GObjectsToSpawn.RemoveAt(i);
            }
        }

        if (_GObjectsToSpawn.Count == 0)
        {
            OnGOsSpawned?.Invoke(_spawnedGObjects);

            Destroy(this);
        }

        yield return null;
    }

    private void OnDestroy()
    {
        _turnController.UnsubscribeFromTeamTurnStartEvent(GetComponent<MapEntityTurnController>().TurnTeamName, _coroutine);
    }
}