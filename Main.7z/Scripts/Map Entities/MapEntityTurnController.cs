using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using UnityEngine;
using UnityEngine.Events;

public class MapEntityTurnController : MonoBehaviour
{
    public event Action OnMoved;

    [field:SerializeField] public string TurnTeamName { get; protected set; }
    [field: SerializeField] public int _MovesCount { get; protected set; }

    public int CurrentMovesCount { get; protected set; }
    public int LivedTurns { get; protected set; }
    public float TimeBetweenMoves { get; protected set; }

    protected List<IMapEntityTurnMover> _turnMovers;

    protected TurnController _turnController;

    protected Func<IEnumerator> _startTurnCrtn;
    protected bool _subscribedOnTurns = true;

    protected void Start()
    {
        _turnMovers = GetComponents<IMapEntityTurnMover>().ToList();
        _turnMovers.Sort((a,b) => a.MovePriority.CompareTo(b.MovePriority));

        _turnController = GameManager.Instance.GetComponent<TurnController>();
        _startTurnCrtn = StartTurn;
        _turnController.SubscribeToTeamTurnStartEvent(TurnTeamName,_startTurnCrtn);
    }
    private void OnDisable()
    {
        if(_subscribedOnTurns == true)
        {
            UnsubscribeFromTurnEvent();
        }
    }

    protected virtual IEnumerator StartTurn()
    {
        CurrentMovesCount = _MovesCount;

        while (CurrentMovesCount > 0)
        {
            DoMove();

            yield return new WaitForSeconds(TimeBetweenMoves);
        }

        LivedTurns++;
    }

    [ContextMenu("Do Move")]
    protected virtual void DoMove()
    {
        TimeBetweenMoves = 0;

        foreach(var turnMover in _turnMovers)
        {
            if (turnMover.TryDoMove())
            {
                TimeBetweenMoves = turnMover.TimeToNextMove;
                break;
            }
        }

        InvokeOnMovedEvent();
        CurrentMovesCount--;
    }

    protected void InvokeOnMovedEvent()
    {
        OnMoved?.Invoke();
    }

    public void UnsubscribeFromTurnEvent()
    {
        _subscribedOnTurns = false;
        _turnController.UnsubscribeFromTeamTurnStartEvent(TurnTeamName, _startTurnCrtn);
    }
}