using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class MapEntity�ollective : MonoBehaviour
{
    [SerializeField] private bool _OccupateCell;
    [SerializeField] private bool _CanCollectAllEntities;

    protected void Start()
    {
        if (!_OccupateCell)
        {
            var mapController = GameManager.Instance.GetComponent<MapController>();
            mapController.ClearCellOccupant(mapController.GetCellAtPosition(transform.position));
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.TryGetComponent(out PlayerManager player))
        {
            OnCollect();

            transform.DOScale(0, 0.2f)
                .OnComplete(() => Destroy(gameObject));
        }

        if (_CanCollectAllEntities == false) return;

        if(collision.TryGetComponent(out EnemyMovementWithCollect enemy))
        {
            transform.DOScale(0, 0.2f)
                .OnComplete(() => Destroy(gameObject));
        }
    }
    protected abstract void OnCollect();
}
