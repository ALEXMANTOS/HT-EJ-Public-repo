using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ObstacleBomb : CellMovingEntity, IMapEntityTurnMover,IMapEntityInteractable,IMapEntityAttack
{
    [field: SerializeField] public int MovePriority { get; private set; }
    [field: SerializeField] public float TimeToNextMove { get; private set; }

    [field: Space]
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }

    [Space]
    [SerializeField] private float _ExplodeAreaSize = 5f;
    [SerializeField] private LayerMask _EntityLayerMask;
    [SerializeField] private int _TurnsToExplode;

    [Space]
    [SerializeField] private VFXController _ExplodeEffect;
    [SerializeField] private List<AudioClip> _Sounds;

    [Space]
    [SerializeField] private TextMeshPro _TurnsToExplodeText;

    private void Awake()
    {
        _animateMovement = false;

        UpdateBombText();
    }

    public bool TryInteract()
    {
        Vector3 playerPosition = PlayerManager.Instance.transform.position;
        Vector3 bombPosition = transform.position;

        Vector3 direction = bombPosition - playerPosition;
        Vector3 newBombPosition = bombPosition + direction;

        Cell newBombCell = _mapController.GetCellAtPosition(newBombPosition);
        if (TryMoveToCell(newBombCell))
        {
            return true;
        }

        return false; 
    }

    public bool TryDoMove()
    {
        if(_TurnsToExplode > 1)
        {
            _TurnsToExplode--;
            UpdateBombText();
            return false;
        }

        Explode();
        _TurnsToExplodeText.DOKill();
        _TurnsToExplodeText.transform.DOKill();

        transform.DOScale(0, 0.4f)
            .OnComplete(() => Destroy(gameObject));

        return true;
    }

    private void Explode()
    {
        float areaSize = _ExplodeAreaSize - 0.1f;
        Vector2 halfExtents = new Vector2(areaSize / 2, areaSize / 2);
        Collider2D[] colliders = Physics2D.OverlapBoxAll(transform.position, halfExtents * 2, 0, _EntityLayerMask);

        foreach (Collider2D collider in colliders)
        {
            EntityHealth entityHealth = collider.GetComponent<EntityHealth>();
            if (entityHealth != null)
            {
                entityHealth.ApplyDamage(Damage);
            }
        }

        Camera.main.GetComponent<CameraShake>().Shake(Damage);

        AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];
        AudioController.Instance.PlaySound(clip, 0.6f);

        VFXController explodeVfx = LeanPool.Spawn(_ExplodeEffect,transform.position,Quaternion.identity);
        explodeVfx.SetEffectSize(halfExtents*2);
    }
    private void UpdateBombText()
    {
        if (_TurnsToExplodeText != null)
        {
            _TurnsToExplodeText.text = _TurnsToExplode.ToString();

            if (_TurnsToExplode <= 1)
            {
                StartBlinkingAndScalingText();
            }
            else
            {
                _TurnsToExplodeText.DOKill(); 
                _TurnsToExplodeText.transform.localScale = Vector3.one;
                _TurnsToExplodeText.color = Color.white;
            }
        }
    }

    private void StartBlinkingAndScalingText()
    {
        _TurnsToExplodeText.DOColor(Color.red, 0.5f).SetLoops(-1, LoopType.Yoyo);
        _TurnsToExplodeText.transform.DOScale(1.2f, 0.5f).SetLoops(-1, LoopType.Yoyo).SetEase(Ease.InOutSine);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        float areaSize = _ExplodeAreaSize - 0.1f;
        Vector2 halfExtents = new Vector2(areaSize / 2, areaSize / 2);
        Gizmos.DrawWireCube(transform.position, halfExtents * 2);
    }
}