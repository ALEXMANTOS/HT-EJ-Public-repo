using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ObstacleChest : MonoBehaviour,IMapEntityInteractable
{
    [SerializeField] private List<CardData> _KeepingCards;
    [SerializeField] private int _CardsToChoice;
    [SerializeField] private float _GivingEnergyIfNoDeckSpace;

    [Space]
    [SerializeField] private GameObject _LockImage;

    private int _requiredKeysCount;
    private int _collectedKeys;

    private bool _opened;

    private void Awake()
    {
        var _spawner = GetComponent<MapEntitySpawnOtherObjectsAtStart>();
        _spawner.OnGOsSpawned += GetKeysGOs;
    }

    private void Start()
    {
        if(PlayerManager.Instance.TryGetComponent(out PlayerAdvencedCards playerUniqueCards))
        {
            foreach (var card in playerUniqueCards.GetUniqueCards())
            {
                if (!_KeepingCards.Contains(card))
                {
                    _KeepingCards.Add(card);
                }
            };
        }

        var maxPlayerEnergy = PlayerManager.Instance.GetComponent<PlayerEnergy>()._MaxEnergy;
        _KeepingCards = _KeepingCards
            .Where(card => CharactersAndCardsUnlockController.Instance.IsCardUnlocked(card.CardName.TableEntryReference.KeyId.ToString())
                           && card.EnergyCost <= maxPlayerEnergy)
            .ToList();
    }

    public bool TryInteract()
    {
        if (_opened)
        {
            if (_KeepingCards.Count < _CardsToChoice)
            {
                Debug.LogWarning("������������ ���� ��� ������!");
                return false;
            }

            List<CardData> cards = new List<CardData>();
            List<CardData> tempCardsPool = new List<CardData>(_KeepingCards);

            for (int i = 0; i < _CardsToChoice; i++)
            {
                int randomIndex = Random.Range(0, tempCardsPool.Count);
                CardData card = tempCardsPool[randomIndex];
                cards.Add(card);
                tempCardsPool.RemoveAt(randomIndex);
            }

            CardsChoice.Instance.OpenChoice(cards,_GivingEnergyIfNoDeckSpace);

            transform.DOScale(0, 0.3f).SetEase(Ease.InBack).OnComplete(() => Destroy(gameObject));
            return true;
        }

        return false;
    }

    private void GetKeysGOs(List<GameObject> spawnedGOs)
    {
        List<ObstacleKeyForChest> keysFound = new List<ObstacleKeyForChest>();
        foreach (var go in spawnedGOs)
        {
            ObstacleKeyForChest key = go.GetComponent<ObstacleKeyForChest>();
            if (key != null)
            {
                key.SetChest(this);
                keysFound.Add(key);
            }
        }

        _requiredKeysCount = keysFound.Count;
    }

    public void AddKey()
    {
        _collectedKeys++;

        if(_collectedKeys == _requiredKeysCount)
        {
            _LockImage.GetComponent<SpriteRenderer>().DOFade(0,0.3f);
            _LockImage.transform.GetChild(0).DOScale(Vector3.zero,0.3f).SetEase(Ease.InBack);
            _opened = true;
        }
    }
}