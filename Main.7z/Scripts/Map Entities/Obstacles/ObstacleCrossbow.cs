using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

public class ObstacleCrossbow : MonoBehaviour, IMapEntityTurnMover,IMapEntityAttack
{
    [field: SerializeField] public int MovePriority { get; private set; }
    [field: SerializeField] public float TimeToNextMove { get; private set; }

    [field: Space]
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }
    [SerializeField] private GameObject _ArrowPrefab;
    [SerializeField] private BulletProperties _ArrowProperties;

    private Directions _directions;
    private int _destroyOnTurn;

    private TurnController _turnController;

    private void Start()
    {
        _turnController = GameManager.Instance.GetComponent<TurnController>();

        SetRandomDirections();

        _destroyOnTurn = _turnController.CurrentTurn + Random.Range(2,6);
    }

    public bool TryDoMove()
    {
        FireArrows();

        if(_turnController.CurrentTurn >= _destroyOnTurn)
        {
            transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() => Destroy(gameObject));
        }

        return true;
    }

    private void FireArrows()
    {
        if (_directions.Up)
        {
            FireArrow(Vector2.up);
        }
        if (_directions.Down)
        {
            FireArrow(Vector2.down);
        }
        if (_directions.Left)
        {
            FireArrow(Vector2.left);
        }
        if (_directions.Right)
        {
            FireArrow(Vector2.right);
        }
    }

    private void SetRandomDirections()
    {
        MapController mapController = GameManager.Instance.GetComponent<MapController>();
        _directions.Up = false;
        _directions.Down = false;
        _directions.Left = false;
        _directions.Right = false;
        List<string> availableDirections = new List<string>();

        if (mapController.GetCellAtPosition(transform.position + Vector3.up) != null)
            availableDirections.Add("Up");

        if (mapController.GetCellAtPosition(transform.position + Vector3.down) != null)
            availableDirections.Add("Down");

        if (mapController.GetCellAtPosition(transform.position + Vector3.left) != null)
            availableDirections.Add("Left");

        if (mapController.GetCellAtPosition(transform.position + Vector3.right) != null)
            availableDirections.Add("Right");
        int directionCount = Random.Range(1, availableDirections.Count + 1);
        availableDirections = availableDirections.OrderBy(x => Random.value).ToList();
        for (int i = 0; i < directionCount; i++)
        {
            switch (availableDirections[i])
            {
                case "Up":
                    _directions.Up = true;
                    break;
                case "Down":
                    _directions.Down = true;
                    break;
                case "Left":
                    _directions.Left = true;
                    break;
                case "Right":
                    _directions.Right = true;
                    break;
            }
        }
    }

    private void FireArrow(Vector2 direction)
    {
        GameObject projectile = LeanPool.Spawn(_ArrowPrefab, transform.position, Quaternion.identity);

        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        projectile.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));

        Bullet bullet = projectile.GetComponent<Bullet>();
        bullet.InitBullet(Damage, _ArrowProperties, gameObject);
    }


    public struct Directions
    {
        public bool Up;
        public bool Down;
        public bool Left;
        public bool Right;
    }
}