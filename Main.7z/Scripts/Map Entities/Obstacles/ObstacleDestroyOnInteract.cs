using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleDestroyOnInteract : MonoBehaviour, IMapEntityInteractable
{
    private bool _isDestroying;

    public bool TryInteract()
    {
        if (_isDestroying) return false;

        _isDestroying = true;

        transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() => Destroy(gameObject));

        return true;
    }
}
