using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ObstacleElectricTower : MonoBehaviour, IMapEntityTurnMover, IMapEntityInteractable, IMapEntityAttack
{
    [field: SerializeField] public int MovePriority { get; private set; }
    [field: SerializeField] public float TimeToNextMove { get; private set; }

    [Space]
    [SerializeField] private GameObject _ProjectilePrefab;

    [field: Space]
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }
    [SerializeField] private float _AttackDistance;
    [SerializeField] private float _ProjectileDuration = 0.1f;
    [SerializeField] private int _MaxChainTargets = 10;

    [Space]
    [SerializeField] private List<AudioClip> _Sounds;

    private int _currentTurns;
    private int _turnToDestroy;
    private bool _isDestroying;

    private void Start()
    {
        _turnToDestroy = Random.Range(3,6);
    }

    public bool TryDoMove()
    {
        _currentTurns++;
        ShootAtTarget();

        if (_currentTurns >= _turnToDestroy)
        {
            DestroyTower();
            return true;
        }

        return false;
    }

    public bool TryInteract()
    {
        if (_isDestroying) return false;

        ShootAtTarget();

        return true;
    }

    private void ShootAtTarget()
    {
        List<EntityHealth> affectedTargets = new List<EntityHealth>();
        Vector3 currentSource = transform.position;
        ChainLightning(currentSource, affectedTargets, 0);
    }

    private void ChainLightning(Vector3 currentSource, List<EntityHealth> affectedTargets, int chainIndex)
    {
        if (chainIndex >= _MaxChainTargets) return;
        EntityHealth target = FindRandomTargetInRange(currentSource, affectedTargets);
        if (target == null) return;

        if (_Sounds.Count > 0)
        {
            AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];
            AudioController.Instance.PlaySound(clip, 0.6f);
        }

        affectedTargets.Add(target);
        Vector3 targetPosition = target.transform.position;
        GameObject projectile = LeanPool.Spawn(_ProjectilePrefab, currentSource, Quaternion.identity);
        List<Vector3> zigzagPath = GenerateLightningPath(currentSource, targetPosition);
        projectile.transform.DOPath(zigzagPath.ToArray(), _ProjectileDuration, PathType.CatmullRom)
            .SetEase(Ease.Linear)
            .OnComplete(() =>
            {
                target.ApplyDamage(Damage);
                LeanPool.Despawn(projectile);
                ChainLightning(targetPosition, affectedTargets, chainIndex + 1);
            });
    }
    private List<Vector3> GenerateLightningPath(Vector3 start, Vector3 end)
    {
        List<Vector3> path = new List<Vector3>();
        path.Add(start);
        int pointsCount = Random.Range(3, 6);
        for (int i = 1; i <= pointsCount; i++)
        {
            float t = (float)i / pointsCount;
            Vector3 point = Vector3.Lerp(start, end, t);
            point += new Vector3(
                Random.Range(-0.5f, 0.5f),
                Random.Range(-0.5f, 0.5f),
                0
            );

            path.Add(point);
        }

        path.Add(end);
        return path;
    }

    private EntityHealth FindRandomTargetInRange(Vector3 sourcePosition, List<EntityHealth> excludedTargets)
    {
        Collider2D[] hits = Physics2D.OverlapBoxAll(sourcePosition, Vector2.one * (_AttackDistance - 0.1f) * 2, 0);
        List<EntityHealth> potentialTargets = new List<EntityHealth>();

        foreach (var hit in hits)
        {
            EntityHealth entity = hit.GetComponent<EntityHealth>();
            if (entity != null && !excludedTargets.Contains(entity))
            {
                potentialTargets.Add(entity);
            }
        }

        if (potentialTargets.Count == 0) return null;
        return potentialTargets[Random.Range(0, potentialTargets.Count)];
    }

    private void DestroyTower()
    {
        _isDestroying = true;

        transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() => Destroy(gameObject));
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireCube(transform.position, Vector3.one * (_AttackDistance - 0.1f) * 2);
    }
}