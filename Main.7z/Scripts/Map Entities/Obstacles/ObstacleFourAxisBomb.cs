using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ObstacleFourAxisBomb : CellMovingEntity, IMapEntityTurnMover, IMapEntityInteractable, IMapEntityAttack
{
    [field: SerializeField] public int MovePriority { get; private set; }
    [field: SerializeField] public float TimeToNextMove { get; private set; }

    [field: Space]
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }

    [Space]
    [SerializeField] private float _ExplodeDistance = 10f;
    [SerializeField] private LayerMask _EntityLayerMask;
    [SerializeField] private int _TurnsToExplode;

    [Space]
    [SerializeField] private VFXController _ExplodeEffect;
    [SerializeField] private List<AudioClip> _Sounds;

    [Space]
    [SerializeField] private TextMeshPro _TurnsToExplodeText;

    private void Awake()
    {
        _animateMovement = false;

        UpdateBombText();
    }

    public bool TryInteract()
    {
        Vector3 playerPosition = PlayerManager.Instance.transform.position;
        Vector3 bombPosition = transform.position;

        Vector3 direction = bombPosition - playerPosition;
        Vector3 newBombPosition = bombPosition + direction;

        Cell newBombCell = _mapController.GetCellAtPosition(newBombPosition);
        if (TryMoveToCell(newBombCell))
        {
            return true;
        }

        return false;
    }

    public bool TryDoMove()
    {
        if (_TurnsToExplode > 1)
        {
            _TurnsToExplode--;
            UpdateBombText();
            return false;
        }

        Explode();
        _TurnsToExplodeText.DOKill();
        _TurnsToExplodeText.transform.DOKill();

        transform.DOScale(0, 0.4f)
            .OnComplete(() => Destroy(gameObject));

        return true;
    }

    private void Explode()
    {
        Vector2[] directions = new Vector2[]
        {
        Vector2.up,
        Vector2.down,
        Vector2.left,
        Vector2.right
        };

        foreach (Vector2 direction in directions)
        {
            RaycastHit2D[] hits = Physics2D.RaycastAll(transform.position, direction, _ExplodeDistance, _EntityLayerMask);

            foreach (RaycastHit2D hit in hits)
            {
                EntityHealth entityHealth = hit.collider.GetComponent<EntityHealth>();
                if (entityHealth != null)
                {
                    entityHealth.ApplyDamage(Damage);
                }
            }
        }
        Camera.main.GetComponent<CameraShake>().Shake(Damage);
        LeanPool.Spawn(_ExplodeEffect, transform.position, Quaternion.identity);

        AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];
        AudioController.Instance.PlaySound(clip, 0.6f);
    }
    private void UpdateBombText()
    {
        if (_TurnsToExplodeText != null)
        {
            _TurnsToExplodeText.text = _TurnsToExplode.ToString();

            if (_TurnsToExplode <= 1)
            {
                StartBlinkingAndScalingText();
            }
            else
            {
                _TurnsToExplodeText.DOKill();
                _TurnsToExplodeText.transform.localScale = Vector3.one;
                _TurnsToExplodeText.color = Color.white;
            }
        }
    }

    private void StartBlinkingAndScalingText()
    {
        _TurnsToExplodeText.DOColor(Color.red, 0.5f).SetLoops(-1, LoopType.Yoyo);
        _TurnsToExplodeText.transform.DOScale(1.2f, 0.5f).SetLoops(-1, LoopType.Yoyo).SetEase(Ease.InOutSine);
    }
}
