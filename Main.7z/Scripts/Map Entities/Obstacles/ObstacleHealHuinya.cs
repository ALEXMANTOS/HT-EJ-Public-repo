using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ObstacleHealHuinya : MonoBehaviour, IMapEntityTurnMover
{
    [field: SerializeField] public int MovePriority { get; private set; }
    [field: SerializeField] public float TimeToNextMove { get; private set; }

    [Space]
    [SerializeField] private float _HealValue;
    [SerializeField] private float _HealAreaSize = 5f;
    [SerializeField] private LayerMask _EntityLayerMask;

    [Space]
    [SerializeField] private VFXController _HealVFX;
    [SerializeField] private List<AudioClip> _Sounds;

    private int _destroyOnTurn;

    private TurnController _turnController;

    private void Start()
    {
        _turnController = GameManager.Instance.GetComponent<TurnController>();

        _destroyOnTurn = _turnController.CurrentTurn + Random.Range(2, 5);
    }
    public bool TryDoMove()
    {
        Heal();

        if (_turnController.CurrentTurn >= _destroyOnTurn)
        {
            transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() => Destroy(gameObject));
        }

        return true;
    }

    private void Heal()
    {
        float areaSize = _HealAreaSize - 0.1f;
        Vector2 halfExtents = new Vector2(areaSize / 2, areaSize / 2);
        Collider2D[] colliders = Physics2D.OverlapBoxAll(transform.position, halfExtents * 2, 0, _EntityLayerMask);

        foreach (Collider2D collider in colliders)
        {
            EntityHealth entityHealth = collider.GetComponent<EntityHealth>();
            if (entityHealth != null)
            {
                entityHealth.Heal(_HealValue);
            }
        }

        var vfx = LeanPool.Spawn(_HealVFX, transform.position, Quaternion.identity);
        vfx.SetEffectSize(Vector2.one * _HealAreaSize);

        if (_Sounds.Count > 0)
        {
            AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];
            AudioController.Instance.PlaySound(clip, 0.6f);
        }
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.green;
        float areaSize = _HealAreaSize - 0.1f;
        Vector2 halfExtents = new Vector2(areaSize / 2, areaSize / 2);
        Gizmos.DrawWireCube(transform.position, halfExtents * 2);
    }
}
