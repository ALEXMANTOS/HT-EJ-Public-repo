using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class ObstacleHellTower : MonoBehaviour, IMapEntityTurnMover,IMapEntityAttack
{
    [field: SerializeField] public int MovePriority { get; private set; }
    [field: SerializeField] public float TimeToNextMove { get; private set; }

    [Space]
    [SerializeField] private GameObject _TrailPrefab;
    [SerializeField] private Vector2 _SpawnOffset;
    [SerializeField] private float _SpawnDistance;

    [field: Space]
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }
    [SerializeField] private float _TotalDamageThreshold = 7f;
    [SerializeField] private float _TrailSpeed = 0.5f;
    [SerializeField] private float _DelayBetweenTrails = 0.1f;
    [SerializeField] private int _TrailsPerEnemy = 3;

    [Space]
    [SerializeField] private Slider _DamageProgressSlider;

    private float _accumulatedDamage = 0f;
    private bool _towerVse = false;

    [Space]
    [SerializeField] private float _AttackZoneSize;
    [SerializeField] private LayerMask _AttackMask;

    private List<EntityHealth> _findedHealthes = new List<EntityHealth>();

    private void Awake()
    {
        _DamageProgressSlider.maxValue = _TotalDamageThreshold;
        _DamageProgressSlider.value = 0;
    }

    public bool TryDoMove()
    {
        float areaSize = _AttackZoneSize - 0.1f;
        Vector2 halfExtents = new Vector2(areaSize / 2, areaSize / 2);

        _findedHealthes.Clear();
        _findedHealthes = Physics2D.OverlapBoxAll(transform.position, halfExtents * 2,0, _AttackMask)
            .Select(col => col.GetComponent<EntityHealth>())
            .Where(health => health != null)
            .ToList();

        if (_findedHealthes.Count > 0)
        {
            foreach (var health in _findedHealthes)
            {
                StartCoroutine(SpawnTrailsForEnemy(health));
            }
        }

        return true;
    }

    private IEnumerator SpawnTrailsForEnemy(EntityHealth health)
    {
        for (int i = 0; i < _TrailsPerEnemy; i++)
        {
            if (health == null) continue;

            SpawnTrail(health);
            yield return new WaitForSeconds(_DelayBetweenTrails);
        }

        yield return new WaitForSeconds(_TrailSpeed);

        if (_towerVse == false && _accumulatedDamage >= _TotalDamageThreshold - 0.001f)
        {
            _towerVse = true;
            transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() => Destroy(gameObject));
        }
    }

    private void SpawnTrail(EntityHealth health)
    {
        Vector3 baseSpawnPosition = transform.position + (Vector3)_SpawnOffset;
        Vector3 randomOffset = Random.insideUnitCircle.normalized * _SpawnDistance;
        Vector3 spawnPosition = baseSpawnPosition + new Vector3(randomOffset.x, randomOffset.y, 0);

        GameObject trailInstance = LeanPool.Spawn(_TrailPrefab, spawnPosition, Quaternion.identity);

        Vector3[] path = new Vector3[3];
        path[0] = spawnPosition;
        path[1] = (spawnPosition + health.transform.position) / 2 + new Vector3(Random.Range(-1f, 1f), Random.Range(-1f, 1f), 0);
        path[2] = health.transform.position;

        trailInstance.transform.DOPath(path, _TrailSpeed, PathType.CatmullRom)
        .SetEase(Ease.InOutSine)
        .OnUpdate(() =>
        {
            if (health == null)
            {
                trailInstance.transform.DOKill();
            }
        })
        .OnKill(() =>
        {
            if (trailInstance != null)
            {
                if(health != null)
                {
                    health.ApplyDamage(Damage);
                    _accumulatedDamage += Damage;
                    _DamageProgressSlider.value = _accumulatedDamage;
                }

                LeanPool.Despawn(trailInstance);
            }
        });
    }
    private void OnDrawGizmosSelected()
    {
        float areaSize = _AttackZoneSize - 0.1f;
        Vector2 halfExtents = new Vector2(areaSize / 2, areaSize / 2);

        Gizmos.color = Color.red;
        Gizmos.DrawWireCube(transform.position, halfExtents * 2);
        Gizmos.color = Color.cyan;
        Vector3 baseSpawnPosition = transform.position + (Vector3)_SpawnOffset;
        Gizmos.DrawWireSphere(baseSpawnPosition, _SpawnDistance);
    }
}
