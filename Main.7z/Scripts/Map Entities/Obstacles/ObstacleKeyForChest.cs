using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleKeyForChest : MapEntity�ollective
{
    private ObstacleChest _chest;

    protected override void OnCollect()
    {
        _chest.AddKey();
    }

    public void SetChest(ObstacleChest chest)
    {
        _chest = chest;
    }
}