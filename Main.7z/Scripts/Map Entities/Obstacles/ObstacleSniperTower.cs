using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

public class ObstacleSniperTower : MonoBehaviour, IMapEntityTurnMover,IMapEntityInteractable,IMapEntityAttack
{
    [field: SerializeField] public int MovePriority { get; private set; }
    [field: SerializeField] public float TimeToNextMove { get; private set; }

    [Space]
    [SerializeField] private GameObject _ProjectilePrefab;
    [SerializeField] private GameObject _ReticlePrefab;
    [SerializeField] private TMP_Text _TurnsText;

    [field: Space]
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }
    [SerializeField] private Vector2 _SpawnOffset;
    [SerializeField] private float _ProjectileDuration = 1f;
    [SerializeField] private int _TurnsUntilAttack = 5;

    [Space]
    [SerializeField] private List<AudioClip> _Sounds;

    private EntityHealth _target;
    private int _currentTurns;
    private GameObject _reticleInstance;
    private bool _isDestroying;

    private EntitiesSpawnController _entitiesSpawnController;

    private void Start()
    {
        _entitiesSpawnController = GameManager.Instance.GetComponent<EntitiesSpawnController>();

        Invoke("FindRandomTarget", 0.1f);

        _reticleInstance = Instantiate(_ReticlePrefab, transform.position, Quaternion.identity);
        UpdateTurnsText();
    }
    private void Update()
    {
        if (_isDestroying) return;

        if (!ReferenceEquals(_target, null) && _target == null)
        {
            FindRandomTarget();
        }

        UpdateReticlePosition();
    }

    public bool TryDoMove()
    {
        if (_target != null)
        {
            _currentTurns++;
            UpdateTurnsText();

            if (_currentTurns >= _TurnsUntilAttack)
            {
                ShootAtTarget();
                return true;
            }
        }
        return false;
    }
    public bool TryInteract()
    {
        if (_isDestroying) return false;

        FindRandomTarget();

        if(_target == null)
        {
            _isDestroying = true;
            _reticleInstance.transform
                .DOMove(transform.position, 0.5f)
                .SetEase(Ease.Linear)
                .OnComplete(() =>
                {
                    ShootAtSelf();
                });
        }

        return true;
    }


    private void FindRandomTarget()
    {
        string[] exludeTeams = { "Obstacle" };
        List<GameObject> exludeObjects = new List<GameObject>();

        GameObject randomEntity = null;

        if(_target != null)
        {
            exludeObjects.Add(_target.gameObject);
            _target = null;
        }

        do
        {
            randomEntity = _entitiesSpawnController.GetRandomEntityExclude(exludeTeams, exludeObjects.ToArray());
            if (randomEntity != null)
            {
                _target = randomEntity.GetComponent<EntityHealth>();
                if (_target != null)
                {
                    return;
                }
                else
                {
                    exludeObjects.Add(randomEntity);
                }
            }
        }
        while (_target == null && randomEntity != null);
    }

    private void UpdateReticlePosition()
    {
        if (_target != null && _reticleInstance != null)
        {
            _reticleInstance.transform
                .DOMove(_target.transform.position, 0.3f)
                .SetEase(Ease.Linear);
        }
    }

    private void UpdateTurnsText()
    {
        if (_TurnsText != null)
        {
            _TurnsText.text = $"{_TurnsUntilAttack - _currentTurns}";
        }
    }

    private void ShootAtTarget()
    {
        if (_target != null)
        {
            Vector3 spawnPosition = transform.position + (Vector3)_SpawnOffset;
            GameObject projectileInstance = LeanPool.Spawn(_ProjectilePrefab, spawnPosition, Quaternion.identity);

            AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];
            AudioController.Instance.PlaySound(clip, 0.6f);

            projectileInstance.transform
                .DOMove(_target.transform.position, _ProjectileDuration)
                .SetEase(Ease.Linear)
                .OnComplete(() =>
                {
                    _target?.ApplyDamage(Damage);
                    LeanPool.Despawn(projectileInstance);
                    DestroyTower();
                });
        }
    }
    private void ShootAtSelf()
    {
        DestroyTower();
    }

    private void DestroyTower()
    {
        _isDestroying = true;

        _reticleInstance.transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() => Destroy(_reticleInstance));
        transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() => Destroy(gameObject));
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position + (Vector3)_SpawnOffset, 0.1f);
    }
}