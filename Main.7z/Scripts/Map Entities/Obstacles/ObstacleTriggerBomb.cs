using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ObstacleTriggerBomb : MonoBehaviour, IMapEntityInteractable, IMapEntityAttack
{
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }

    [Space]
    [SerializeField] private float _ExplodeAreaSize = 5f;
    [SerializeField] private LayerMask _EntityLayerMask;
    [SerializeField] private float _TimeToExplode;

    [Space]
    [SerializeField] private VFXController _ExplodeEffect;
    [SerializeField] private List<AudioClip> _Sounds;

    [Space]
    [SerializeField] private TextMeshPro _TimeToExplodeText;

    private bool _isDefused = false;
    private float _currentTime;
    private Tween _blinkTween;

    private void Start()
    {
        _currentTime = _TimeToExplode;
        UpdateBombText();
        StartCountdown();
    }

    private void Update()
    {
        if (!_isDefused)
        {
            _currentTime -= Time.deltaTime;
            UpdateBombText();

            if (_currentTime <= 0)
            {
                _isDefused = true;

                Explode();

                transform.DOScale(0, 0.4f)
                .OnComplete(() => Destroy(gameObject));
            }
        }
    }

    public bool TryInteract()
    {
        if (_isDefused) return false;

        _isDefused = true;
        StopBlinkingText();
        _TimeToExplodeText.color = Color.cyan;

        transform.DOScale(0, 0.4f).SetDelay(0.6f).SetEase(Ease.InBack)
        .OnComplete(() => Destroy(gameObject));

        return true;
    }

    private void Explode()
    {
        float areaSize = _ExplodeAreaSize - 0.1f;
        Vector2 halfExtents = new Vector2(areaSize / 2, areaSize / 2);
        Collider2D[] colliders = Physics2D.OverlapBoxAll(transform.position, halfExtents * 2, 0, _EntityLayerMask);

        foreach (Collider2D collider in colliders)
        {
            EntityHealth entityHealth = collider.GetComponent<EntityHealth>();
            if (entityHealth != null)
            {
                entityHealth.ApplyDamage(Damage);
            }
        }

        Camera.main.GetComponent<CameraShake>().Shake(Damage);

        VFXController explodeVfx = LeanPool.Spawn(_ExplodeEffect, transform.position, Quaternion.identity);
        explodeVfx.SetEffectSize(halfExtents * 2);

        AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];
        AudioController.Instance.PlaySound(clip, 0.6f);
    }

    private void UpdateBombText()
    {
        int seconds = Mathf.CeilToInt(_currentTime);
        _TimeToExplodeText.text = seconds.ToString();

        if (seconds <= 5 && !_isDefused && _blinkTween == null)
        {
            StartBlinkingText();
        }
    }

    private void StartCountdown()
    {
        _currentTime = _TimeToExplode;
    }

    private void StartBlinkingText()
    {
        _blinkTween = _TimeToExplodeText.DOColor(Color.red, 0.5f).SetLoops(-1, LoopType.Yoyo);
        _TimeToExplodeText.transform.DOScale(1.2f, 0.5f).SetLoops(-1, LoopType.Yoyo).SetEase(Ease.InOutSine);
    }

    private void StopBlinkingText()
    {
        _blinkTween?.Kill();
        _TimeToExplodeText.transform.DOKill();
        _TimeToExplodeText.transform.localScale = Vector3.one;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        float areaSize = _ExplodeAreaSize - 0.1f;
        Vector2 halfExtents = new Vector2(areaSize / 2, areaSize / 2);
        Gizmos.DrawWireCube(transform.position, halfExtents * 2);
    }
}