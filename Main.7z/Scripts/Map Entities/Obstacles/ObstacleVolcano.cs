using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleVolcano : MonoBehaviour, IMapEntityTurnMover,IMapEntityAttack
{
    [field: SerializeField] public int MovePriority { get; private set; }
    public float TimeToNextMove
    {
        get => GetTimeToNextMove();
        private set => _timeToNextMove = value;
    }
    private float _timeToNextMove;

    [field: Space]
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }
    [SerializeField] private int _NumberOfCellsToTarget = 3;
    [SerializeField] private bool _DestroyAfterTime;

    [Space]
    [SerializeField] private GameObject _RectilePrefab;
    [SerializeField] private GameObject _ProjectilePrefab;
    [SerializeField] private Transform _ProjectileStartPoint;
    [SerializeField] private float _ProjectileDuration = 5f;
    [SerializeField] private float _ProjectileArcHeight = 2f;
    [SerializeField] private float _ProjectilesDelay;

    [Space]
    [SerializeField] private List<AudioClip> _Sounds;

    private List<Cell> _targetCells = new List<Cell>();
    private List<GameObject> _targetRectiles = new List<GameObject>();
    private bool _isTargetingTurn = true;
    private int _destroyOnTurn;

    private MapController _mapController;
    private TurnController _turnController;

    private void Start()
    {
        _mapController = GameManager.Instance.GetComponent<MapController>();
        _turnController = GameManager.Instance.GetComponent<TurnController>();

        _destroyOnTurn = _turnController.CurrentTurn + Random.Range(4, 9);
    }
    private float GetTimeToNextMove()
    {
        if (!_isTargetingTurn) return 0.5f;
        else return _NumberOfCellsToTarget * _ProjectilesDelay + _ProjectileDuration;
    }

    public bool TryDoMove()
    {
        if (_isTargetingTurn)
        {
            SelectRandomCells();
            ShowTargetRectiles();
            _isTargetingTurn = false;
        }
        else
        {
            FireAtSelectedCells();
            HideTargetRectiles();

            if (_DestroyAfterTime && _turnController.CurrentTurn >= _destroyOnTurn)
            {
                Invoke("DestroyVolcano", TimeToNextMove);
            }

            _isTargetingTurn = true;
        }

        return true;
    }

    private void SelectRandomCells()
    {
        _targetCells.Clear();

        _targetCells = _mapController.GetRandomFreeCells(_NumberOfCellsToTarget);
    }

    private void ShowTargetRectiles()
    {
        HideTargetRectiles();
        foreach (var cell in _targetCells)
        {
            var indicator = Instantiate(_RectilePrefab, cell.transform.position, Quaternion.identity);
            indicator.transform.localScale = Vector3.zero;
            indicator.transform.DOScale(1, 0.5f).SetEase(Ease.OutBack);

            _targetRectiles.Add(indicator);
        }
    }

    private void HideTargetRectiles()
    {
        foreach (var indicator in _targetRectiles)
        {
            indicator.transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() =>
            {
                Destroy(indicator);
            });
        }
        _targetRectiles.Clear();
    }

    private void FireAtSelectedCells()
    {
        for (int i = 0; i < _targetCells.Count; i++)
        {
            Cell targetCell = _targetCells[i];
            float delay = i * _ProjectilesDelay;
            StartCoroutine(FireProjectileWithDelay(targetCell, delay));
        }
    }

    private IEnumerator FireProjectileWithDelay(Cell targetCell, float delay)
    {
        yield return new WaitForSeconds(delay);
        FireProjectile(targetCell);
    }

    private void FireProjectile(Cell targetCell)
    {
        Vector2 startPosition = _ProjectileStartPoint != null ? _ProjectileStartPoint.position : transform.position;
        Vector2 targetPosition = targetCell.transform.position;

        GameObject projectile = LeanPool.Spawn(_ProjectilePrefab, startPosition, Quaternion.identity);
        Sequence projectileSequence = DOTween.Sequence();
        float midPointY = Mathf.Max(startPosition.y, targetPosition.y) + _ProjectileArcHeight;
        Vector2 midPoint = new Vector2((startPosition.x + targetPosition.x) / 2, midPointY);

        AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];
        AudioController.Instance.PlaySound(clip, 0.6f);
        projectileSequence.Append(projectile.transform.DOMove(midPoint, _ProjectileDuration / 2).SetEase(Ease.OutQuad));
        projectileSequence.Append(projectile.transform.DOMove(targetPosition, _ProjectileDuration / 2).SetEase(Ease.InCubic))
            .OnComplete(() => OnProjectileLanded(projectile, targetCell));
    }

    private void OnProjectileLanded(GameObject projectile, Cell targetCell)
    {
        LeanPool.Despawn(projectile);
        var occupant = targetCell.Occupant;
        if (occupant != null)
        {
            var damageable = occupant.GetComponent<EntityHealth>();
            if (damageable != null)
            {
                damageable.ApplyDamage(Damage);
            }
        }
    }

    private void DestroyVolcano()
    {
        transform.DOScale(0, 0.5f).SetEase(Ease.InBack).OnComplete(() => Destroy(gameObject));
    }
}