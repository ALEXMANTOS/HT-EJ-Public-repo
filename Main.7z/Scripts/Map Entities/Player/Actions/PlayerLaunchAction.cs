using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerLaunchAction : PlayerAttackAction
{
    [Space]
    [SerializeField] private GameObject _ProjectilePrefab;
    [SerializeField] private float _ProjectileDuration = 1f;
    [SerializeField] private float _ProjectileArcHeight = 2f;

    private MapController _mapController;

    private void Awake()
    {
        _mapController = GameManager.Instance.GetComponent<MapController>();

        _ActionForScreen = PlayerControlsUIController.ActionForScreen.Cells;
    }

    protected override bool ActionHandler(Vector2 targetMovePosition)
    {
        Cell targetCell = _mapController.GetCellAtPosition(targetMovePosition);

        if (targetCell != null)
        {
            FireProjectile(targetCell);
        }

        return true;
    }

    private void FireProjectile(Cell targetCell)
    {
        Vector2 startPosition = transform.position;
        Vector2 targetPosition = targetCell.transform.position;

        GameObject projectile = LeanPool.Spawn(_ProjectilePrefab, startPosition, Quaternion.identity);
        Sequence projectileSequence = DOTween.Sequence();
        float midPointY = Mathf.Max(startPosition.y, targetPosition.y) + _ProjectileArcHeight;
        Vector2 midPoint = new Vector2((startPosition.x + targetPosition.x) / 2, midPointY);
        projectileSequence.Append(projectile.transform.DOMove(midPoint, _ProjectileDuration / 2).SetEase(Ease.OutQuad));
        projectileSequence.Append(projectile.transform.DOMove(targetPosition, _ProjectileDuration / 2).SetEase(Ease.InCubic))
            .OnComplete(() => OnProjectileLanded(projectile, targetCell));
    }

    private void OnProjectileLanded(GameObject projectile, Cell targetCell)
    {
        LeanPool.Despawn(projectile);
        var occupant = targetCell.Occupant;
        if (occupant != null)
        {
            var damageable = occupant.GetComponent<EntityHealth>();
            if (damageable != null)
            {
                damageable.ApplyDamage(Damage);
            }
        }
    }
}