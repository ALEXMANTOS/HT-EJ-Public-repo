using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerRayShootAction : PlayerAttackAction
{
    [Space]
    [SerializeField] private GameObject _ProjectilePrefab;

    [Space]
    [SerializeField] private float _RaySpeed;
    [SerializeField] private int _PenetrateCount;

    private readonly HashSet<Collider2D> _hitTargets = new HashSet<Collider2D>();

    private void Awake()
    {
        _ActionForScreen = PlayerControlsUIController.ActionForScreen.Main;
    }

    protected override bool ActionHandler(Vector2 targetMovePosition)
    {
        Vector2 startPosition = transform.position;
        Vector2 direction = (targetMovePosition - startPosition).normalized;

        int remainingPenetrations = _PenetrateCount;
        Vector2 currentStartPosition = startPosition;
        List<Vector2> hitPoints = new List<Vector2> { startPosition };

        while (remainingPenetrations > 0)
        {
            RaycastHit2D hit = Physics2D.Raycast(currentStartPosition, direction, Mathf.Infinity, ~LayerMask.GetMask("Player"));
            if (hit.collider != null)
            {
                if (!_hitTargets.Contains(hit.collider))
                {
                    hitPoints.Add(hit.point);
                    _hitTargets.Add(hit.collider);
                    if (hit.collider.TryGetComponent(out EntityHealth hp))
                    {
                        hp.ApplyDamage(Damage);
                    }

                    remainingPenetrations--;
                    currentStartPosition = hit.point + direction * 0.1f;
                }
                else
                {
                    currentStartPosition = hit.point + direction * 0.1f;
                    continue;
                }
            }
            else
            {
                hitPoints.Add(currentStartPosition + direction * 10);
                break;
            }
        }

        AnimateProjectilePath(hitPoints);
        return true;
    }

    private void AnimateProjectilePath(List<Vector2> pathPoints)
    {
        GameObject projectile = LeanPool.Spawn(_ProjectilePrefab, pathPoints[0], Quaternion.identity);

        Sequence animationSequence = DOTween.Sequence();
        for (int i = 1; i < pathPoints.Count; i++)
        {
            animationSequence.Append(projectile.transform.DOMove(pathPoints[i], Vector2.Distance(pathPoints[i - 1], pathPoints[i]) / _RaySpeed));
        }

        animationSequence.OnComplete(() =>
        {
            LeanPool.Despawn(projectile);
            _hitTargets.Clear();
        });
    }
}