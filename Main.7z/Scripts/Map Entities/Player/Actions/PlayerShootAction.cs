using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class PlayerShootAction : PlayerAttackAction
{
    [Space]
    [SerializeField] private GameObject _ProjectilePrefab;

    [Space]
    [SerializeField] private BulletProperties _Properties;

    private void Awake()
    {
        _ActionForScreen = PlayerControlsUIController.ActionForScreen.Main;
    }

    protected override bool ActionHandler(Vector2 targetMovePosition)
    {
        GameObject projectile = LeanPool.Spawn(_ProjectilePrefab, transform.position, Quaternion.identity);
        Vector2 direction = targetMovePosition - (Vector2)transform.position;

        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        projectile.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));

        Bullet bullet = projectile.GetComponent<Bullet>();
        bullet.InitBullet(Damage, _Properties, gameObject);

        return true;
    }
}
