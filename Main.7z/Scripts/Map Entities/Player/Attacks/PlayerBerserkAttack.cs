using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBerserkAttack : PlayerAttack
{
    [SerializeField] private int _BonusDamageDuration = 4;
    [SerializeField] private float _BonusDamageMultiplier = 1;

    private float _baseDemage;

    [Space]
    [SerializeField] private Sprite _EffectIcon;
    private const string EFFECT_NAME = "Berserk";

    private float _currentBonusDamage = 0;
    private int _remainingTurns = 0;

    private PlayerHealth _health;
    private PlayerEffectsUIController _playerEffectsUIController;

    protected new void Start()
    {
        base.Start();

        _baseDemage = Damage;

        _health = GetComponent<PlayerHealth>();
        _playerEffectsUIController = PlayerEffectsUIController.Instance;

        _health.OnDamaged += OnPlayerTakeDamage;
        GameManager.Instance.GetComponent<TurnController>().OnNewTurnStarted += OnTurnStart;
    }

    public override bool TryDoMove(Vector2 targetMovePosition)
    {
        Cell targetCell = _mapController.GetCellAtPosition(targetMovePosition);

        if (targetCell?.Occupant != null && targetCell.Occupant.TryGetComponent(out EntityHealth health))
        {
            float appliedDamage = 0;
            health.ApplyDamage(Damage,ref appliedDamage);
            _onDamageApplied?.Invoke(appliedDamage);
            return true;
        }

        return false;
    }

    private void OnPlayerTakeDamage(float damage)
    {
        _currentBonusDamage += damage;
        _remainingTurns = _BonusDamageDuration;

        Damage = _baseDemage + _currentBonusDamage * _BonusDamageMultiplier;

        if (!_playerEffectsUIController.EffectExist(EFFECT_NAME))
        {
            _playerEffectsUIController.AddUIEffect(EFFECT_NAME,_EffectIcon,_remainingTurns);
        }
        else
        {
            _playerEffectsUIController.UpdateUIEffectStatus(EFFECT_NAME, _remainingTurns);
        }
    }

    private void OnTurnStart(string teamName)
    {
        if (teamName != "Player") return;

        if (_remainingTurns > 0)
        {
            _remainingTurns--;
            _playerEffectsUIController.UpdateUIEffectStatus(EFFECT_NAME, _remainingTurns);

            if (_remainingTurns == 0)
            {
                _currentBonusDamage = 0;
                Damage = _baseDemage;
                _playerEffectsUIController.RemoveUIEffect(EFFECT_NAME);
            }
        }
    }
}