using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDenAttack : PlayerAttack
{
    [SerializeField] private float _BonusDamage;
    [SerializeField] private int _BonusDamageTurnsThreshold;

    public override bool TryDoMove(Vector2 targetMovePosition)
    {
        Cell targetCell = _mapController.GetCellAtPosition(targetMovePosition);

        if (targetCell?.Occupant != null && targetCell.Occupant.TryGetComponent(out EntityHealth health))
        {
            float damage = Damage;

            if(targetCell.Occupant.GetComponent<MapEntityTurnController>().LivedTurns < _BonusDamageTurnsThreshold)
            {
                damage += _BonusDamage;
            }

            float appliedDamage = 0;
            health.ApplyDamage(damage, ref appliedDamage);
            _onDamageApplied?.Invoke(appliedDamage);

            return true;
        }

        return false;
    }
}
