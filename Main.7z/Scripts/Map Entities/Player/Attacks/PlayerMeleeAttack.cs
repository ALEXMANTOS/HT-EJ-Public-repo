using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMeleeAttack : PlayerAttack
{
    public override bool TryDoMove(Vector2 targetMovePosition)
    {
        Cell targetCell = _mapController.GetCellAtPosition(targetMovePosition);

        if(targetCell?.Occupant != null && targetCell.Occupant.TryGetComponent(out EntityHealth health))
        {
            float appliedDamage = 0;
            health.ApplyDamage(Damage,ref appliedDamage);
            _onDamageApplied?.Invoke(appliedDamage);
            return true;
        }

        return false;
    }
}