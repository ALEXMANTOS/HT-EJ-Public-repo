using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(PlayerHealth))]
public class PlayerVampireMeleeAttack : PlayerAttack
{
    [SerializeField] private float _HealAmount;
    [SerializeField] private float _DamageToHealThreshold;

    [Space]
    [SerializeField] private Sprite _EffectIcon;
    private const string _effectName = "vampire heal";

    private float _accumulatedDamage;

    private PlayerHealth _playerHealth;
    private PlayerEffectsUIController _playerEffectsUIController;

    private void Awake()
    {
        _playerHealth = GetComponent<PlayerHealth>();
        _playerEffectsUIController = PlayerEffectsUIController.Instance;
    }

    protected new void Start()
    {
        base.Start();

        _playerEffectsUIController.AddUIEffect(_effectName, _EffectIcon,_DamageToHealThreshold);
    }

    public override bool TryDoMove(Vector2 targetMovePosition)
    {
        Cell targetCell = _mapController.GetCellAtPosition(targetMovePosition);

        if (targetCell?.Occupant != null && targetCell.Occupant.TryGetComponent(out EntityHealth health))
        {
            float appliedDamage = 0;
            health.ApplyDamage(Damage,ref appliedDamage);
            _onDamageApplied?.Invoke(appliedDamage);
            _accumulatedDamage += appliedDamage;

            if (_accumulatedDamage >= _DamageToHealThreshold - 0.001f)
            {
                _playerHealth.Heal(_HealAmount);
                _accumulatedDamage = 0; 
            }

            _playerEffectsUIController.UpdateUIEffectStatus(_effectName,_DamageToHealThreshold - _accumulatedDamage);

            return true;
        }

        return false;
    }
}