using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDodgeHealth : PlayerHealth
{
    [Space]
    [SerializeField][Range(0,100)] private float _DodgeChance;
    [SerializeField] private VFXController _DodgeVFX;
    [SerializeField] private AudioClip _DodgeSFX;

    public override void ApplyDamage(float damage)
    {
        float[] _probalitys = { _DodgeChance, 100 - _DodgeChance };
        int? randomIndex = ProbalityRandom.RandomRange(_probalitys);

        if (randomIndex == 0) 
        {
            Dodge();

            return;
        }

        base.ApplyDamage(damage);
    }
    public override void ApplyDamage(float damage, ref float appliedDamage)
    {
        float[] _probalitys = { _DodgeChance, 100 - _DodgeChance };
        int? randomIndex = ProbalityRandom.RandomRange(_probalitys);

        if (randomIndex == 0) return;

        base.ApplyDamage((float)damage, ref appliedDamage);
    }

    private void Dodge()
    {
        VFXController explodeVfx = LeanPool.Spawn(_DodgeVFX, transform.position, Quaternion.identity);
        AudioController.Instance.PlaySound(_DodgeSFX);
    }
}