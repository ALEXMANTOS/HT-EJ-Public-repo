using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class PlayerAction : MonoBehaviour,IPlayerTurnMover
{
    [field: SerializeField] public int MovePriority { get; protected set; }
    [field: SerializeField] public float TimeToNextMove { get; protected set; }

    [Space]
    [SerializeField] protected VFXController _ActionActivationVFX;
    [SerializeField] protected VFXController _ActionCancelVFX;

    [Space]
    [SerializeField] private List<AudioClip> _Sounds;

    protected PlayerControlsUIController.ActionForScreen _ActionForScreen;

    private bool _actionActive;

    private void Start()
    {
        if(_ActionForScreen == PlayerControlsUIController.ActionForScreen.Main)
        {
            PlayerControlsUIController.Instance.EnableActionButton(_ActionForScreen, (Vector2 direction) =>
            {
                GetComponent<PlayerTurnController>().TryDoMove(direction);
            }, () =>
            {
                ActionActivation();
            },() =>
            {
                ActionCancel();
            });
        }
        else
        {
            PlayerControlsUIController.Instance.EnableActionButton(_ActionForScreen,(Vector2 cellPosition) =>
            {
                _actionActive = true;
                GetComponent<PlayerTurnController>().TryDoMoveAtCell(cellPosition);
            }, () =>
            {
                ActionActivation();
            }, () =>
            {
                ActionCancel();
            });
        }
    }
    private void ActionActivation()
    {
        _actionActive = true;
        LeanPool.Spawn(_ActionActivationVFX, transform.position, Quaternion.identity);
    }
    private void ActionCancel()
    {
        _actionActive = false;
        LeanPool.Spawn(_ActionCancelVFX, transform.position, Quaternion.identity);
    }

    public bool TryDoMove(Vector2 targetMovePosition)
    {
        if(_actionActive == false)
        {
            return false;
        }

        if (_Sounds.Count > 0)
        {
            AudioClip clip = _Sounds[Random.Range(0, _Sounds.Count)];
            AudioController.Instance.PlaySound(clip, 0.6f);
        }

        return ActionHandler(targetMovePosition);
    }

    protected abstract bool ActionHandler(Vector2 targetMovePositionl);
}