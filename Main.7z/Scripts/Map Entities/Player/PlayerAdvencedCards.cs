using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class PlayerAdvencedCards : MonoBehaviour
{
    [SerializeField][Range(0,6)] private int _StartRandomCardsCount;
    [SerializeField] private List<CardData> _StartCards;

    [Space]
    [SerializeField] private List<CardData> _NecessarilyStartCards;
    [SerializeField] private List<CardData> _UniqueCards;

    private DeckController _deckController;

    private void Start()
    {
        _deckController = GameManager.Instance.GetComponent<DeckController>();

        foreach (CardData card in _NecessarilyStartCards)
        {
            if (CharactersAndCardsUnlockController.Instance.IsCardUnlocked(card.CardName.TableEntryReference.KeyId.ToString()))
            {
                _deckController.TryAddCardToDeck(card);
            }
        }

        var maxPlayerEnergy = GetComponent<PlayerEnergy>()._MaxEnergy;
        List<CardData> unlockedCards = _StartCards
           .Where(card => CharactersAndCardsUnlockController.Instance.IsCardUnlocked(card.CardName.TableEntryReference.KeyId.ToString())
                          && card.EnergyCost <= maxPlayerEnergy)
           .ToList();

        for (int i = 0; i < _StartRandomCardsCount && unlockedCards.Count > 0; i++)
        {
            int randomIndex = Random.Range(0, unlockedCards.Count);
            CardData card = unlockedCards[randomIndex];
            _deckController.TryAddCardToDeck(card);
            unlockedCards.RemoveAt(randomIndex);
        }
    }

    public List<CardData> GetUniqueCards()
    {
        return _UniqueCards;
    }
}
