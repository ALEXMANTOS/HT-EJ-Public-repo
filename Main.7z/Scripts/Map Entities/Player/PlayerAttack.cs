using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class PlayerAttack : MonoBehaviour, IPlayerTurnMover, IPlayerMeleeAttack
{
    protected Action<float> _onDamageApplied;
    event Action<float> IPlayerMeleeAttack.OnDamageApplied
    {
        add
        {
            _onDamageApplied += value;
        }
        remove
        {
            _onDamageApplied -= value;
        }
    }

    [field: SerializeField] public int MovePriority { get; protected set; }
    [field: SerializeField] public float TimeToNextMove { get; protected set; }

    [field: Space]
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }

    protected MapController _mapController;

    protected void Start()
    {
        _mapController = GameManager.Instance.GetComponent<MapController>();
    }

    public abstract bool TryDoMove(Vector2 targetMovePosition);
}
