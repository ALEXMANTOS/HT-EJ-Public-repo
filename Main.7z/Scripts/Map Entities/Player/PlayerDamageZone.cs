using DG.Tweening;
using Lean.Pool;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDamageZone : MonoBehaviour, IPlayerMeleeAttack
{
    protected event Action<float> _onDamageApplied;
    event Action<float> IPlayerMeleeAttack.OnDamageApplied
    {
        add
        {
            _onDamageApplied += value;
        }
        remove
        {
            _onDamageApplied -= value;
        }
    }
    [field: SerializeField] public float Damage { get; protected set; }
    [field: SerializeField] public AttackType AttackType { get; protected set; }

    [SerializeField] private float _DamageZoneSize = 5f;
    [SerializeField] private LayerMask _EntityLayerMask;

    [Space]
    [SerializeField] private VFXController _DamageVFX;

    private void Start()
    {
        GameManager.Instance.GetComponent<TurnController>().OnNewTurnStarted += ApplyDamage;
    }

    private void ApplyDamage(string teamName)
    {
        if (teamName != "Player") return;

        float areaSize = _DamageZoneSize - 0.1f;
        Vector2 halfExtents = new Vector2(areaSize / 2, areaSize / 2);
        Collider2D[] colliders = Physics2D.OverlapBoxAll(transform.position, halfExtents * 2, 0, _EntityLayerMask);

        foreach (Collider2D collider in colliders)
        {
            EntityHealth entityHealth = collider.GetComponent<EntityHealth>();
            if (entityHealth != null)
            {
                float appliedDamage = 0;
                entityHealth.ApplyDamage(Damage,ref appliedDamage);
                _onDamageApplied?.Invoke(appliedDamage);
            }
        }

        var vfx = LeanPool.Spawn(_DamageVFX, transform.position, Quaternion.identity);
        vfx.SetEffectSize(Vector2.one * _DamageZoneSize);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        float areaSize = _DamageZoneSize - 0.1f;
        Vector2 halfExtents = new Vector2(areaSize / 2, areaSize / 2);
        Gizmos.DrawWireCube(transform.position, halfExtents * 2);
    }
}