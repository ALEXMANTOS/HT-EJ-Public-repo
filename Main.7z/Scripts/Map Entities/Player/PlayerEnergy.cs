using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerEnergy : MonoBehaviour
{
    public event Action<float> OnEnergyPointsChanged;

    [Header("Energy")]
    [SerializeField] private float maxEnergy;
    [SerializeField] private float currentEnergy;
    public float _MaxEnergy { get { return maxEnergy; } private set { maxEnergy = value; } }
    public float _CurrentEnergy { get { return currentEnergy; } private set { currentEnergy = value; } }

    public bool CheckEnergy(float energy)
    {
        if (_CurrentEnergy < energy)
            return false;

        return true;
    }
    public bool TrySpendEnergy(float energy)
    {
        if(_CurrentEnergy < energy)
            return false;

        _CurrentEnergy -= energy;
        OnEnergyPointsChanged?.Invoke(_CurrentEnergy);

        return true;
    }
    public void AddEnergy(float energy)
    {
        _CurrentEnergy += energy;
        
        if(_CurrentEnergy > _MaxEnergy)
        {
            _CurrentEnergy = _MaxEnergy;
        }

        OnEnergyPointsChanged?.Invoke(_CurrentEnergy);
    }
}