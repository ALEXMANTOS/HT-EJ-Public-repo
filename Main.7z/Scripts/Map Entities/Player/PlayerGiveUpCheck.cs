using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(PlayerTurnController))]
public class PlayerGiveUpCheck : MonoBehaviour
{
    private PlayerTurnController _playerTurnController;
    private GameOverController _gameOverController;
    private MapController _mapController;

    private void Start()
    {
        _playerTurnController = GetComponent<PlayerTurnController>();
        _gameOverController = GameManager.Instance.GetComponent<GameOverController>();
        _mapController = GameManager.Instance.GetComponent<MapController>();

        _playerTurnController.OnMoved += () => StartCoroutine(Check());

        GameManager.Instance.GetComponent<TurnController>()
            .SubscribeToTeamTurnStartEvent("Player", Check);
    }

    private IEnumerator Check()
    {
        List<Cell> neighboringCells = _mapController.GetNeighborCells(_mapController.GetCellAtPosition(transform.position));

        bool allOccupied = true;
        bool hasEntityWithHealth = false;

        foreach (Cell cell in neighboringCells)
        {
            if (cell.Occupant == null)
            {
                allOccupied = false;
                break;
            }
            else
            {
                GameObject occupant = cell.Occupant;
                if (occupant != null && occupant.GetComponent<EntityHealth>() != null)
                {
                    hasEntityWithHealth = true;
                    break;
                }
            }
        }

        if (allOccupied && !hasEntityWithHealth)
        {
            _gameOverController.OpenGiveUpPanel();
        }
        else
        {
            _gameOverController.CloseGiveUpPanel();
        }

        yield return null;
    }
}