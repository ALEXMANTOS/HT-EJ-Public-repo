using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class PlayerHealth : EntityHealth
{
    protected override void Death()
    {
        if (GameManager.Instance.GetComponent<GameOverController>().GameIsOver) return;

        GameManager.Instance.GetComponent<GameOverController>().GameOver();
    }
}