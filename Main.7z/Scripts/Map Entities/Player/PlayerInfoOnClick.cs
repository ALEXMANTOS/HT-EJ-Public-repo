using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PlayerInfoOnClick : MapEntityInfoOnClickBase
{
    [SerializeField] private CharacterSelectiveInfoData _CharacterSelectiveData;
    public override string EntityName => _CharacterSelectiveData.CharacterName.GetLocalizedString();
    public override Sprite EntityIcon => _CharacterSelectiveData.Icon;
    public override string EntityDescription => _CharacterSelectiveData.Description.GetLocalizedString();
}
