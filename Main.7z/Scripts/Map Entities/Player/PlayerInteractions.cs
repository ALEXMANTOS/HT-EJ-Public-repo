using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInteractions : MonoBehaviour,IPlayerTurnMover
{
    [field: SerializeField] public int MovePriority { get; private set; }
    [field: SerializeField] public float TimeToNextMove { get; private set; }

    public bool TryDoMove(Vector2 targetMovePosition)
    {
        Cell targetCell = GameManager.Instance.GetComponent<MapController>().GetCellAtPosition(targetMovePosition);

        if (targetCell?.Occupant != null && targetCell.Occupant.TryGetComponent(out IMapEntityInteractable interaction))
        {
            return interaction.TryInteract();
        }

        return false;
    }
}
