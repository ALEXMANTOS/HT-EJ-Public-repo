using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class PlayerMovement : CellMovingEntity,IPlayerTurnMover
{
    [field:SerializeField] public int MovePriority { get; private set; }
    public float TimeToNextMove { get; private set; }

    private void Awake()
    {
        TimeToNextMove = MoveDuration;
    }

    public bool TryDoMove(Vector2 targetMovePosition)
    {
        Cell targetCell = _mapController.GetCellAtPosition(targetMovePosition);

        if (targetCell?.Occupant != null && targetCell.Occupant.TryGetComponent(out MapEntity�ollective collective))
        {
            _mapController.ClearCellOccupant(_mapController.GetCellAtPosition(collective.transform.position));
        }

        return TryMoveToCell(targetCell);
    }
}