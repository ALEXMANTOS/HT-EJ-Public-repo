using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class PlayerTurnController : MapEntityTurnController
{
    private Vector2 _targetMovePosition;

    private new List<IPlayerTurnMover> _turnMovers;
    private float _NextMoveTime;

    private MapController _mapController;

    private new void Start()
    {
        _turnMovers = GetComponents<IPlayerTurnMover>().ToList();
        _turnMovers.Sort((a, b) => a.MovePriority.CompareTo(b.MovePriority));

        _turnController = GameManager.Instance.GetComponent<TurnController>();
        _startTurnCrtn = StartTurn;
        _turnController.SubscribeToTeamTurnStartEvent(TurnTeamName, _startTurnCrtn);

        _mapController = GameManager.Instance.GetComponent<MapController>();
    }

    protected override IEnumerator StartTurn()
    {
        CurrentMovesCount = _MovesCount;

        yield return new WaitUntil(() => CurrentMovesCount == 0);
    }

    protected override void DoMove()
    {
        foreach (var turnMover in _turnMovers)
        {
            if (turnMover.TryDoMove(_targetMovePosition))
            {
                CurrentMovesCount--;
                InvokeOnMovedEvent();

                TimeBetweenMoves = turnMover.TimeToNextMove;
                _NextMoveTime = Time.time + TimeBetweenMoves;

                break;
            }
        }
    }

    public void TryDoMove(Vector2 inputDirection)
    {
        if (CurrentMovesCount > 0 && Time.time >= _NextMoveTime)
        {
            _targetMovePosition = (Vector2)transform.position + inputDirection;

            DoMove();
        }
    }
    public void TryDoMoveAtCell(Vector2 cellPosition)
    {
        if (CurrentMovesCount > 0 && Time.time >= _NextMoveTime)
        {
            _targetMovePosition = cellPosition;

            DoMove();
        }
    }

    public void SkipTurn()
    {
        CurrentMovesCount = 0;
        InvokeOnMovedEvent();
    }
}