using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProbalityRandom : MonoBehaviour
{
    public static int? RandomRange(float[] probalitys, bool debug = false)
    {
        float totalProbality = 0;
        float randomValue;

        foreach (var item in probalitys)
        {
            totalProbality += item;
        }

        randomValue = Random.Range(0, totalProbality);

        if (debug)
        {
            Debug.Log("Total Probality: " + totalProbality);
            Debug.Log("Random Value: " + randomValue);
        }

        for (int i = 0; i < probalitys.Length; i++)
        {
            if (randomValue <= probalitys[i])
            {
                return i;
            }
            else
            {
                randomValue -= probalitys[i];
            }
        }

        return null;
    }

    public static int? RandomRange(int[] probalitys, bool debug = false)
    {
        int totalProbality = 0;
        int randomValue;

        foreach (var item in probalitys)
        {
            totalProbality += item;
        }

        randomValue = Random.Range(0, totalProbality);

        if (debug)
        {
            Debug.Log("Total Probality: " + totalProbality);
            Debug.Log("Random Value: " + randomValue);
        }

        for (int i = 0; i < probalitys.Length; i++)
        {
            if (randomValue <= probalitys[i])
            {
                return i;
            }
            else
            {
                randomValue -= probalitys[i];
            }
        }

        return null;
    }
}
