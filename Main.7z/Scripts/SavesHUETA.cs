using BayatGames.SaveGameFree;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SavesHUETA : MonoBehaviour
{
    [SerializeField] private string _SaveToDeleteName;

    [ContextMenu("Debug All Saves")]
    public void DebugAllSaves()
    {
        var saves = SaveGame.GetFiles();

        foreach (var save in saves)
        {
            Debug.Log(save.Name);
        }
    }
    [ContextMenu("Delete Save")]
    public void DeleteSave()
    {
        if (SaveGame.Exists(_SaveToDeleteName))
        {
            SaveGame.Delete(_SaveToDeleteName);
            Debug.Log($"Save '{_SaveToDeleteName}' has been deleted.");
        }
        else
        {
            Debug.LogWarning($"Save '{_SaveToDeleteName}' does not exist.");
        }
    }
}
