using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization;

[CreateAssetMenu(fileName = "NewCard", menuName = "Cards/New Card")]
public class CardData : ScriptableObject
{
    public CardRare Rare;
    public LocalizedString CardName;
    public Sprite Icon;
    public LocalizedString CardDescription;
    public float EnergyCost;

    [Space]
    public List<CardEffect> Effects = new List<CardEffect>();

    public bool CanUse()
    {
        if (PlayerManager.Instance.GetComponent<PlayerEnergy>().CheckEnergy(EnergyCost))
        {
            return true;
        }

        return false;
    }
    public void SpendEnergy()
    {
        PlayerManager.Instance.GetComponent<PlayerEnergy>().TrySpendEnergy(EnergyCost);
    }



    public enum CardRare
    {
        Common,
        Unique
    }
}
