using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ApplyDamageToAllEntitiesInZoneCardEffect : CardEffect
{
    public bool DamagePlayer = false;
    public float Damage = 0f;
    public float CellsInTotal = 0f;

    public override void Calling()
    {
        Vector2 center = PlayerManager.Instance.transform.position;
        float cells = CellsInTotal - 0.1f;
        Vector2 halfExtents = new Vector2(cells / 2, cells / 2);

        Collider2D[] colliders = Physics2D.OverlapBoxAll(center, halfExtents * 2, 0f);

        foreach (Collider2D collider in colliders)
        {
            EntityHealth entityHealth = collider.GetComponent<EntityHealth>();
            if (entityHealth != null)
            {
                if (!DamagePlayer && entityHealth is PlayerHealth)
                    continue;

                entityHealth.ApplyDamage(Damage);
            }
        }
    }

}
