using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugCardEffect : CardEffect
{
    public string DebugText;

    public override void Calling()
    {
        Debug.Log(DebugText);
    }
}
