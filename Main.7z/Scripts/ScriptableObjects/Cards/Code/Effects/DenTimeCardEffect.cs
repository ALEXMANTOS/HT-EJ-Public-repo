using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class DenTimeCardEffect : CardEffect
{
    public float Damage;
    public int EnemyTurnsThreshold;

    public override void Calling()
    {
        var enemies = GameManager.Instance.GetComponent<EntitiesSpawnController>().GetEntitiesExcludingTeams("Player","Obstacle","Ally","Boss");
        enemies = enemies.Where(enemy => enemy.GetComponent<MapEntityTurnController>().LivedTurns < EnemyTurnsThreshold).ToList();

        foreach(GameObject enemy in enemies)
        {
            enemy.GetComponent<EntityHealth>().ApplyDamage(Damage);
        }
    }
}
