using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealCardEffect : CardEffect
{
    public int HealValue;

    public override void Calling()
    {
        PlayerManager.Instance.GetComponent<PlayerHealth>().Heal(HealValue);
    }
}
