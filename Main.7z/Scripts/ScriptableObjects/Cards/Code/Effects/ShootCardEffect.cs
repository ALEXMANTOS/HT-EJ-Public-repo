using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ShootCardEffect : CardEffect
{
    public GameObject ProjectilePrefab;

    [Space]
    public float Damage;
    public BulletProperties Properties;

    public override void Calling()
    {
        PlayerControlsUIController.Instance.SetMovementButtonsAction(Shoot);
    }
    private void Shoot(Vector2 direction)
    {
        Vector2 playerPosition = PlayerManager.Instance.transform.position;

        GameObject projectile = LeanPool.Spawn(ProjectilePrefab, playerPosition, Quaternion.identity);

        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        projectile.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));

        Bullet bullet = projectile.GetComponent<Bullet>();
        bullet.InitBullet(Damage, Properties, PlayerManager.Instance.gameObject);

        PlayerControlsUIController.Instance.ResetMovementButtonsAction();
    }
}