using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class SkipTurnCardEffect : CardEffect
{
    public override void Calling()
    {
        PlayerManager.Instance.GetComponent<PlayerTurnController>().SkipTurn();
    }
}