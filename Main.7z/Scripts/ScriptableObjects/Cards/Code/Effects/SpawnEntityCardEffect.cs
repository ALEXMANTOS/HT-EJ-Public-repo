using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class SpawnEntityCardEffect : CardEffect
{
    public GameObject EntityToSpawn;

    public override void Calling()
    {
        var neighboursCells = GameManager.Instance.GetComponent<MapController>().
        GetNeighborCells(GameManager.Instance.GetComponent<MapController>()
        .GetCellAtPosition(PlayerManager.Instance.transform.position));
        neighboursCells = neighboursCells.Where(cell => cell.Occupant == null).ToList();

        if (neighboursCells.Count == 0) return;

        PlayerControlsUIController.Instance.SetMovementButtonsAction(TrySpawn);
    }

    private void TrySpawn(Vector2 direction)
    {
        GameManager gameManager = GameManager.Instance;

        if (gameManager.GetComponent<MapController>().TryToSpawnEntity(EntityToSpawn, PlayerManager.Instance.transform.position + (Vector3)direction, out GameObject spawnedInstance))
        {
            gameManager.GetComponent<EntitiesSpawnController>().AddEntityToSpawned(spawnedInstance.GetComponent<MapEntityTurnController>());
        }

        PlayerControlsUIController.Instance.ResetMovementButtonsAction();
    }
}