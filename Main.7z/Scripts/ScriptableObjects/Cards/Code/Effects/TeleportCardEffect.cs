using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TeleportCardEffect : CardEffect
{
    public override void Calling()
    {
        PlayerControlsUIController.Instance.OpenCellsScreen(Teleport);
    }

    private void Teleport(Cell cell)
    {
        var playerMovement = PlayerManager.Instance.GetComponent<PlayerMovement>();

        playerMovement.TeleportToCell(cell);
    }
}