using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Card Selective Data", menuName = "Selective/New Card Selective Data")]
public class CardSelectiveInfoData : SelectiveInfoData
{
    [Space]
    public CardData CardData;
}