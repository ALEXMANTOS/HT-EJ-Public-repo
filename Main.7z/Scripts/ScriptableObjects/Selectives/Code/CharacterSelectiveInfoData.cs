using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization;

[CreateAssetMenu(fileName = "New Character Selective Data", menuName = "Selective/New Character Selective Data")]
public class CharacterSelectiveInfoData : SelectiveInfoData
{
    [Space]
    public GameObject CharacterPrefab;

    [Space]
    public LocalizedString CharacterName;
    public Sprite Icon;
    public LocalizedString Description;
}
