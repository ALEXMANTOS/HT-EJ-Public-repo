using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(SelectiveInfoData), true)]
public class SelectiveInfoDataEditor : Editor
{
    SerializedProperty initiallyUnlockedProperty;
    SerializedProperty unlockTypeProperty;
    SerializedProperty achievementProperty;
    SerializedProperty diamondCostProperty;
    SerializedProperty rubiesCostProperty;

    private void OnEnable()
    {
        // Get references to the properties
        initiallyUnlockedProperty = serializedObject.FindProperty("InitiallyUnlocked");
        unlockTypeProperty = serializedObject.FindProperty("UnlockType");
        achievementProperty = serializedObject.FindProperty("AchievementToUnlock");
        diamondCostProperty = serializedObject.FindProperty("DiamondsCost");
        rubiesCostProperty = serializedObject.FindProperty("RubiesCost");
    }

    public override void OnInspectorGUI()
    {
        // Update the object before displaying
        serializedObject.Update();

        DrawPropertiesExcluding(serializedObject,"InitiallyUnlocked", "UnlockType", "AchievementToUnlock", "DiamondsCost", "RubiesCost");

        // Display InitiallyUnlocked property
        EditorGUILayout.PropertyField(initiallyUnlockedProperty);

        // Check if InitiallyUnlocked is false before displaying the other properties
        if (!initiallyUnlockedProperty.boolValue)
        {
            // Display UnlockType property
            EditorGUILayout.PropertyField(unlockTypeProperty);

            // Show additional fields based on UnlockType
            SelectiveInfoData.SelectiveUnlockType unlockType = (SelectiveInfoData.SelectiveUnlockType)unlockTypeProperty.enumValueIndex;
            switch (unlockType)
            {
                case SelectiveInfoData.SelectiveUnlockType.Achievement:
                    EditorGUILayout.PropertyField(achievementProperty);
                    break;
                case SelectiveInfoData.SelectiveUnlockType.Diamonds:
                    EditorGUILayout.PropertyField(diamondCostProperty);
                    break;
            }

            // Display RubiesCost property
            EditorGUILayout.PropertyField(rubiesCostProperty);
        }

        // Apply the changes
        serializedObject.ApplyModifiedProperties();
    }
}