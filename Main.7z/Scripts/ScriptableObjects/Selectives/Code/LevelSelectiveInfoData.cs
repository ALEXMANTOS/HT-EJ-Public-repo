using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization;

[CreateAssetMenu(fileName = "New Level Selective Data", menuName = "Selective/New Level Selective Data")]
public class LevelSelectiveInfoData : SelectiveInfoData
{
    [field: Space]
    [field: SerializeField] public string LevelKey { get; private set; }
    [field: SerializeField] public LocalizedString LevelName { get; private set; }
}