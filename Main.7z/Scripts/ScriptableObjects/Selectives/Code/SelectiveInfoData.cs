using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Localization;

public abstract class SelectiveInfoData : ScriptableObject
{
    [Space]
    public bool InitiallyUnlocked;
    public SelectiveUnlockType UnlockType;
    public string AchievementToUnlock;
    public int DiamondsCost;
    public int RubiesCost;

    public enum SelectiveUnlockType
    {
        Achievement,
        Diamonds
    }
}