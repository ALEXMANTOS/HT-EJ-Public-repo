using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetGameobjectsInDontDestroyOnLoad : MonoBehaviour
{
    [SerializeField] private List<GameObject> _gameobjects;

    private void Awake()
    {
        foreach (var go in _gameobjects)
        {
            DontDestroyOnLoad(go);
        }
    }
}
