using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using DG.Tweening;
using UnityEngine.UI;

[RequireComponent(typeof(CardUI))]
public class CardDragAndDropUI : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    [SerializeField] private RectTransform _Holder;
    [SerializeField] private int _ActivateCardDistance = 150;
    [SerializeField] private float _RotationMagnitude = 10f;
    [SerializeField] private float _RotationSmoothDuration = 0.1f;
    [SerializeField] private float _ReturnRotationSpeed = 0.2f;

    private CardUI _cardUI;
    private RectTransform _rectTransform;
    private DeckController _deckController;

    private Vector2 _startDragCardPosition;
    private Vector2 _lastDragPosition;
    private bool _isDragging = false;

    private void Start()
    {
        _cardUI = GetComponent<CardUI>();
        _rectTransform = GetComponent<RectTransform>();
        _deckController = GameManager.Instance.GetComponent<DeckController>();
    }

    private void Update()
    {
        if (_isDragging && _rectTransform.anchoredPosition == _lastDragPosition)
        {
            _rectTransform.DORotate(Vector3.zero, _ReturnRotationSpeed);
        }
        _lastDragPosition = _rectTransform.anchoredPosition;
    }

    private void OnEnable()
    {
        if (_rectTransform == null) return;
        ReturnToDeck();
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        _isDragging = true;

        _startDragCardPosition = _rectTransform.anchoredPosition;
        _lastDragPosition = _startDragCardPosition;

        _deckController.SetHoldingCard(_Holder);
        _rectTransform.DOScale(1.2f, 0.2f); 
    }

    public void OnDrag(PointerEventData eventData)
    {
        if (!_isDragging) return;

        _rectTransform.anchoredPosition += eventData.delta;

        float rotationZ = Mathf.Clamp(-eventData.delta.x * _RotationMagnitude, -_RotationMagnitude, _RotationMagnitude);
        _rectTransform.DORotate(new Vector3(0, 0, rotationZ), _RotationSmoothDuration);

        _lastDragPosition = _rectTransform.anchoredPosition;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        _isDragging = false;
        _rectTransform.DOKill();
        if (_rectTransform.anchoredPosition.y > _startDragCardPosition.y + _ActivateCardDistance && eventData != null)
        {
            OpenCard();
        }
        else
        {
            ReturnToDeck();
        }

        _rectTransform.DORotate(Vector3.zero, _ReturnRotationSpeed);
    }

    public void ReturnToDeck()
    {
        StartCoroutine(ReturnToDeckHandler());
    }

    private IEnumerator ReturnToDeckHandler()
    {
        Vector2 originalPosition = _rectTransform.position;

        RectTransform deck = _deckController.PutCardInDeck(_Holder);
        yield return new WaitForEndOfFrame();

        Vector2 cardPositionInDeck = Vector2.zero;

        _rectTransform.position = originalPosition;

        _rectTransform.rotation = Quaternion.identity;
        _rectTransform.DOAnchorPos(cardPositionInDeck, 0.3f).OnComplete(() =>
        {
            _rectTransform.DOScale(1f, 0.2f);
        });
    }

    private void OpenCard()
    {
        _deckController.OpenCard(_cardUI, _Holder);
    }
}