using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CardUI : MonoBehaviour
{
    [SerializeField] private Sprite _CommonRareSprite;
    [SerializeField] private Sprite _UniqueRareSprite;

    [Space]
    [SerializeField] private Image _CardSpriteRef;
    [SerializeField] private TMP_Text _CardNameRef;
    [SerializeField] private Image _CardIconRef;
    [SerializeField] private TMP_Text _CardCostRef;

    [field:SerializeField] public CardData _CardData {  get; private set; }

    private void Start()
    {
        if (_CardData)
        {
            SetCardData(_CardData);
        }
    }

    public void SetCardData(CardData data)
    {
        _CardData = data;

        _CardNameRef.text = _CardData.CardName.GetLocalizedString();
        _CardIconRef.sprite = _CardData.Icon;
        _CardCostRef.text = _CardData.EnergyCost.ToString();

        if(_CardData.Rare == CardData.CardRare.Common)
        {
            _CardSpriteRef.sprite = _CommonRareSprite;
        }
        else
        {
            _CardSpriteRef.sprite = _UniqueRareSprite;
        }
    }
}