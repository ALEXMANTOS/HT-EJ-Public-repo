using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using TMPro;

[RequireComponent(typeof(CanvasGroup))]
[RequireComponent(typeof(LayoutGroup))]
public class CardsChoice : MonoBehaviour
{
    public static CardsChoice Instance { get; private set; }

    [SerializeField] private GameObject _EnergyCard;

    private CanvasGroup _canvasGroup;
    private List<CardUI> _cardsUI = new List<CardUI>();
    private List<CardUI> _activeCards = new List<CardUI>();

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        _canvasGroup = GetComponent<CanvasGroup>();

        for (int i = 0; i < transform.childCount; i++)
        {
            var cardUI = transform.GetChild(i).GetComponentInChildren<CardUI>();
            if (cardUI != null)
            {
                _cardsUI.Add(cardUI);
                var button = cardUI.GetComponent<Button>();
                if (button != null)
                {
                    button.onClick.AddListener(() => ChooseCard(cardUI));
                }
            }
        }
        _canvasGroup.alpha = 0;
        _canvasGroup.blocksRaycasts = false;
        _EnergyCard.SetActive(false);
        gameObject.SetActive(false);
    }

    public void OpenChoice(List<CardData> cardsToShow,float energyCountIfDeckIsFull)
    {
        gameObject.SetActive(true);
        _canvasGroup.blocksRaycasts = true;
        _canvasGroup.DOFade(1f, 0.15f);

        _activeCards.Clear();

        GameManager.Instance.GetComponent<TurnController>().StopTurnsCycle();

        if (GameManager.Instance.GetComponent<DeckController>().DeckIsFull())
        {
            _EnergyCard.SetActive(true);

            Button cardButton = _EnergyCard.transform.GetChild(0).GetComponent<Button>();
            cardButton.onClick.RemoveAllListeners();
            cardButton.onClick.AddListener(() => AddEnergy(energyCountIfDeckIsFull));

            cardButton.transform.Find("Count").GetComponent<TMP_Text>().text = energyCountIfDeckIsFull.ToString();

            RectTransform cardRectTransform = _EnergyCard.transform.GetChild(0).GetComponent<RectTransform>();
            Vector3 startPosition = new Vector3(cardRectTransform.localPosition.x, -Screen.height, cardRectTransform.localPosition.z);
            cardRectTransform.localPosition = startPosition;
            cardRectTransform.DOLocalMoveY(0, 0.3f)
                .SetEase(Ease.OutBack)
                .SetDelay(0.15f);
        }
        else
        {
            for (int i = 0; i < _cardsUI.Count; i++)
            {
                if (i < cardsToShow.Count)
                {
                    var card = _cardsUI[i];
                    card.transform.parent.gameObject.SetActive(true);
                    card.SetCardData(cardsToShow[i]);
                    _activeCards.Add(card);

                    RectTransform cardRectTransform = card.GetComponent<RectTransform>();
                    Vector3 startPosition = new Vector3(cardRectTransform.localPosition.x, -Screen.height - 200f, cardRectTransform.localPosition.z);
                    cardRectTransform.localPosition = startPosition;
                    cardRectTransform.DOLocalMoveY(0, 0.3f)
                        .SetEase(Ease.OutBack)
                        .SetDelay(i * 0.1f);
                }
                else
                {
                    _cardsUI[i].transform.parent.gameObject.SetActive(false);
                }
            }
        }
    }

    private void HideChoice()
    {
        _canvasGroup.blocksRaycasts = false;
        _canvasGroup.DOFade(0f, 0.15f).OnComplete(() =>
        {
            _EnergyCard.SetActive(false);
            for (int i = 0; i < _cardsUI.Count; i++)
            {
                _cardsUI[i].transform.parent.gameObject.SetActive(false);
            }

            gameObject.SetActive(false);
        });
    }

    private void ChooseCard(CardUI chosenCard)
    {
        GameManager.Instance.GetComponent<DeckController>().TryAddCardToDeck(chosenCard._CardData);
        GameManager.Instance.GetComponent<TurnController>().ResumeTurnsCycle();

        HideChoice();
    }

    private void AddEnergy(float energy)
    {
        PlayerManager.Instance.GetComponent<PlayerEnergy>().AddEnergy(energy);
        GameManager.Instance.GetComponent<TurnController>().ResumeTurnsCycle();

        HideChoice();
    }
}