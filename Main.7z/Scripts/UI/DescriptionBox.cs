using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DescriptionBox : MonoBehaviour
{
    [SerializeField] private ScrollRect _Scroll;

    private void OnEnable()
    {
        DOVirtual.DelayedCall(0.1f,() => _Scroll.verticalNormalizedPosition = 1f);
    }
}