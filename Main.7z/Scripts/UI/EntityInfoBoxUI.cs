using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class EntityInfoBoxUI : MonoBehaviour
{
    public static EntityInfoBoxUI Instance {  get; private set; }

    [SerializeField] private GameObject _InfoPanel;
    [SerializeField] private TMP_Text _NameText;
    [SerializeField] private Image _Icon;
    [SerializeField] private TMP_Text _DescriptionText;
    [SerializeField] private TMP_Text _HealthText;
    [SerializeField] private TMP_Text _MovesCountText;

    [Space]
    [SerializeField] private TMP_Text _MeleeDamageText;
    [SerializeField] private TMP_Text _ShootDamageText;
    [SerializeField] private TMP_Text _LaunchDamageText;
    [SerializeField] private TMP_Text _RayDamageText;

    [Header("Enable/Disable Settings")]
    [SerializeField] private RectTransform _InformationBox;
    [SerializeField] private CanvasGroup _CloseButtonsCGnRef;

    [Space]
    [SerializeField] private float _EnableTime;
    [SerializeField] private float _DisableTime;

    private void Awake()
    {
        Instance = this;
        _InfoPanel.SetActive(false);
    }

    public void ShowInfo(MapEntityInfoOnClickBase info)
    {
        _NameText.text = info.EntityName;
        _DescriptionText.text = info.EntityDescription;
        _Icon.sprite = info.EntityIcon;

        _HealthText.gameObject.SetActive(false);
        if(info.TryGetComponent(out EntityHealth hp))
        {
            _HealthText.gameObject.SetActive(true);
            _HealthText.text = hp._CurrentHealth % 1 == 0
            ? $"{(int)hp._CurrentHealth}\n{(int)hp._MaxHealth}" : $"{hp._CurrentHealth:F1}\n{hp._MaxHealth:F1}";
        }
        _MovesCountText.gameObject.SetActive(false);
        if (info.TryGetComponent(out MapEntityTurnController MEturnController) && MEturnController._MovesCount != 0)
        {
            _MovesCountText.gameObject.SetActive(true);
            _MovesCountText.text = MEturnController._MovesCount.ToString();
        }

        UpdateDamageTexts(info);

        OpenInfoBox();
    }
    private void UpdateDamageTexts(MapEntityInfoOnClickBase info)
    {
        _MeleeDamageText.gameObject.SetActive(false);
        _ShootDamageText.gameObject.SetActive(false);
        _LaunchDamageText.gameObject.SetActive(false);
        _RayDamageText.gameObject.SetActive(false);

        var attacks = info.GetComponents<IMapEntityAttack>();

        if(attacks != null && attacks.Length > 0)
        {
            foreach(var attack in attacks)
            {
                switch (attack.AttackType)
                {
                    case AttackType.Melee:
                    {
                            _MeleeDamageText.gameObject.SetActive(true);
                            _MeleeDamageText.text = attack.Damage.ToString();
                            break;
                    }
                    case AttackType.Shoot:
                    {
                            _ShootDamageText.gameObject.SetActive(true);
                            _ShootDamageText.text = attack.Damage.ToString();
                            break;
                        }
                    case AttackType.Launch:
                    {
                            _LaunchDamageText.gameObject.SetActive(true);
                            _LaunchDamageText.text = attack.Damage.ToString();
                            break;
                        }
                    case AttackType.Ray:
                    {
                            _RayDamageText.gameObject.SetActive(true);
                            _RayDamageText.text = attack.Damage.ToString();
                            break;
                        }
                }
            }
        }
    }

    private void OpenInfoBox()
    {
        _InformationBox.localScale = Vector3.zero;
        _CloseButtonsCGnRef.alpha = 0;

        _InfoPanel.gameObject.SetActive(true);

        _CloseButtonsCGnRef.DOFade(1f, _EnableTime).SetEase(Ease.InOutQuad);
        _InformationBox.DOScale(Vector3.one, _EnableTime).SetEase(Ease.OutBack);
    }
    public void HideInfo()
    {
        _InformationBox.DOScale(Vector3.zero, _DisableTime).SetEase(Ease.InBack);

        _CloseButtonsCGnRef.DOFade(0f, _DisableTime).SetEase(Ease.InOutQuad).OnComplete(() =>
        {
            _InfoPanel.gameObject.SetActive(false);
        });
    }
}