using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.SceneManagement;

public class GameOverScreen : MonoBehaviour
{
    [SerializeField] private LocalizeStringEvent _BestScoreText;
    [SerializeField] private LocalizeStringEvent _CurrentScoreText;


    private void OnEnable()
    {
        _BestScoreText.StringReference.Arguments = new object[] { LevelsManager.Instance.GetBestScore(SceneManager.GetActiveScene().name) };
        _BestScoreText.RefreshString();

        _CurrentScoreText.StringReference.Arguments = new object[] { GameManager.Instance.GetComponent<TurnController>().CurrentTurn };
        _CurrentScoreText.RefreshString();
    }
}
