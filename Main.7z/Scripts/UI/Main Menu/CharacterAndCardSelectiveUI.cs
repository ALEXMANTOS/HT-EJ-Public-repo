using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

[RequireComponent(typeof(Button))]
public class CharacterAndCardSelectiveUI : MonoBehaviour
{
    [SerializeField] private LocalizeStringEvent _NameText;
    [SerializeField] private Image _Icon;
    [SerializeField] private Image _LockBG;

    [Space]
    [SerializeField] private TMP_Text _CardCostRef;

    [field: Space]
    [field: SerializeField] public SelectiveInfoData Data {  get; private set; }

    private void Start()
    {
        if(Data is CharacterSelectiveInfoData)
        {
            CharacterSelectiveInfoData data = (CharacterSelectiveInfoData)Data;

            _NameText.StringReference = data.CharacterName;
            _Icon.sprite = data.Icon;

            GetComponent<Button>().onClick.AddListener(() => CharactersAndCardsInfoBoxUI.Instance.OpenCharacterInfoBox(this));

            if (!CharactersAndCardsUnlockController.Instance.IsCharacterUnlocked(data.CharacterName.TableEntryReference.KeyId.ToString()) && Data.UnlockType == SelectiveInfoData.SelectiveUnlockType.Achievement)
            {
                if (AchievementsController.Instance.IsAchievementUnlocked(Data.AchievementToUnlock))
                {
                    CharactersAndCardsUnlockController.Instance.UnlockCharacter(data.CharacterName.TableEntryReference.KeyId.ToString());
                }
            }

            if (CharactersAndCardsUnlockController.Instance.IsCharacterUnlocked(data.CharacterName.TableEntryReference.KeyId.ToString()))
            {
                UnlockSelectiveUI();
            }
        }
        else
        {
            CardSelectiveInfoData data = (CardSelectiveInfoData)Data;

            _CardCostRef.text = data.CardData.EnergyCost.ToString();
            _NameText.StringReference = data.CardData.CardName;
            _Icon.sprite = data.CardData.Icon;

            GetComponent<Button>().onClick.AddListener(() => CharactersAndCardsInfoBoxUI.Instance.OpenCardInfoBox(this,GetComponent<Image>().sprite));

            if (!CharactersAndCardsUnlockController.Instance.IsCardUnlocked(data.CardData.CardName.TableEntryReference.KeyId.ToString()) && Data.UnlockType == SelectiveInfoData.SelectiveUnlockType.Achievement)
            {
                if (AchievementsController.Instance.IsAchievementUnlocked(Data.AchievementToUnlock))
                {
                    CharactersAndCardsUnlockController.Instance.UnlockCard(data.CardData.CardName.TableEntryReference.KeyId.ToString());
                }
            }

            if (CharactersAndCardsUnlockController.Instance.IsCardUnlocked(data.CardData.CardName.TableEntryReference.KeyId.ToString()))
            {
                UnlockSelectiveUI();
            }
        }
    }

    public void UnlockSelectiveUI()
    {
        _LockBG.gameObject.SetActive(false);
    }
}