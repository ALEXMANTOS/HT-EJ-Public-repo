using BayatGames.SaveGameFree;
using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CharactersAndCardsInfoBoxUI : MonoBehaviour
{
    public static CharactersAndCardsInfoBoxUI Instance {  get; private set; }

    [Header("Info Box")]
    [SerializeField] private GameObject _InfoBoxPanel;
    [SerializeField] private RectTransform _InfoCard;
    [SerializeField] private TMP_Text _NameRef;
    [SerializeField] private Image _IconRef;
    [SerializeField] private TMP_Text _DescriptionRef;
    [SerializeField] private CanvasGroup _CloseInfoBoxBtnCG;

    [Space]
    [SerializeField] private CanvasGroup _AchievementInfoBoxCG;
    [SerializeField] private Slider _AchievementProgressSlider;
    [SerializeField] private TMP_Text _AchievementNameRef;
    [SerializeField] private TMP_Text _AchievementProgressRef;

    [Space]
    [SerializeField] private CanvasGroup _DBuySelectiveCG;
    [SerializeField] private TMP_Text _DBuyDiaomndsCountRef;

    [Space]
    [SerializeField] private CanvasGroup _RBuySelectiveBtnCG;
    [SerializeField] private TMP_Text _RBuyRubiesCountRef;

    [Header("Characters Info")]
    [SerializeField] private CanvasGroup _ActivateCharacterBtnCG;

    [Space]
    [SerializeField] private TMP_Text _HealthText;
    [SerializeField] private TMP_Text _MovesCountText;

    [Space]
    [SerializeField] private TMP_Text _MeleeDamageText;
    [SerializeField] private TMP_Text _ShootDamageText;
    [SerializeField] private TMP_Text _LaunchDamageText;
    [SerializeField] private TMP_Text _RayDamageText;


    [Header("Card Info")]
    [SerializeField] private CanvasGroup _CloseInfoBoxBtnCG2;
    [SerializeField] private TMP_Text _CardCostRef;

    private Sprite _defaultCardSprite;

    private CharacterAndCardSelectiveUI _currentSelectiveUI;


    private void Awake()
    {
        Instance = this;

        _defaultCardSprite = _InfoCard.GetComponent<Image>().sprite;
    }

    private void Start()
    {
        _HealthText.gameObject.SetActive(false);
        _MovesCountText.gameObject.SetActive(false);

        _MeleeDamageText.gameObject.SetActive(false);
        _ShootDamageText.gameObject.SetActive(false);
        _LaunchDamageText.gameObject.SetActive(false);
        _RayDamageText.gameObject.SetActive(false);
    }


    public void OpenCharacterInfoBox(CharacterAndCardSelectiveUI selectiveUI)
    {
        _currentSelectiveUI = selectiveUI;

        _InfoCard.GetComponent<Image>().sprite = _defaultCardSprite;

        CharacterSelectiveInfoData data = (CharacterSelectiveInfoData)selectiveUI.Data;

        _NameRef.text = data.CharacterName.GetLocalizedString();
        _IconRef.sprite = data.Icon;
        _DescriptionRef.text = data.Description.GetLocalizedString();

        OpenInfoBox(data);
    }
    public void OpenCardInfoBox(CharacterAndCardSelectiveUI selectiveUI,Sprite cardSprite = null)
    {
        _currentSelectiveUI = selectiveUI;

        _InfoCard.GetComponent<Image>().sprite = cardSprite != null ? cardSprite : _defaultCardSprite;

        CardSelectiveInfoData data = (CardSelectiveInfoData)selectiveUI.Data;

        _NameRef.text = data.CardData.CardName.GetLocalizedString();
        _IconRef.sprite = data.CardData.Icon;
        _DescriptionRef.text = data.CardData.CardDescription.GetLocalizedString();
        _CardCostRef.text = data.CardData.EnergyCost.ToString();

        OpenInfoBox(data);
    }

    private void OpenInfoBox(CharacterSelectiveInfoData data)
    {
        _InfoCard.localScale = Vector3.zero;

        _CloseInfoBoxBtnCG.alpha = 0;
        _ActivateCharacterBtnCG.gameObject.SetActive(false);
        _AchievementInfoBoxCG.gameObject.SetActive(false);
        _DBuySelectiveCG.gameObject.SetActive(false);
        _RBuySelectiveBtnCG.gameObject.SetActive(false);

        if (data.CharacterPrefab.TryGetComponent(out EntityHealth hp))
        {
            _HealthText.gameObject.SetActive(true);
            _HealthText.text = hp._CurrentHealth % 1 == 0
            ? $"{(int)hp._CurrentHealth}\n{(int)hp._MaxHealth}" : $"{hp._CurrentHealth:F1}\n{hp._MaxHealth:F1}";
        }
        if (data.CharacterPrefab.TryGetComponent(out MapEntityTurnController MEturnController) && MEturnController._MovesCount != 0)
        {
            _MovesCountText.gameObject.SetActive(true);
            _MovesCountText.text = MEturnController._MovesCount.ToString();
        }

        UpdateDamageTexts(data.CharacterPrefab);

        _InfoBoxPanel.SetActive(true);

        _CloseInfoBoxBtnCG.DOFade(1f, 0.3f).SetEase(Ease.InOutQuad);
        if (CharactersAndCardsUnlockController.Instance.IsCharacterUnlocked(data.CharacterName.TableEntryReference.KeyId.ToString()))
        {
            _ActivateCharacterBtnCG.alpha = 0;
            _ActivateCharacterBtnCG.gameObject.SetActive(true);
            _ActivateCharacterBtnCG.DOFade(1f, 0.3f).SetEase(Ease.InOutQuad);
        }
        else
        {
            if(data.UnlockType == SelectiveInfoData.SelectiveUnlockType.Achievement)
            {
                _AchievementInfoBoxCG.alpha = 0;

                var achievementData = AchievementsController.Instance.GetAchievementSaveData(data.AchievementToUnlock);

                _AchievementProgressSlider.maxValue = achievementData.RequiredProgress;
                _AchievementProgressSlider.value = achievementData.CurrentProgress;

                _AchievementNameRef.text = achievementData.AchievementName.GetLocalizedString();
                _AchievementProgressRef.text = $"{achievementData.CurrentProgress}/{achievementData.RequiredProgress}";

                _AchievementInfoBoxCG.gameObject.SetActive(true);
                _AchievementInfoBoxCG.DOFade(1f, 0.3f).SetEase(Ease.InOutQuad);
            }
            else
            {
                _DBuySelectiveCG.alpha = 0;
                _DBuySelectiveCG.gameObject.SetActive(true);

                _DBuyDiaomndsCountRef.text = data.DiamondsCost.ToString();

                _DBuySelectiveCG.DOFade(1f, 0.3f).SetEase(Ease.InOutQuad);
            }

            _RBuySelectiveBtnCG.alpha = 0;
            _RBuySelectiveBtnCG.gameObject.SetActive(true);
            _RBuyRubiesCountRef.text = data.RubiesCost.ToString();
            _RBuySelectiveBtnCG.DOFade(1f, 0.3f).SetEase(Ease.InOutQuad);
        }

        _InfoCard.DOScale(Vector3.one, 0.3f).SetEase(Ease.OutBack);
    }
    private void OpenInfoBox(CardSelectiveInfoData data)
    {
        _InfoCard.localScale = Vector3.zero;

        _CloseInfoBoxBtnCG.alpha = 0;
        _CloseInfoBoxBtnCG2.gameObject.SetActive(false);
        _AchievementInfoBoxCG.gameObject.SetActive(false);
        _DBuySelectiveCG.gameObject.SetActive(false);
        _RBuySelectiveBtnCG.gameObject.SetActive(false);
        _CardCostRef.gameObject.SetActive(true);

        _InfoBoxPanel.SetActive(true);

        _CloseInfoBoxBtnCG.DOFade(1f, 0.3f).SetEase(Ease.InOutQuad);
        if (CharactersAndCardsUnlockController.Instance.IsCardUnlocked(data.CardData.CardName.TableEntryReference.KeyId.ToString()))
        {
            _CloseInfoBoxBtnCG2.alpha = 0;
            _CloseInfoBoxBtnCG2.gameObject.SetActive(true);
            _CloseInfoBoxBtnCG2.DOFade(1f, 0.3f).SetEase(Ease.InOutQuad);
        }
        else
        {
            if (data.UnlockType == SelectiveInfoData.SelectiveUnlockType.Achievement)
            {
                _AchievementInfoBoxCG.alpha = 0;

                var achievement = AchievementsController.Instance.GetAchievementSaveData(data.AchievementToUnlock);

                _AchievementProgressSlider.maxValue = achievement.RequiredProgress;
                _AchievementProgressSlider.value = achievement.CurrentProgress;

                _AchievementNameRef.text = achievement.AchievementName.GetLocalizedString();
                _AchievementProgressRef.text = $"{achievement.CurrentProgress}/{achievement.RequiredProgress}";

                _AchievementInfoBoxCG.gameObject.SetActive(true);
                _AchievementInfoBoxCG.DOFade(1f, 0.3f).SetEase(Ease.InOutQuad);
            }
            else
            {
                _DBuySelectiveCG.alpha = 0;
                _DBuySelectiveCG.gameObject.SetActive(true);

                _DBuyDiaomndsCountRef.text = data.DiamondsCost.ToString();

                _DBuySelectiveCG.DOFade(1f, 0.3f).SetEase(Ease.InOutQuad);
            }

            _RBuySelectiveBtnCG.alpha = 0;
            _RBuySelectiveBtnCG.gameObject.SetActive(true);
            _RBuyRubiesCountRef.text = data.RubiesCost.ToString();
            _RBuySelectiveBtnCG.DOFade(1f, 0.3f).SetEase(Ease.InOutQuad);
        }

        _InfoCard.DOScale(Vector3.one, 0.3f).SetEase(Ease.OutBack);
    }
    public void HideInfo()
    {
        _InfoCard.DOScale(Vector3.zero, 0.3f).SetEase(Ease.InBack);

        _ActivateCharacterBtnCG.DOFade(0, 0.3f).SetEase(Ease.InOutQuad);
        _AchievementInfoBoxCG.DOFade(0, 0.3f).SetEase(Ease.InOutQuad);
        _DBuySelectiveCG.DOFade(0, 0.3f).SetEase(Ease.InOutQuad);
        _RBuySelectiveBtnCG.DOFade(0, 0.3f).SetEase(Ease.InOutQuad);
        _CloseInfoBoxBtnCG2.DOFade(0, 0.3f).SetEase(Ease.InOutQuad);
        _CloseInfoBoxBtnCG.DOFade(0f, 0.3f).SetEase(Ease.InOutQuad).OnComplete(() =>
        {
            _InfoBoxPanel.SetActive(false);

            _ActivateCharacterBtnCG.gameObject.SetActive(false);
            _CloseInfoBoxBtnCG2.gameObject.SetActive(false);
            _CardCostRef.gameObject.SetActive(false);

            _HealthText.gameObject.SetActive(false);
            _MovesCountText.gameObject.SetActive(false);

            _MeleeDamageText.gameObject.SetActive(false);
            _ShootDamageText.gameObject.SetActive(false);
            _LaunchDamageText.gameObject.SetActive(false);
            _RayDamageText.gameObject.SetActive(false);
        });
    }

    private void UpdateDamageTexts(GameObject characterPrefab)
    {
        _MeleeDamageText.gameObject.SetActive(false);
        _ShootDamageText.gameObject.SetActive(false);
        _LaunchDamageText.gameObject.SetActive(false);
        _RayDamageText.gameObject.SetActive(false);

        var attacks = characterPrefab.GetComponents<IMapEntityAttack>();

        if (attacks != null && attacks.Length > 0)
        {
            foreach (var attack in attacks)
            {
                switch (attack.AttackType)
                {
                    case AttackType.Melee:
                        {
                            _MeleeDamageText.gameObject.SetActive(true);
                            _MeleeDamageText.text = attack.Damage.ToString();
                            break;
                        }
                    case AttackType.Shoot:
                        {
                            _ShootDamageText.gameObject.SetActive(true);
                            _ShootDamageText.text = attack.Damage.ToString();
                            break;
                        }
                    case AttackType.Launch:
                        {
                            _LaunchDamageText.gameObject.SetActive(true);
                            _LaunchDamageText.text = attack.Damage.ToString();
                            break;
                        }
                    case AttackType.Ray:
                        {
                            _RayDamageText.gameObject.SetActive(true);
                            _RayDamageText.text = attack.Damage.ToString();
                            break;
                        }
                }
            }
        }
    }

    public void ActivateCharacter()
    {
        var data = (CharacterSelectiveInfoData)_currentSelectiveUI.Data;

        MainMenuController.Instance.SelectCharacter(data.CharacterName.TableEntryReference.KeyId.ToString());

        HideInfo();
    }

    public void TryToBuySelectiveByDiamonds()
    {
        if (CurrencyController.Instance.TrySpendDiamonds(_currentSelectiveUI.Data.DiamondsCost))
        {
            BuySelective();
        }
        else
        {
            _DBuySelectiveCG.interactable = false;
            _DBuySelectiveCG.GetComponent<RectTransform>().DOShakeAnchorPos(0.3f, 20, 50, 360).OnComplete(() => _DBuySelectiveCG.interactable = true);
        }
    }
    public void TryToBuySelectiveByRubies()
    {
        if (CurrencyController.Instance.TrySpendRubies(_currentSelectiveUI.Data.RubiesCost))
        {
            BuySelective();
        }
        else
        {
            _RBuySelectiveBtnCG.interactable = false;
            _RBuySelectiveBtnCG.GetComponent<RectTransform>().DOShakeAnchorPos(0.3f, 20, 50, 360).OnComplete(() => _RBuySelectiveBtnCG.interactable = true);
        }
    }
    private void BuySelective()
    {
        _currentSelectiveUI.UnlockSelectiveUI();
        _DBuySelectiveCG.gameObject.SetActive(false);
        _RBuySelectiveBtnCG.gameObject.SetActive(false);
        _AchievementInfoBoxCG.gameObject.SetActive(false);

        if (_currentSelectiveUI.Data is CharacterSelectiveInfoData)
        {
            var data = (CharacterSelectiveInfoData)_currentSelectiveUI.Data;

            CharactersAndCardsUnlockController.Instance.UnlockCharacter(data.CharacterName.TableEntryReference.KeyId.ToString());

            _ActivateCharacterBtnCG.gameObject.SetActive(true);
            _ActivateCharacterBtnCG.alpha = 1;

            _ActivateCharacterBtnCG.GetComponent<RectTransform>().DOScale(0,0);
            _ActivateCharacterBtnCG.GetComponent<RectTransform>().DOScale(1, 0.5f).SetEase(Ease.OutBack);
        }
        else
        {
            var data = (CardSelectiveInfoData)_currentSelectiveUI.Data;

            CharactersAndCardsUnlockController.Instance.UnlockCard(data.CardData.CardName.TableEntryReference.KeyId.ToString());

            _CloseInfoBoxBtnCG2.gameObject.SetActive(true);
            _CloseInfoBoxBtnCG2.alpha = 1;

            _CloseInfoBoxBtnCG2.GetComponent<RectTransform>().DOScale(0,0);
            _CloseInfoBoxBtnCG2.GetComponent<RectTransform>().DOScale(1, 0.5f).SetEase(Ease.OutBack);
        }
    }
}