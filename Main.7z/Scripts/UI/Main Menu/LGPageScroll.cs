using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(LayoutGroup))]
public class LGPageScroll : MonoBehaviour
{
    public event Action OnPageChanged;

    [SerializeField] private int _ItemsPerPage = 10;

    [Space]
    [SerializeField] private Button _NextPageButton;
    [SerializeField] private Button _PreviousPageButton;

    public int TotalPages { get; private set; }
    public int CurrentPage { get; private set; } = 0;
    public int TotalItems { get; private set; }

    private LayoutGroup _layoutGroup;

    private void Awake()
    {
        _layoutGroup = GetComponent<LayoutGroup>();
        TotalItems = _layoutGroup.transform.childCount;
        TotalPages = Mathf.CeilToInt((float)TotalItems / _ItemsPerPage);

        UpdatePage();
        _NextPageButton.onClick.AddListener(NextPage);
        _PreviousPageButton.onClick.AddListener(PreviousPage);
        UpdateButtons();
    }

    private void UpdatePage()
    {
        int startItem = CurrentPage * _ItemsPerPage;
        int endItem = Mathf.Min((CurrentPage + 1) * _ItemsPerPage, TotalItems);
        for (int i = 0; i < TotalItems; i++)
        {
            _layoutGroup.transform.GetChild(i).gameObject.SetActive(i >= startItem && i < endItem);
        }
    }

    private void NextPage()
    {
        if (CurrentPage < TotalPages - 1)
        {
            CurrentPage++;
            UpdatePage();
            UpdateButtons();
            OnPageChanged?.Invoke();
        }
    }

    private void PreviousPage()
    {
        if (CurrentPage > 0)
        {
            CurrentPage--;
            UpdatePage();
            UpdateButtons();
            OnPageChanged?.Invoke();
        }
    }

    private void UpdateButtons()
    {
        _PreviousPageButton.interactable = CurrentPage > 0;
        _NextPageButton.interactable = CurrentPage < TotalPages - 1;
    }
}