using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(LGPageScroll))]
public class LGPageScrollAdvancedUI : MonoBehaviour
{
    [SerializeField] private HorizontalLayoutGroup _PageNumberLayoutGroup;
    [SerializeField] private GameObject _PageNumberPrefab;
    [SerializeField] private Color _CurrentPageColor = Color.white;
    [SerializeField] private Color _DefaultPageColor = Color.yellow;

    private LGPageScroll _lgPageScroll;
    private List<TMP_Text> _pageNumberTexts = new List<TMP_Text>();

    private void Awake()
    {
        _lgPageScroll = GetComponent<LGPageScroll>();
    }

    private void Start()
    {
        GeneratePageNumbers();
        UpdatePageDisplay();
        _lgPageScroll.OnPageChanged += UpdatePageDisplay;
    }

    private void GeneratePageNumbers()
    {
        foreach (Transform child in _PageNumberLayoutGroup.transform)
        {
            Destroy(child.gameObject);
        }

        _pageNumberTexts.Clear();
        for (int i = 0; i < _lgPageScroll.TotalPages; i++)
        {
            GameObject pageNumberObj = Instantiate(_PageNumberPrefab, _PageNumberLayoutGroup.transform);
            TMP_Text pageNumberText = pageNumberObj.GetComponent<TMP_Text>();
            pageNumberText.text = (i + 1).ToString();
            _pageNumberTexts.Add(pageNumberText);
        }
    }

    private void UpdatePageDisplay()
    {
        int currentPage = _lgPageScroll.CurrentPage;

        for (int i = 0; i < _pageNumberTexts.Count; i++)
        {
            _pageNumberTexts[i].color = i == currentPage ? _CurrentPageColor : _DefaultPageColor;
        }
    }

    private void OnDestroy()
    {
        _lgPageScroll.OnPageChanged -= UpdatePageDisplay;
    }
}
