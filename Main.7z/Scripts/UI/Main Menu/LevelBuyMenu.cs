using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Localization;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

[RequireComponent(typeof(CanvasGroup))]
public class LevelBuyMenu : MonoBehaviour
{
    [Space]
    [SerializeField] private Transform _BuyBox;
    [SerializeField] private LocalizeStringEvent _LevelDescRef;

    [Space]
    [SerializeField] private GameObject _AchievementBox;
    [SerializeField] private LocalizeStringEvent _AchievementDescriptionRef;
    [SerializeField] private Slider _AchievementProgressRef;
    [SerializeField] private TMP_Text _AchievementProgressTextRef;

    [Space]
    [SerializeField] private GameObject _DiamondsBuyButton;
    [SerializeField] private TMP_Text _DiamondsCostRef;
    [SerializeField] private TMP_Text _RubiesCostRef;

    private CanvasGroup _canvasGroup;

    private LevelSelectButton _levelBtn;

    private void Awake()
    {
        _canvasGroup = GetComponent<CanvasGroup>();
    }

    public void OpenMenu(LevelSelectButton levelBtn)
    {
        _levelBtn = levelBtn;

        gameObject.SetActive(true);

        _LevelDescRef.StringReference.Arguments = new object[] { _levelBtn.LevelSelectiveData.LevelName.GetLocalizedString() };
        _LevelDescRef.RefreshString();

        _AchievementBox.SetActive(false);
        _DiamondsBuyButton.SetActive(false);

        if(_levelBtn.LevelSelectiveData.UnlockType == SelectiveInfoData.SelectiveUnlockType.Achievement)
        {
            _AchievementBox.SetActive(true);

            var achievementData = AchievementsController.Instance.GetAchievementSaveData(_levelBtn.LevelSelectiveData.AchievementToUnlock);

            _AchievementDescriptionRef.StringReference = achievementData.AchievementName;
            _AchievementProgressRef.maxValue = achievementData.RequiredProgress;
            _AchievementProgressRef.value = achievementData.CurrentProgress;
            _AchievementProgressTextRef.text = $"{achievementData.CurrentProgress}/{achievementData.RequiredProgress}";
        }
        else
        {
            _DiamondsBuyButton.SetActive(true);

            _DiamondsCostRef.text = _levelBtn.LevelSelectiveData.DiamondsCost.ToString();
        }

        _RubiesCostRef.text = _levelBtn.LevelSelectiveData.RubiesCost.ToString();

        _BuyBox.localScale = Vector3.zero;
        _canvasGroup.alpha = 0;

        _canvasGroup.DOFade(1f, 0.3f).SetEase(Ease.InOutQuad);
        _BuyBox.DOScale(Vector3.one, 0.3f).SetEase(Ease.OutBack);
    }
    public void CloseMenu()
    {
        _canvasGroup.DOFade(0f, 0.3f).SetEase(Ease.InOutQuad);
        _BuyBox.DOScale(Vector3.zero, 0.3f).SetEase(Ease.InBack).OnComplete(() => gameObject.SetActive(false));
    }

    public void TryToBuyByDiamonds()
    {
        if (CurrencyController.Instance.TrySpendDiamonds(_levelBtn.LevelSelectiveData.DiamondsCost))
        {
            LevelsManager.Instance.UnlockLevel(_levelBtn.LevelSelectiveData.LevelKey);
            _levelBtn.UnlockButton();
            CloseMenu();
        }
    }
    public void TryToBuyByRubies()
    {
        if (CurrencyController.Instance.TrySpendRubies(_levelBtn.LevelSelectiveData.RubiesCost))
        {
            LevelsManager.Instance.UnlockLevel(_levelBtn.LevelSelectiveData.LevelKey);
            _levelBtn.UnlockButton();
            CloseMenu();
        }
    }
}