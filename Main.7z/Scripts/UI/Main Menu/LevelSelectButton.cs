using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using TMPro;
using UnityEngine.Localization;
using UnityEngine.Localization.Components;

[RequireComponent(typeof(Button))]
public class LevelSelectButton : MonoBehaviour
{
    [field: SerializeField] public LevelSelectiveInfoData LevelSelectiveData { get; private set; }

    [Space]
    [SerializeField] private LocalizeStringEvent _LevelNameRef;
    [SerializeField] private LocalizeStringEvent _BestScoreRef;
    [SerializeField] private Image _LockImageRef;
    [SerializeField] private TMP_Text _DiamondsCostRef;
    [SerializeField] private TMP_Text _RubiesCostRef;

    [Space]
    [SerializeField] private LevelBuyMenu _LevelBuyMenu;

    private LevelsManager _LevelsManager;

    private Button _button;

    private void Awake()
    {
        _button = GetComponent<Button>();
    }

    private void Start()
    {
        _LevelsManager = LevelsManager.Instance;

        _LevelNameRef.StringReference = LevelSelectiveData.LevelName;

        if (_LevelsManager.IsLevelUnlocked(LevelSelectiveData.LevelKey))
        {
            UnlockButton();
            CheckBestScore();
        }
        else if (LevelSelectiveData.UnlockType == SelectiveInfoData.SelectiveUnlockType.Achievement &&
            AchievementsController.Instance.IsAchievementUnlocked(LevelSelectiveData.AchievementToUnlock))
        {
            LevelsManager.Instance.UnlockLevel(LevelSelectiveData.LevelKey);
            UnlockButton();
            CheckBestScore();
        }
        else
        {
            LockButton();
        }
    }

    private void OpenBuyMenu()
    {
        _LevelBuyMenu.OpenMenu(this);
    }

    private void LockButton()
    {
        _button.onClick.AddListener(OpenBuyMenu);

        if(LevelSelectiveData.UnlockType == SelectiveInfoData.SelectiveUnlockType.Diamonds)
        {
            _DiamondsCostRef.text = LevelSelectiveData.DiamondsCost.ToString();
        }
        else
        {
            _DiamondsCostRef.gameObject.SetActive(false);
        }
        _RubiesCostRef.text = LevelSelectiveData.RubiesCost.ToString();

        _BestScoreRef.gameObject.SetActive(false);
        _LockImageRef.gameObject.SetActive(true);
    }
    public void UnlockButton()
    {
        if (_button == null) return;

        _button.onClick.RemoveAllListeners();
        _button.onClick.AddListener(() => MainMenuController.Instance.LoadScene(LevelSelectiveData.LevelKey));
        _button.interactable = true;

        _DiamondsCostRef.gameObject.SetActive(false);
        _RubiesCostRef.gameObject.SetActive(false);
        _LockImageRef.gameObject.SetActive(false);
    }
    private void CheckBestScore()
    {
        int bestscore = LevelsManager.Instance.GetBestScore(LevelSelectiveData.LevelKey);

        if (bestscore > 0)
        {
            _BestScoreRef.gameObject.SetActive(true);

            _BestScoreRef.StringReference.Arguments = new object[] { LevelsManager.Instance.GetBestScore(LevelSelectiveData.LevelKey) };
            _BestScoreRef.RefreshString();
        }
        else
        {
            _BestScoreRef.gameObject.SetActive(false);
        }
    }
}
