using DG.Tweening;
using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using BayatGames.SaveGameFree;
using UnityEngine.Audio;
using System.Collections;
using UnityEngine.Localization.Settings;

public class MainMenuController : MonoBehaviour
{
    public static MainMenuController Instance {  get; private set; }

    public const string SELECTED_CHARACTER_SAVE_KEY = "selectedcharacter";

    [SerializeField] private GameObject _CurrentScreen;
    [SerializeField] private Image _FadeOutImage;
    [SerializeField] private float _FadeOutTime;

    [Space]
    [SerializeField] private TMP_Text _DiamondsCountText;
    [SerializeField] private TMP_Text _RubiesCountText;

    [Space]
    [SerializeField] private AudioMixer _MainAudioMixer;

    [Space]
    [SerializeField] private Image _FlagRef;
    [SerializeField] private Sprite[] _FlagSprites;

    [Space]
    [SerializeField] private Image _CurrentCharacterSprite;

    private int _currentLanguageIndex = 0;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        Application.targetFrameRate = 60;

        CurrencyController.Instance.OnDiamondsUpdated += UpdateDiamondsCount;
        CurrencyController.Instance.OnRubiesUpdated += UpdateRubiesCount;

        UpdateDiamondsCount(CurrencyController.Instance.GetDiamonds());
        UpdateRubiesCount(CurrencyController.Instance.GetRubies());

        if (PlayerPrefs.HasKey("languageIndex"))
        {
            ChangeLanguage(PlayerPrefs.GetInt("languageIndex"));
        }
        else
        {
            ChangeLanguage(0);
        }

        GameObject playerPrefab = CharactersAndCardsUnlockController.Instance.GetCharacter(GetSelectedCharacterNameKeyId());
        if (playerPrefab == null)
        {
            playerPrefab = CharactersAndCardsUnlockController.Instance.GetFirstCharacter();
        }

        _CurrentCharacterSprite.sprite = playerPrefab.GetComponentInChildren<SpriteRenderer>().sprite;
    }

    public void ChangeScreen(GameObject toScreen)
    {
        _FadeOutImage.raycastTarget = true;
        _FadeOutImage.DOFade(1f, _FadeOutTime).OnComplete(() =>
        {
            _CurrentScreen.SetActive(false);
            _CurrentScreen = toScreen;
            _CurrentScreen.SetActive(true);
            _FadeOutImage.raycastTarget = false;

            _FadeOutImage.DOFade(0f, _FadeOutTime);
        });
    }

    public void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }

    public void SelectCharacter(string characterNameKeyId)
    {
        SaveGame.Save<string>(SELECTED_CHARACTER_SAVE_KEY,characterNameKeyId);

        GameObject playerPrefab = CharactersAndCardsUnlockController.Instance.GetCharacter(GetSelectedCharacterNameKeyId());
        if (playerPrefab == null)
        {
            playerPrefab = CharactersAndCardsUnlockController.Instance.GetFirstCharacter();
        }

        _CurrentCharacterSprite.sprite = playerPrefab.GetComponentInChildren<SpriteRenderer>().sprite;
    }
    public string GetSelectedCharacterNameKeyId()
    {
        if (SaveGame.Exists(SELECTED_CHARACTER_SAVE_KEY))
        {
            return SaveGame.Load<string>(SELECTED_CHARACTER_SAVE_KEY);
        }

        return "";
    }

    public void ResetAllProgress()
    {
        SaveGame.DeleteAll();
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    #region Audio
    public void SetMusicMute(bool mute)
    {
        if (mute)
        {
            _MainAudioMixer.SetFloat("Music", -80);
        }
        else
        {
            _MainAudioMixer.SetFloat("Music", 0);
        }
    }
    public void SetSFXMute(bool mute)
    {
        if (mute)
        {
            _MainAudioMixer.SetFloat("SFX", -80);
        }
        else
        {
            _MainAudioMixer.SetFloat("SFX", 0);
        }
    }
    #endregion

    #region Language
    public void ChangeLanguage(int localeIndex)
    {
        _currentLanguageIndex = localeIndex;
        StartCoroutine(SetLanguage(localeIndex));
    }
    public void ChangeLanguage()
    {
        int totalLanguages = LocalizationSettings.AvailableLocales.Locales.Count;
        _currentLanguageIndex = (_currentLanguageIndex + 1) % totalLanguages;
        StartCoroutine(SetLanguage(_currentLanguageIndex));
    }
    private IEnumerator SetLanguage(int languageIndex)
    {
        yield return LocalizationSettings.InitializationOperation;

        LocalizationSettings.SelectedLocale = LocalizationSettings.AvailableLocales.Locales[languageIndex];
        _FlagRef.sprite = _FlagSprites[languageIndex];

        PlayerPrefs.SetInt("languageIndex",languageIndex);
    }
    #endregion

    #region Currency
    private void UpdateDiamondsCount(int count)
    {
        _DiamondsCountText.text = count.ToString();
    }
    private void UpdateRubiesCount(int count)
    {
        _RubiesCountText.text = count.ToString();
    }
    #endregion
}