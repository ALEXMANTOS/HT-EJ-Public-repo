using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Toggle))]
public class SaveToggleState : MonoBehaviour
{
    [SerializeField] private string _SaveName;

    private Toggle _toggle;

    private void Awake()
    {
        _toggle = GetComponent<Toggle>();
    }

    private void Start()
    {
        _toggle.onValueChanged.AddListener(SaveState);

        if (PlayerPrefs.HasKey(_SaveName))
        {
            _toggle.isOn = PlayerPrefs.GetInt(_SaveName) == 1;
        }
    }

    private void SaveState(bool state)
    {
        PlayerPrefs.SetInt(_SaveName, _toggle.isOn ? 1 : 0);
        PlayerPrefs.Save();
    }
}