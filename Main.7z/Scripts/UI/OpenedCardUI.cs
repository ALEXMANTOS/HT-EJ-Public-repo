using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class OpenedCardUI : MonoBehaviour
{
    [SerializeField] private TMP_Text _CardNameRef;
    [SerializeField] private Image _CardIconRef;
    [SerializeField] private TMP_Text _CardDescriptionRef;
    [SerializeField] private TMP_Text _CardCostRef;

    private CardData _cardData;

    [Header("Enable/Disable Settings")]
    [SerializeField] private RectTransform _InformationBox;
    [SerializeField] private CanvasGroup _CloseButtoCGnRef;
    [SerializeField] private CanvasGroup _ActivateButtonCGRef;

    [Space]
    [SerializeField] private float _EnableTime;
    [SerializeField] private float _DisableTime;

    public void SetCardData(CardData data,Sprite cardSprite)
    {
        _cardData = data;

        _InformationBox.GetComponent<Image>().sprite = cardSprite;

        _CardNameRef.text = _cardData.CardName.GetLocalizedString();
        _CardIconRef.sprite = _cardData.Icon;
        _CardDescriptionRef.text = _cardData.CardDescription.GetLocalizedString();
        _CardCostRef.text = _cardData.EnergyCost.ToString();
    }

    public void SetCardActive(bool active)
    {
        if(active == true)
        {
            _InformationBox.localScale = Vector3.zero;
            _CloseButtoCGnRef.alpha = 0;

            gameObject.SetActive(true);

            _CloseButtoCGnRef.DOFade(1f, _EnableTime).SetEase(Ease.InOutQuad);
            if (_cardData.CanUse())
            {
                _ActivateButtonCGRef.gameObject.SetActive(true);
                _ActivateButtonCGRef.alpha = 0;
                _ActivateButtonCGRef.DOFade(1f, _EnableTime).SetEase(Ease.InOutQuad);
            }
            else
            {
                _ActivateButtonCGRef.gameObject.SetActive(false);
            }

            _InformationBox.DOScale(Vector3.one, _EnableTime).SetEase(Ease.OutBack);
        }
        else
        {
            _InformationBox.DOScale(Vector3.zero, _DisableTime).SetEase(Ease.InBack);

            _CloseButtoCGnRef.DOFade(0f, _DisableTime).SetEase(Ease.InOutQuad);
            _ActivateButtonCGRef.DOFade(0f, _DisableTime).SetEase(Ease.InOutQuad).OnComplete(() =>
            {
                gameObject.SetActive(false);
            });
        }
    }

    public void UseCard()
    {
        _cardData.SpendEnergy();

        foreach (CardEffect effect in _cardData.Effects)
        {
            effect.Calling();
        }
    }
}
