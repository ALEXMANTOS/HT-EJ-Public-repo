using DG.Tweening;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerControlsUIController : MonoBehaviour
{
    public static PlayerControlsUIController Instance { get; private set; }

    [Header("Controls Screens")]
    [SerializeField] private GameObject _MainScreen;
    [SerializeField] private GameObject _CellsScreen;

    [Header("Moving")]
    [SerializeField] private Button _UpMoveButton;
    [SerializeField] private Button _DownMoveButton;
    [SerializeField] private Button _LeftMoveButton;
    [SerializeField] private Button _RightMoveButton;

    [Header("Stats")]
    [SerializeField] private TMP_Text _HPCountText;
    [SerializeField] private TMP_Text _EPCountText;

    [Space]
    [SerializeField] private LocalizeStringEvent _PlayerTurnsCountText;
    [SerializeField] private LocalizeStringEvent _GameTurnsCountText;

    [Space]
    [SerializeField] private RectTransform _ReturnToMMParent;
    [SerializeField] private RectTransform _ReturnToMMBox;

    [Header("Cells Buttons")]
    [SerializeField] private GameObject _CellButtonPrefab;
    [SerializeField] private RectTransform _CellsButtonsParent;

    private Dictionary<Cell, Button> _cellsButtons = new Dictionary<Cell, Button>();
    private Action<Cell> _cellBtnAction;
    private bool _disableCellsAfterAction;

    [Header("Action")]
    [SerializeField] private Button _ActionButton;
    [SerializeField] private Button _CancelActionButton;

    private PlayerTurnController _playerTurnController;
    private PlayerHealth _playerHealth;
    private PlayerEnergy _playerEnergy;
    private TurnController _turnController;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        _turnController = GameManager.Instance.GetComponent<TurnController>();

        Invoke("StartHandler", 0.05f);
    }

    private void StartHandler()
    {
        _playerTurnController = PlayerManager.Instance.GetComponent<PlayerTurnController>();
        _playerHealth = PlayerManager.Instance.GetComponent<PlayerHealth>();
        _playerEnergy = PlayerManager.Instance.GetComponent<PlayerEnergy>();

        SetMovementButtonsAction(_playerTurnController.TryDoMove);

        _playerTurnController.OnMoved += UpdateTurnsCount;
        _turnController.OnNewTurnStarted += (s) => UpdateTurnsCount();

        _playerHealth.OnHPChanged += UpdateHPCount;
        _playerEnergy.OnEnergyPointsChanged += UpdateEPCount;

        UpdateTurnsCount();
        UpdateHPCount(_playerHealth._CurrentHealth);
        UpdateEPCount(_playerEnergy._CurrentEnergy);

        CreateCellsButtons();
    }

    public void SetMovementButtonsAction(Action<Vector2> action)
    {
        _UpMoveButton.onClick.RemoveAllListeners();
        _DownMoveButton.onClick.RemoveAllListeners();
        _LeftMoveButton.onClick.RemoveAllListeners();
        _RightMoveButton.onClick.RemoveAllListeners();

        _UpMoveButton.onClick.AddListener(() => action.Invoke(Vector2.up));
        _DownMoveButton.onClick.AddListener(() => action.Invoke(Vector2.down));
        _LeftMoveButton.onClick.AddListener(() => action.Invoke(Vector2.left));
        _RightMoveButton.onClick.AddListener(() => action.Invoke(Vector2.right));
    }
    public void ResetMovementButtonsAction()
    {
        SetMovementButtonsAction(_playerTurnController.TryDoMove);
    }

    public void GiveUp()
    {
        GameManager.Instance.GetComponent<GameOverController>().GiveUp();
    }

    #region Screens
    private void OpenMainScreen()
    {
        _CellsScreen.SetActive(false);
        _MainScreen.SetActive(true);
    }
    public void OpenCellsScreen(Action<Cell> cellBtnAction,bool includeOccupatedCells = false,bool disableCellsAfterAction = true)
    {
        _cellBtnAction = cellBtnAction;

        _MainScreen.SetActive(false);
        _CellsScreen.SetActive(true);

        _disableCellsAfterAction = disableCellsAfterAction;

        foreach (var entry in _cellsButtons)
        {
            Cell cell = entry.Key;
            Button button = entry.Value;

            if (includeOccupatedCells)
            {
                button.gameObject.SetActive(true);
            }
            else
            {
                button.gameObject.SetActive(cell.Occupant == null);
            }
        }
    }
    #endregion

    #region Action Button
    public void EnableActionButton(ActionForScreen actionFor, Action<Vector2> playerAction, Action actionOfActionButton,Action actionOfCancelAction) 
    {
        _ActionButton.gameObject.SetActive(true);
        if(actionFor == ActionForScreen.Main)
        {
            _ActionButton.onClick.AddListener(() => 
            {
                SetMovementButtonsAction(playerAction);

                actionOfActionButton.Invoke();

                _ActionButton.gameObject.SetActive(false);
                _CancelActionButton.gameObject.SetActive(true);
            });
            _CancelActionButton.onClick.AddListener(() => 
            {
                actionOfCancelAction.Invoke();

                SetMovementButtonsAction(_playerTurnController.TryDoMove);

                _CancelActionButton.gameObject.SetActive(false);
                _ActionButton.gameObject.SetActive(true);
            });
        }
        else
        {
            _ActionButton.onClick.AddListener(() =>
            {
                actionOfActionButton.Invoke();

                OpenCellsScreen(ConvertVector2ToCellAction(playerAction), true,false);

                _ActionButton.gameObject.SetActive(false);
                _CancelActionButton.gameObject.SetActive(true);
            });
            _CancelActionButton.onClick.AddListener(() =>
            {
                actionOfCancelAction.Invoke();

                OpenMainScreen();

                _CancelActionButton.gameObject.SetActive(false);
                _ActionButton.gameObject.SetActive(true);
            });
        }

        _turnController.OnNewTurnStarted += (s) =>
        {
            if (_CancelActionButton.gameObject.activeSelf == true)
            {
                if(_MainScreen.gameObject.activeSelf == true)
                {
                    actionOfCancelAction.Invoke();

                    SetMovementButtonsAction(_playerTurnController.TryDoMove);

                    _CancelActionButton.gameObject.SetActive(false);
                    _ActionButton.gameObject.SetActive(true);
                }
                else
                {
                    actionOfCancelAction.Invoke();

                    OpenMainScreen();

                    _CancelActionButton.gameObject.SetActive(false);
                    _ActionButton.gameObject.SetActive(true);
                }
            }
        };
    }

    private Action<Cell> ConvertVector2ToCellAction(Action<Vector2> vectorAction)
    {
        return (Cell cell) =>
        {
            Vector2 cellPosition = cell.transform.position;
            vectorAction(cellPosition);
        };
    }

    public enum ActionForScreen
    {
        Main,
        Cells
    }
    #endregion

    #region Cells Buttons
    private void CreateCellsButtons()
    {
        var cells = GameManager.Instance.GetComponent<MapController>().GetMap();
        Canvas canvas = GetComponent<Canvas>();

        Vector3 cellSize = cells[0].GetComponent<Renderer>().bounds.size;
        float sizeFactor = 0.8f;

        foreach (var cell in cells)
        {
            Vector2 screenPosition = RectTransformUtility.WorldToScreenPoint(Camera.main, cell.transform.position);
            var buttonInstance = Instantiate(_CellButtonPrefab, _CellsButtonsParent);
            var button = buttonInstance.GetComponent<Button>();
            RectTransform buttonRect = buttonInstance.GetComponent<RectTransform>();
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                _CellsButtonsParent as RectTransform, screenPosition, canvas.worldCamera, out Vector2 localPosition
            );

            buttonRect.localPosition = localPosition;

            Vector2 cellSizeOnScreen = RectTransformUtility.WorldToScreenPoint(Camera.main, cell.transform.position + cellSize) - screenPosition;
            buttonRect.sizeDelta = new Vector2(Mathf.Abs(cellSizeOnScreen.x), Mathf.Abs(cellSizeOnScreen.y)) * sizeFactor;

            button.onClick.AddListener(() => OnCellButtonClicked(cell));
            _cellsButtons.Add(cell, button);
        }
    }

    private void OnCellButtonClicked(Cell cell)
    {
        Debug.Log($"Button clicked on cell at position {cell.transform.position}");

        _cellBtnAction.Invoke(cell);

        if (_disableCellsAfterAction)
        {
            OpenMainScreen();
        }
    }
    #endregion

    #region Update Counts
    private void UpdateTurnsCount()
    {
        _PlayerTurnsCountText.StringReference.Arguments = new object[] { PlayerManager.Instance.GetComponent<MapEntityTurnController>().CurrentMovesCount };
        _PlayerTurnsCountText.RefreshString();

        _GameTurnsCountText.StringReference.Arguments = new object[] { _turnController.CurrentTurn };
        _GameTurnsCountText.RefreshString();
    }
    private void UpdateHPCount(float hp)
    {
        _HPCountText.text = hp % 1 == 0
        ? $"{(int)hp}" : $"{hp:F1}";
    }
    private void UpdateEPCount(float ep)
    {
        _EPCountText.text = ep % 1 == 0
        ? $"{(int)ep}" : $"{ep:F1}";
    }
    #endregion

    #region Return Box
    public void OpenReturnBox()
    {
        _ReturnToMMBox.localScale = Vector3.zero;
        _ReturnToMMParent.gameObject.SetActive(true);
        _ReturnToMMBox.DOScale(Vector3.one, 0.3f).SetEase(Ease.OutBack);
    }

    public void HideReturnBox()
    {
        _ReturnToMMBox.DOScale(Vector3.zero, 0.3f).SetEase(Ease.InBack).OnComplete(() =>
        {
            _ReturnToMMParent.gameObject.SetActive(false);
        });
    }
    #endregion

    #region Scenes
    public void ChangeScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }
    public void ReloadScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    #endregion
}