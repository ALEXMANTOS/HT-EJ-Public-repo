using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerEffectUI : MonoBehaviour
{
    [SerializeField] private Image _IconRef;
    [SerializeField] private TMP_Text _StatusRef;

    public void Initialize(Sprite effectIcon, float effectStatus)
    {
        _IconRef.sprite = effectIcon;
        UpdateStatus(effectStatus);
    }

    public void UpdateStatus(float effectStatus)
    {
        _StatusRef.text = effectStatus % 1 == 0
             ? $"{(int)effectStatus}" : $"{effectStatus:F1}";
    }
}
