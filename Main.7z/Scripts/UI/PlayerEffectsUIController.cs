using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerEffectsUIController : MonoBehaviour
{
    public static PlayerEffectsUIController Instance {  get; private set; }

    [SerializeField] private GameObject _EffectsBox;
    [SerializeField] private PlayerEffectUI _UIEffectPrefab;

    private Dictionary<string, PlayerEffectUI> _activeEffects = new Dictionary<string, PlayerEffectUI>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void AddUIEffect(string effectName, Sprite effectIcon, float effectStatus)
    {
        if (_activeEffects.ContainsKey(effectName))
        {
            Debug.LogWarning($"������ '{effectName}' ��� ����������. �������� ��� ������.");
            return;
        }
        PlayerEffectUI effectUI = Instantiate(_UIEffectPrefab, _EffectsBox.transform);

        if (effectUI != null)
        {
            effectUI.Initialize(effectIcon, effectStatus);
            _activeEffects.Add(effectName, effectUI);
        }
        else
        {
            Debug.LogError("������ �� �������� ��������� EffectUI!");
        }
    }
    public bool EffectExist(string effectName)
    {
        return _activeEffects.ContainsKey(effectName);
    }
    public void UpdateUIEffectStatus(string effectName, float effectStatus)
    {
        if (_activeEffects.TryGetValue(effectName, out PlayerEffectUI effectUI))
        {
            effectUI.UpdateStatus(effectStatus);
        }
        else
        {
            Debug.LogWarning($"������ '{effectName}' �� ������.");
        }
    }

    public void RemoveUIEffect(string effectName)
    {
        if (_activeEffects.TryGetValue(effectName, out PlayerEffectUI effectUI))
        {
            Destroy(effectUI.gameObject);
            _activeEffects.Remove(effectName);
        }
        else
        {
            Debug.LogWarning($"������ '{effectName}' �� ������ ��� ��������.");
        }
    }
}