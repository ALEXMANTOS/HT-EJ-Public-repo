using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Canvas))]
public class SetSFXToButtonsCanvas : MonoBehaviour
{
    [SerializeField] private AudioClip _ButtonClickSound;
    [SerializeField] private List<Button> _ExcludedButtons;

    private AudioController _audioController;
    private Canvas _canvas;

    private void Start()
    {
        _audioController = AudioController.Instance;
        _canvas = GetComponent<Canvas>();

        Button[] buttons = _canvas.GetComponentsInChildren<Button>(true);

        foreach (Button button in buttons)
        {
            if (!_ExcludedButtons.Contains(button))
            {
                button.onClick.AddListener(() => PlaySound());
            }
        }
    }

    private void PlaySound()
    {
        if (_ButtonClickSound != null)
        {
            _audioController.PlaySound(_ButtonClickSound, 0.2f);
        }
    }
}