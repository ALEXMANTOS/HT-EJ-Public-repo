using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(GameOverController))]
public class UpdateLeaderboardScoreOnGameOver : MonoBehaviour
{
    [SerializeField] private string _LeaderboardID;

    private void Start()
    {
        GameManager.Instance.GetComponent<GameOverController>().OnGameOver += () =>
            GooglePlayServicesManager.Instance.UpdateLeaderboardScore(_LeaderboardID, GameManager.Instance.GetComponent<TurnController>().CurrentTurn);
    }
}
