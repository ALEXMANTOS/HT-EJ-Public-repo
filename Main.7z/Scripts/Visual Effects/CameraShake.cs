using DG.Tweening;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Camera))]
public class CameraShake : MonoBehaviour
{
    private float _shakeDuration = 0.15f;
    private float _shakeStrength = 0.3f;
    private int _vibrato = 20;
    private float _randomness = 360f;

    private Vector3 _originalPosition;

    private void Start()
    {
        _originalPosition = transform.position;
    }

    public void Shake(float multiplier = 1)
    {
        float adjustedDuration = Mathf.Clamp(_shakeDuration * multiplier, _shakeDuration, _shakeDuration * 1.6f);
        float adjustedStrength = Mathf.Clamp(_shakeStrength * multiplier, _shakeStrength, _shakeStrength * 1.6f);
        int adjustedVibrato = (int)Mathf.Clamp(_vibrato * multiplier, _vibrato, _vibrato * 1.5f);

        transform.DOShakePosition(_shakeDuration, _shakeStrength, _vibrato, _randomness)
            .OnComplete(() => transform.position = _originalPosition);
    }
    public void Shake(float duration, float strength, int vibrato = 10, float randomness = 90f)
    {
        transform.DOShakePosition(duration, strength, vibrato, randomness)
            .OnComplete(() => transform.position = _originalPosition);
    }
}
