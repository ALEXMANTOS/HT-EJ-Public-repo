using DG.Tweening;
using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SliceEffect : MonoBehaviour
{
    public static SliceEffect Instance { get; private set; }

    [SerializeField] private GameObject _SliceEffectPrefab;
    [SerializeField] private float _SliceDuration = 0.2f;
    [SerializeField] private float _SliceStartDistance = 1f;
    [SerializeField] private float _SliceEndDistance = 0.8f;
    [SerializeField] private float _DespawnDelay = 0.5f;

    private void Awake()
    {
        Instance = this;
    }

    public void ShowSliceEffect(Vector3 targetPosition)
    {
        GameObject effectInstance = LeanPool.Spawn(_SliceEffectPrefab, Vector3.zero, Quaternion.identity);
        effectInstance.transform.position = GetRandomStartPosition(targetPosition, _SliceStartDistance);
        AnimateTrail(effectInstance, targetPosition);
    }

    private void AnimateTrail(GameObject effectInstance, Vector3 targetPosition)
    {
        TrailRenderer trailRenderer = effectInstance.GetComponent<TrailRenderer>();
        Vector3 randomEndPoint = GetRandomEndPoint(effectInstance.transform.position, targetPosition, _SliceEndDistance);
        Vector3[] path = new Vector3[3];
        path[0] = effectInstance.transform.position;
        path[1] = targetPosition;
        path[2] = randomEndPoint;
        effectInstance.transform.DOPath(path, _SliceDuration, PathType.CatmullRom)
            .OnComplete(() =>
            {
                LeanPool.Despawn(effectInstance, _DespawnDelay);
            });
    }

    private Vector3 GetRandomStartPosition(Vector3 target, float distance)
    {
        Vector2 randomDirection = Random.insideUnitCircle.normalized;
        return target + new Vector3(randomDirection.x, randomDirection.y, 0) * distance;
    }

    private Vector3 GetRandomEndPoint(Vector3 startPosition, Vector3 targetPosition, float distance)
    {
        Vector3 direction = (targetPosition - startPosition).normalized;
        Vector3 oppositeDirection = direction;
        float angleOffset = Random.Range(-60f, 60f);
        Quaternion rotation = Quaternion.Euler(0, 0, angleOffset);
        Vector3 offsetDirection = rotation * oppositeDirection;
        Vector3 endPoint = targetPosition + offsetDirection * distance;

        return endPoint;
    }
}
