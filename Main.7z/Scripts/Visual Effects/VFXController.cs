using Lean.Pool;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(ParticleSystem))]
public class VFXController : MonoBehaviour
{
    [SerializeField] private bool _DestroyAfterPlay = true;

    private ParticleSystem[] particleSystems;

    private void Awake()
    {
        particleSystems = GetComponentsInChildren<ParticleSystem>();
    }
    private void Update()
    {
        if (_DestroyAfterPlay && !particleSystems[0].IsAlive() && !particleSystems[0].isPlaying)
        {
            LeanPool.Despawn(gameObject);
        }
    }

    public void UnparentAndStop()
    {
        transform.SetParent(null);

        foreach (var particleSystem in particleSystems)
        {
            particleSystem.Stop();
        }
    }
    public void SetEffectSize(Vector3 zoneSize)
    {
        foreach (var particleSystem in particleSystems)
        {
            var shape = particleSystem.shape;
            shape.scale = zoneSize;
            var main = particleSystem.main;
            main.startSize = zoneSize.magnitude * 0.1f;
        }
    }
}
